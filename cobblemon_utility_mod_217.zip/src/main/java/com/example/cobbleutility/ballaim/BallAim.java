package com.example.cobbleutility.ballaim;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.radar.CobblemonBridge;
import com.example.cobbleutility.render.RenderUtil;
import com.example.cobbleutility.util.ColorUtil;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;

/**
 * Poké Ball aim assist. When enabled and you throw a Cobblemon ball while a Pokémon is near your crosshair,
 * the throw direction is replaced by a computed one that accounts for distance (gravity + drag) and the
 * target's movement, then your camera is restored. Everything is client-side: the server just receives a
 * normal "use item" with a slightly different look direction.
 */
public final class BallAim {
    private record Solution(float yaw, float pitch, double flightTicks, Vec3d aimPoint) {}

    // state shared with the renderer
    private static Entity target;
    private static List<Vec3d> arc = List.of();
    private static boolean holdingBall;

    // movement tracking of the current target
    private static int trackedId = -1;
    private static Vec3d lastPos;
    private static Vec3d velocity = Vec3d.ZERO;

    // rotation restore after a throw
    private static boolean restore;
    private static float restoreYaw, restorePitch;

    private BallAim() {}

    /** The Pokémon currently picked near the crosshair while holding a ball (null otherwise). */
    public static Entity currentTarget() {
        return target;
    }

    public static void init() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            onUse(player, hand);
            return TypedActionResult.pass(player.getStackInHand(hand));
        });
        ClientTickEvents.END_CLIENT_TICK.register(BallAim::tick);
    }

    // ------------------------------------------------------------------ helpers
    public static boolean isBall(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        Identifier id = Registries.ITEM.getId(stack.getItem());
        return id.getNamespace().equals("cobblemon") && id.getPath().endsWith("_ball");
    }

    private static Vec3d center(Entity e) {
        Box b = e.getBoundingBox();
        return new Vec3d((b.minX + b.maxX) / 2, (b.minY + b.maxY) / 2, (b.minZ + b.maxZ) / 2);
    }

    private static Vec3d startPos(PlayerEntity p) {
        return new Vec3d(p.getX(), p.getEyeY() - 0.1, p.getZ());
    }

    // ------------------------------------------------------------------ per tick
    private static void tick(MinecraftClient mc) {
        if (restore && mc.player != null) {
            mc.player.setYaw(restoreYaw);
            mc.player.setPitch(restorePitch);
        }
        restore = false;

        ModConfig cfg = ConfigManager.get();
        target = null;
        arc = List.of();
        holdingBall = false;
        if (mc.player == null || mc.world == null || !cfg.ballAimEnabled) return;
        holdingBall = isBall(mc.player.getMainHandStack()) || isBall(mc.player.getOffHandStack());
        if (!holdingBall) {
            trackedId = -1;
            return;
        }
        Entity t = pickTarget(mc, cfg);
        if (t == null) {
            trackedId = -1;
            return;
        }
        // velocity from position delta (client velocity of mobs is unreliable)
        Vec3d c = center(t);
        if (trackedId == t.getId() && lastPos != null) {
            Vec3d v = c.subtract(lastPos);
            velocity = velocity.multiply(0.5).add(v.multiply(0.5)); // light smoothing
        } else {
            velocity = Vec3d.ZERO;
        }
        trackedId = t.getId();
        lastPos = c;
        target = t;

        if (!cfg.ballAimEnabled) return;
        Solution s = solve(mc, cfg, t, true);
        if (s != null && cfg.ballAimShowArc) arc = simulate(mc.player, s.yaw(), s.pitch(), cfg, (int) Math.ceil(s.flightTicks()) + 1);
    }

    private static Entity pickTarget(MinecraftClient mc, ModConfig cfg) {
        PlayerEntity p = mc.player;
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0f);
        double maxDist = cfg.ballAimMaxDistance;
        double cosMax = Math.cos(Math.toRadians(cfg.ballAimFov));
        Entity best = null;
        double bestDot = cosMax;
        for (Entity e : mc.world.getEntities()) {
            if (e == p || e.isRemoved() || !CobblemonBridge.isPokemon(e)) continue;
            Vec3d c = center(e);
            double d = c.distanceTo(eye);
            if (d > maxDist || d < 1.5) continue;
            double dot = c.subtract(eye).normalize().dotProduct(look);
            if (dot < bestDot) continue;
            if (cfg.ballAimWildOnly) {
                try {
                    CobblemonBridge.Info info = CobblemonBridge.inspect(e, mc);
                    if (info != null && info.owned()) continue;
                } catch (Throwable ignored) {
                }
            }
            bestDot = dot;
            best = e;
        }
        return best;
    }

    // ------------------------------------------------------------------ use hook
    private static void onUse(PlayerEntity player, Hand hand) {
        ModConfig cfg = ConfigManager.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!cfg.ballAimEnabled || mc.player == null || player != mc.player || mc.world == null) return;
        if (!isBall(player.getStackInHand(hand))) return;
        Entity t = target != null && !target.isRemoved() ? target : pickTarget(mc, cfg);
        if (t == null) return;
        Solution s = solve(mc, cfg, t, true);
        if (s == null) {
            com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal("§cOut of range / blocked: normal throw."), true);
            return;
        }
        restoreYaw = player.getYaw();
        restorePitch = player.getPitch();
        restore = true;
        player.setYaw(s.yaw());
        player.setPitch(s.pitch());
    }

    // ------------------------------------------------------------------ physics
    /** Positions of the ball for each tick, starting with the spawn position. */
    private static List<Vec3d> simulate(PlayerEntity p, float yaw, float pitch, ModConfig cfg, int ticks) {
        List<Vec3d> pts = new ArrayList<>();
        Vec3d pos = startPos(p);
        Vec3d vel = Vec3d.fromPolar(pitch, yaw).multiply(cfg.ballAimSpeed);
        Vec3d pv = p.getVelocity();
        vel = vel.add(pv.x, p.isOnGround() ? 0.0 : pv.y, pv.z);
        pts.add(pos);
        for (int i = 0; i < ticks && i < 400; i++) {
            pos = pos.add(vel);
            vel = vel.multiply(cfg.ballAimDrag).add(0, -cfg.ballAimGravity, 0);
            pts.add(pos);
        }
        return pts;
    }

    /**
     * Height error of the trajectory at the moment it has covered the horizontal distance to {@code goal}.
     * Returns null if it never gets there; otherwise [error, flightTicks].
     */
    private static double[] errorAt(PlayerEntity p, float yaw, float pitch, ModConfig cfg, Vec3d start, Vec3d goal) {
        double hx = goal.x - start.x, hz = goal.z - start.z;
        double hDist = Math.sqrt(hx * hx + hz * hz);
        Vec3d pos = start;
        Vec3d vel = Vec3d.fromPolar(pitch, yaw).multiply(cfg.ballAimSpeed);
        Vec3d pv = p.getVelocity();
        vel = vel.add(pv.x, p.isOnGround() ? 0.0 : pv.y, pv.z);
        double ux = hx / hDist, uz = hz / hDist;
        double prevAlong = 0;
        for (int t = 1; t <= 400; t++) {
            Vec3d next = pos.add(vel);
            double along = (next.x - start.x) * ux + (next.z - start.z) * uz;
            if (along >= hDist) {
                double f = (hDist - prevAlong) / Math.max(1e-9, along - prevAlong);
                double y = pos.y + (next.y - pos.y) * f;
                return new double[]{y - goal.y, t - 1 + f};
            }
            if (along < prevAlong - 1e-6 && t > 3) return null; // flying away
            prevAlong = along;
            pos = next;
            vel = vel.multiply(cfg.ballAimDrag).add(0, -cfg.ballAimGravity, 0);
        }
        return null;
    }

    private static Solution solve(MinecraftClient mc, ModConfig cfg, Entity t, boolean checkBlocked) {
        PlayerEntity p = mc.player;
        Vec3d start = startPos(p);
        Vec3d goal = center(t);
        Solution best = null;
        for (int iter = 0; iter < 4; iter++) {
            Vec3d g = goal;
            double hx = g.x - start.x, hz = g.z - start.z;
            if (hx * hx + hz * hz < 1.0) return null;
            float yaw = (float) (Math.toDegrees(Math.atan2(-hx, hz)));
            // Correct for the player's own horizontal drift: refine yaw so that the arrival point lines up.
            Float pitch = solvePitch(p, yaw, cfg, start, g);
            if (pitch == null) return null;
            double[] e = errorAt(p, yaw, pitch, cfg, start, g);
            if (e == null) return null;
            best = new Solution(yaw, pitch, e[1], g);
            if (!cfg.ballAimLeadTarget) break;
            goal = center(t).add(velocity.multiply(e[1]));
        }
        if (best == null) return null;
        if (checkBlocked && blocked(mc, p, best, cfg)) return null;
        return best;
    }

    /** Low-arc pitch: scan from steep-down to steep-up, take the first place where the ball goes from below to above the goal. */
    private static Float solvePitch(PlayerEntity p, float yaw, ModConfig cfg, Vec3d start, Vec3d goal) {
        double[] prev = null;
        float prevPitch = 80f;
        for (float pitch = 80f; pitch >= -80f; pitch -= 1.0f) {
            double[] e = errorAt(p, yaw, pitch, cfg, start, goal);
            if (e != null && prev != null && prev[0] < 0 && e[0] >= 0) {
                float lo = prevPitch, hi = pitch; // error(lo) < 0 <= error(hi)
                for (int i = 0; i < 24; i++) {
                    float mid = (lo + hi) / 2f;
                    double[] em = errorAt(p, yaw, mid, cfg, start, goal);
                    if (em == null) break;
                    if (em[0] < 0) lo = mid; else hi = mid;
                }
                return (lo + hi) / 2f;
            }
            if (e != null) {
                prev = e;
                prevPitch = pitch;
            }
        }
        return null;
    }

    private static boolean blocked(MinecraftClient mc, PlayerEntity p, Solution s, ModConfig cfg) {
        List<Vec3d> pts = simulate(p, s.yaw(), s.pitch(), cfg, (int) Math.floor(s.flightTicks()));
        for (int i = 1; i < pts.size(); i++) {
            var hit = mc.world.raycast(new RaycastContext(pts.get(i - 1), pts.get(i),
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
            if (hit.getType() == HitResult.Type.BLOCK) {
                // a block right next to the target is fine (ball hits the Pokémon in front of it)
                if (hit.getPos().distanceTo(s.aimPoint()) > 2.0) return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ rendering
    public static void renderWorld(MatrixStack ms, Vec3d cam) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.ballAimEnabled || !holdingBall || target == null) return;
        int argb = ColorUtil.opaque(cfg.ballAimColor);
        MatrixStack.Entry entry = ms.peek();
        BufferBuilder b = RenderUtil.beginLines(2.0f);
        List<Vec3d> pts = arc;
        for (int i = 1; i < pts.size(); i++) {
            Vec3d a = pts.get(i - 1).subtract(cam), c = pts.get(i).subtract(cam);
            RenderUtil.line(b, entry, a.x, a.y, a.z, c.x, c.y, c.z, argb);
        }
        Vec3d t = center(target).subtract(cam);
        RenderUtil.diamond(b, entry, t.x, t.y, t.z, 0.4, argb);
        RenderUtil.end(b);
    }

    public static String statusText() {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.ballAimEnabled || !holdingBall) return null;
        if (target == null) return "Aim: no target";
        return "Aim: locked";
    }
}
