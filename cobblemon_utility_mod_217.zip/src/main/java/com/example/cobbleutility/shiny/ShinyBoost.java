package com.example.cobbleutility.shiny;

import com.example.cobbleutility.CobblemonUtilityMod;
import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.text.Text;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Local shiny-odds multiplier.
 *
 * In singleplayer / LAN the game server runs inside this same game, so we can temporarily lower
 * Cobblemon's in-memory "shinyRate" (the N in 1/N). It is never written to disk by this mod and is
 * restored when you leave the world, switch to a remote server, or close the game.
 * All Cobblemon access is reflective: if the setting is not found the boost simply stays inactive.
 */
public final class ShinyBoost {
    private static Float original;   // value before we touched it
    private static Float applied;    // value we set
    private static boolean warned;
    private static int tick;

    // ---- server side boost (remote servers running Cobblemon Shiny Control) ----
    private static boolean serverOn;      // what the server confirmed
    private static int serverMult;
    private static int lastSent = -1000;  // tick of the last request
    private static boolean remoteUsed;
    private static String serverKey = ""; // filter the server confirmed
    private static String pendingKey = "";
    private static int attempts;          // requests sent without an answer

    private ShinyBoost() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(ShinyBoost::onTick);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (client.getServer() == null && ConfigManager.get().shinyBoostEnabled) { // joining a remote server: start with the boost off
                ConfigManager.get().shinyBoostEnabled = false;
                ConfigManager.save();
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            restore(client, false);
            if (remoteUsed) {          // the server drops the boost when we leave: do not re-enable it on the next join
                ConfigManager.get().shinyBoostEnabled = false;
                ConfigManager.save();
            }
            serverOn = false;
            serverMult = 0;
            remoteUsed = false;
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> restore(client, false));
    }

    /** Key press: flips the boost (local world or server). */
    public static void toggleFromKey() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ModConfig cfg = ConfigManager.get();
        if (mc.player == null) return;
        boolean remote = mc.getServer() == null;
        if (remote && !com.example.cobbleutility.net.ServerLink.available()) {
            mc.player.sendMessage(Text.literal("§c[Shiny Boost] This server does not have the Cobblemon Shiny Control mod."), true);
            return;
        }
        cfg.shinyBoostEnabled = !cfg.shinyBoostEnabled;
        ConfigManager.save();
        mc.player.sendMessage(Text.literal("§6[Shiny Boost] §f" + (cfg.shinyBoostEnabled ? "§aON" : "§cOFF")
                + (remote ? " §7(asking the server...)" : "")), true);
        if (remote) { lastSent = -1000; attempts = 0; } // send right away
    }

    /** Called by ServerLink when the server answers a boost request. */
    public static void onServerReply(com.google.gson.JsonObject o) {
        boolean on = o.has("on") && o.get("on").getAsBoolean();
        attempts = 0;
        serverKey = pendingKey;
        serverOn = on;
        serverMult = o.has("chance") ? (int) Math.round(o.get("chance").getAsDouble()) : 0;
        ModConfig cfg = ConfigManager.get();
        if (cfg.shinyBoostEnabled != on) {
            cfg.shinyBoostEnabled = on; // refused or switched off by the server
            ConfigManager.save();
        }
        String msg = o.has("msg") ? o.get("msg").getAsString() : (on ? "Shiny boost ON" : "Shiny boost OFF");
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (cfg.hudToasts) {
            com.example.cobbleutility.render.Toasts.push("Shiny boost", msg, on ? 0xFFD54F : 0xB0BEC5);
        } else {
            com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal("§6[Shiny Boost] §f" + msg), true);
        }
    }

    /** The Pokémon selection sent to the server. */
    private static JsonObject buildFilter(ModConfig cfg) {
        JsonObject f = new JsonObject();
        f.addProperty("enabled", cfg.shinyFilterEnabled);
        JsonArray types = new JsonArray();
        for (String t : cfg.shinyFilterTypes.split("[,;| ]+")) if (!t.trim().isEmpty()) types.add(t.trim().toLowerCase());
        f.add("types", types);
        JsonArray cats = new JsonArray();
        if (cfg.shinyFilterLegendary) cats.add("legendary");
        if (cfg.shinyFilterMythical) cats.add("mythical");
        if (cfg.shinyFilterUltraBeast) cats.add("ultrabeast");
        if (cfg.shinyFilterParadox) cats.add("paradox");
        if (cfg.shinyFilterNormal) cats.add("normal");
        f.add("cats", cats);
        JsonArray sp = new JsonArray();
        for (String t : cfg.shinyFilterSpecies.split("[,;|]+")) if (!t.trim().isEmpty()) sp.add(t.trim().toLowerCase());
        f.add("species", sp);
        return f;
    }

    private static JsonObject buildQuality(ModConfig cfg) {
        JsonObject q = new JsonObject();
        q.addProperty("ivs", cfg.boostPerfectIvs);
        q.addProperty("ivsChance", cfg.boostIvChancePercent);
        q.addProperty("ha", cfg.boostHiddenAbilityPercent);
        q.addProperty("size", cfg.boostSizeMode);
        q.addProperty("sizeChance", cfg.boostSizeChancePercent);
        q.addProperty("alpha", cfg.boostAlphaPercent);
        return q;
    }

    private static JsonObject buildSpawns(ModConfig cfg) {
        JsonObject s = new JsonObject();
        JsonArray cats = new JsonArray();
        if (cfg.spawnUltraBeasts) cats.add("ultrabeast");
        if (cfg.spawnLegendary) cats.add("legendary");
        if (cfg.spawnMythical) cats.add("mythical");
        if (cfg.spawnParadox) cats.add("paradox");
        s.add("cats", cats);
        s.addProperty("minutes", cfg.spawnEveryMinutes);
        s.addProperty("lmin", Math.min(cfg.spawnLevelMin, cfg.spawnLevelMax));
        s.addProperty("lmax", Math.max(cfg.spawnLevelMin, cfg.spawnLevelMax));
        return s;
    }

    private static void remoteSync(MinecraftClient mc) {
        ModConfig cfg = ConfigManager.get();
        if (!com.example.cobbleutility.net.ServerLink.available()) return;
        boolean want = cfg.shinyBoostEnabled;
        int mult = Math.max(0, Math.min(100, cfg.shinyServerChancePercent));
        JsonObject filter = buildFilter(cfg);
        JsonObject quality = buildQuality(cfg);
        JsonObject spawns = buildSpawns(cfg);
        String key = filter.toString() + quality + spawns;
        boolean differs = want != serverOn || (want && ((mult != serverMult && serverMult != 0) || !key.equals(serverKey)));
        if (!differs) return;
        if (tick - lastSent < 40) return; // wait for the answer (2 s)
        if (attempts >= 3) { // the server never answers: it has no (or an old) Cobblemon Shiny Control mod
            cfg.shinyBoostEnabled = false;
            ConfigManager.save();
            attempts = 0;
            if (mc.player != null) mc.player.sendMessage(Text.literal(
                    "§c[Shiny Boost] The server did not answer. Install Cobblemon Shiny Control 1.7.0 or newer on the server."), false);
            return;
        }
        attempts++;
        lastSent = tick;
        remoteUsed = true;
        pendingKey = key;
        com.example.cobbleutility.net.ServerLink.requestBoost(want, mult, filter, quality, spawns);
    }

    private static void onTick(MinecraftClient mc) {
        if (++tick % 20 != 0) return;
        ModConfig cfg = ConfigManager.get();
        if (mc.world != null && mc.player != null && mc.getServer() == null) { // remote server
            remoteSync(mc);
            return;
        }
        boolean should = cfg.shinyBoostEnabled && mc.world != null && mc.player != null && mc.getServer() != null;
        if (!should) {
            if (applied != null) restore(mc, true);
            return;
        }

        Object config = cobblemonConfig();
        if (config == null) {
            warnOnce(mc, "Cobblemon not found: shiny boost unavailable.");
            return;
        }
        Float current = readRate(config);
        if (current == null || current <= 0f) {
            warnOnce(mc, "Could not read Cobblemon's shiny rate: shiny boost unavailable.");
            return;
        }

        // If the current value is not the one we set, it is the new "real" base (config reload etc.)
        boolean firstTime = applied == null;
        if (firstTime || Math.abs(current - applied) > 0.01f) original = current;

        float target = Math.max(1f, original / Math.max(1, cfg.shinyMultiplier));
        if (firstTime || Math.abs(current - target) > 0.01f) {
            if (!writeRate(config, target)) {
                warnOnce(mc, "Could not change Cobblemon's shiny rate: shiny boost unavailable.");
                original = null;
                applied = null;
                return;
            }
            applied = target;
            if (cfg.shinyBoostNotify) {
                mc.player.sendMessage(Text.literal("§6[Shiny Boost] §fshiny odds 1/" + Math.round(original)
                        + " §7->§f 1/" + Math.round(target) + " §7(x" + cfg.shinyMultiplier + ")"), false);
            }
        }
    }

    private static void restore(MinecraftClient mc, boolean notify) {
        if (original != null && applied != null) {
            Object config = cobblemonConfig();
            if (config != null) {
                Float current = readRate(config);
                if (current != null && Math.abs(current - applied) < 0.01f) writeRate(config, original);
            }
            if (notify && mc.player != null && ConfigManager.get().shinyBoostNotify) {
                mc.player.sendMessage(Text.literal("§6[Shiny Boost] §7removed, odds back to 1/" + Math.round(original)), false);
            }
        }
        original = null;
        applied = null;
    }

    private static void warnOnce(MinecraftClient mc, String msg) {
        if (warned) return;
        warned = true;
        CobblemonUtilityMod.LOGGER.warn(msg);
        if (mc.player != null) mc.player.sendMessage(Text.literal("§c[Shiny Boost] " + msg), false);
    }

    // ------------------------------------------------------------ reflection
    private static Object cobblemonConfig() {
        if (!FabricLoader.getInstance().isModLoaded("cobblemon")) return null;
        try {
            Class<?> cls = Class.forName("com.cobblemon.mod.common.Cobblemon", true, ShinyBoost.class.getClassLoader());
            Object instance = cls.getField("INSTANCE").get(null);
            Method getter = cls.getMethod("getConfig");
            return getter.invoke(instance);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Float readRate(Object config) {
        try {
            for (Method m : config.getClass().getMethods()) {
                if (m.getName().equals("getShinyRate") && m.getParameterCount() == 0) {
                    Object v = m.invoke(config);
                    if (v instanceof Number n) return n.floatValue();
                }
            }
            Field f = findField(config.getClass(), "shinyRate");
            if (f != null) {
                Object v = f.get(config);
                if (v instanceof Number n) return n.floatValue();
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static boolean writeRate(Object config, float value) {
        try {
            for (Method m : config.getClass().getMethods()) {
                if (m.getName().equals("setShinyRate") && m.getParameterCount() == 1) {
                    Class<?> t = m.getParameterTypes()[0];
                    if (t == float.class || t == Float.class) m.invoke(config, value);
                    else if (t == double.class || t == Double.class) m.invoke(config, (double) value);
                    else continue;
                    return true;
                }
            }
            Field f = findField(config.getClass(), "shinyRate");
            if (f != null) {
                if (f.getType() == double.class) f.setDouble(config, value); else f.setFloat(config, value);
                return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static Field findField(Class<?> cls, String name) {
        for (Class<?> c = cls; c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {
            }
        }
        return null;
    }
}
