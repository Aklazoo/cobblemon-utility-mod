package com.example.cobbleutility.render;

import com.example.cobbleutility.esp.ContainerEsp;
import com.example.cobbleutility.radar.RadarManager;
import com.example.cobbleutility.structure.StructureFinder;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

/** Single registration point for all per-frame drawing. Everything reads ModConfig live. */
public final class Overlay {
    private Overlay() {}

    public static void init() {
        WorldRenderEvents.LAST.register(ctx -> {
            MatrixStack ms = ctx.matrixStack();
            if (ms == null || com.example.cobbleutility.util.StreamMode.active()) return;
            Vec3d cam = ctx.camera().getPos();
            float td = ctx.tickCounter().getTickDelta(false);
            ContainerEsp.render(ms, cam, ctx.camera());
            RadarManager.renderWorld(ms, cam, td, ctx.camera());
            StructureFinder.renderWorld(ms, cam, ctx.camera());
            com.example.cobbleutility.ballaim.BallAim.renderWorld(ms, cam);
            com.example.cobbleutility.finder.ChestFilter.renderWorld(ms, cam);
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.player == null || com.example.cobbleutility.util.StreamMode.active()) return;
            float td = tickCounter.getTickDelta(false);
            RadarManager.renderHud(drawContext, td);
            StructureFinder.renderHud(drawContext, td);
            String cf = com.example.cobbleutility.finder.ChestFilter.statusText();
            if (cf != null) {
                int cw = mc.textRenderer.getWidth(cf) + 14;
                Hud.panel(drawContext, 6, 6, cw, 16, com.example.cobbleutility.config.ConfigManager.get().chestFilterColor, 1f);
                drawContext.drawText(mc.textRenderer, net.minecraft.text.Text.literal(cf), 12, 10, 0xFFFFFFFF, true);
            }
            com.example.cobbleutility.finder.ChestFilter.renderLabels(drawContext, td);
            Toasts.render(drawContext);
            String aim = com.example.cobbleutility.ballaim.BallAim.statusText();
            if (aim != null) {
                Hud.tag(drawContext, mc.textRenderer, aim, drawContext.getScaledWindowWidth() / 2,
                        drawContext.getScaledWindowHeight() / 2 + 14, 0xFF55FF, 1f);
            }
        });
    }
}
