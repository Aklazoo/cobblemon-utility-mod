package com.example.cobbleutility.structure;

import com.example.cobbleutility.CobblemonUtilityMod;
import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.render.RenderUtil;
import com.example.cobbleutility.util.ColorUtil;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.gen.structure.Structure;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Singleplayer: asks the integrated server directly (same engine as /locate, no cheats needed).
 * Multiplayer: sends "/locate structure ..." (needs permission) and parses the coordinates from the reply.
 */
public final class StructureFinder {
    public record Entry(String query, String name) {}
    public record Waypoint(BlockPos pos, String name, Identifier dim) {}

    /** Fallback list (used on remote servers, where the structure registry is not synced to the client). */
    public static final List<Entry> ENTRIES = List.of(
            new Entry("#minecraft:village", "Village"),
            new Entry("minecraft:pillager_outpost", "Pillager Outpost"),
            new Entry("minecraft:mansion", "Woodland Mansion"),
            new Entry("minecraft:monument", "Ocean Monument"),
            new Entry("minecraft:stronghold", "Stronghold"),
            new Entry("minecraft:ancient_city", "Ancient City"),
            new Entry("minecraft:trial_chambers", "Trial Chambers"),
            new Entry("minecraft:desert_pyramid", "Desert Temple"),
            new Entry("minecraft:jungle_pyramid", "Jungle Temple"),
            new Entry("minecraft:swamp_hut", "Swamp Hut"),
            new Entry("minecraft:igloo", "Igloo"),
            new Entry("#minecraft:shipwreck", "Shipwreck"),
            new Entry("#minecraft:ocean_ruin", "Ocean Ruins"),
            new Entry("#minecraft:mineshaft", "Mineshaft"),
            new Entry("#minecraft:ruined_portal", "Ruined Portal"),
            new Entry("minecraft:trail_ruins", "Trail Ruins"),
            new Entry("minecraft:fortress", "Nether Fortress"),
            new Entry("minecraft:bastion_remnant", "Bastion Remnant"),
            new Entry("minecraft:nether_fossil", "Nether Fossil"),
            new Entry("minecraft:end_city", "End City"));

    /**
     * Singleplayer: every structure registered in the game, modpack structures included
     * (read from the integrated server's registry). Otherwise: the vanilla fallback list.
     */
    public static List<Entry> availableEntries(MinecraftClient mc) {
        IntegratedServer srv = mc.getServer();
        if (srv != null) {
            try {
                Registry<Structure> reg = srv.getRegistryManager().get(RegistryKeys.STRUCTURE);
                List<Entry> list = new ArrayList<>(ENTRIES.stream().filter(e -> e.query().startsWith("#")).toList());
                for (Identifier id : reg.getIds()) list.add(new Entry(id.toString(), pretty(id)));
                list.sort(Comparator
                        .comparing((Entry e) -> !e.query().startsWith("#") && !isVanilla(e.query()) ? 1 : 0)
                        .thenComparing(e -> e.name().toLowerCase(Locale.ROOT)));
                return list;
            } catch (Throwable t) {
                CobblemonUtilityMod.LOGGER.warn("Could not read structure registry", t);
            }
        }
        return ENTRIES;
    }

    public static boolean isVanilla(String query) {
        return query.startsWith("minecraft:") || query.startsWith("#minecraft:");
    }

    private static String pretty(Identifier id) {
        String path = id.getPath().replace('/', ' ').replace('_', ' ').trim();
        StringBuilder sb = new StringBuilder();
        for (String w : path.split(" +")) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        if (!id.getNamespace().equals("minecraft")) sb.append(" [").append(id.getNamespace()).append("]");
        return sb.toString();
    }

    /** Turns what the player typed ("village", "cobblemon:xyz", "#minecraft:village") into a locate query. */
    public static String normalizeQuery(String raw) {
        String q = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
        if (q.isEmpty()) return "";
        boolean tag = q.startsWith("#");
        if (tag) q = q.substring(1);
        if (q.indexOf(':') < 0) q = "minecraft:" + q;
        return (tag ? "#" : "") + q;
    }

    private static final Pattern COORDS = Pattern.compile("\\[(-?\\d+), (?:~|-?\\d+), (-?\\d+)\\]");

    private static Waypoint waypoint;
    private static String pendingName;
    private static Identifier pendingDim;
    private static int pendingTicks;

    private StructureFinder() {}

    public static Waypoint getWaypoint() {
        return waypoint;
    }

    public static void clear() {
        waypoint = null;
    }

    public static void init() {
        WaypointStore.load();
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (pendingName != null && --pendingTicks <= 0) {
                if (mc.player != null) {
                    mc.player.sendMessage(Text.literal("§cNo result for " + pendingName
                            + " (no permission for /locate, or not found)."), true);
                }
                pendingName = null;
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> {
            waypoint = null;
            pendingName = null;
        });
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (pendingName == null || overlay) return;
            Matcher m = COORDS.matcher(message.getString());
            if (m.find()) {
                BlockPos pos = new BlockPos(Integer.parseInt(m.group(1)), 64, Integer.parseInt(m.group(2)));
                setResult(pendingName, pendingDim, pos);
                pendingName = null;
            }
        });
    }

    // ------------------------------------------------------------ locating
    public static void locateTyped(String raw) {
        String q = normalizeQuery(raw);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (q.isEmpty()) {
            if (mc.player != null) mc.player.sendMessage(Text.literal("§cType a structure id first (e.g. minecraft:village)."), true);
            return;
        }
        locate(new Entry(q, q));
    }

    public static void locate(Entry entry) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        mc.player.sendMessage(Text.literal("§7Searching for " + entry.name() + "..."), true);

        Identifier dim = mc.world.getRegistryKey().getValue();
        IntegratedServer srv = mc.getServer();
        if (srv != null) {
            RegistryKey<net.minecraft.world.World> worldKey = mc.world.getRegistryKey();
            BlockPos origin = mc.player.getBlockPos();
            int radius = ConfigManager.get().structureSearchRadius;
            srv.execute(() -> {
                BlockPos found = null;
                try {
                    ServerWorld sw = srv.getWorld(worldKey);
                    if (sw != null) found = search(sw, entry.query(), origin, radius);
                } catch (Throwable t) {
                    CobblemonUtilityMod.LOGGER.warn("Structure search failed", t);
                }
                BlockPos result = found;
                mc.execute(() -> setResult(entry.name(), dim, result));
            });
        } else {
            pendingName = entry.name();
            pendingDim = dim;
            pendingTicks = 400;
            mc.player.networkHandler.sendChatCommand("locate structure " + entry.query());
        }
    }

    private static BlockPos search(ServerWorld sw, String query, BlockPos origin, int radius) {
        Registry<Structure> reg = sw.getRegistryManager().get(RegistryKeys.STRUCTURE);
        RegistryEntryList<Structure> list = null;
        if (query.startsWith("#")) {
            TagKey<Structure> tag = TagKey.of(RegistryKeys.STRUCTURE, Identifier.of(query.substring(1)));
            Optional<RegistryEntryList.Named<Structure>> named = reg.getEntryList(tag);
            if (named.isPresent()) list = named.get();
        } else {
            Optional<RegistryEntry.Reference<Structure>> ref =
                    reg.getEntry(RegistryKey.of(RegistryKeys.STRUCTURE, Identifier.of(query)));
            if (ref.isPresent()) list = RegistryEntryList.of(List.of(ref.get()));
        }
        if (list == null) return null;
        Pair<BlockPos, RegistryEntry<Structure>> pair =
                sw.getChunkManager().getChunkGenerator().locateStructure(sw, list, origin, radius, false);
        return pair == null ? null : pair.getFirst();
    }

    private static void setResult(String name, Identifier dim, BlockPos pos) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (pos == null) {
            mc.player.sendMessage(Text.literal("§c" + name + " not found nearby."), true);
            return;
        }
        waypoint = new Waypoint(pos, name, dim);
        mc.player.sendMessage(Text.literal("§b" + name + " §7at §f" + pos.getX() + ", " + pos.getZ()), true);
        if (ConfigManager.get().structureAutoSave) {
            WaypointStore.add(name, pos.getX(), pos.getZ(), dim.toString());
        }
    }

    /** Starts tracking a saved waypoint. */
    public static void track(WaypointStore.Saved s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            waypoint = new Waypoint(new BlockPos(s.x, 64, s.z), s.name, Identifier.of(s.dim));
            if (mc.player != null) {
                mc.player.sendMessage(Text.literal("§bTracking " + s.name + " §7at §f" + s.x + ", " + s.z), true);
            }
        } catch (Exception e) {
            CobblemonUtilityMod.LOGGER.warn("Bad saved waypoint", e);
        }
    }

    // ------------------------------------------------------------ world rendering
    public static void renderWorld(MatrixStack ms, Vec3d cam, Camera camera) {
        ModConfig cfg = ConfigManager.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        Waypoint wp = waypoint;
        if (wp == null || !cfg.structureAutoPathLine || mc.world == null) return;
        if (!mc.world.getRegistryKey().getValue().equals(wp.dim())) return;

        double dx = wp.pos().getX() + 0.5 - cam.x;
        double dz = wp.pos().getZ() + 0.5 - cam.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < 1.5) return;

        int argb = ColorUtil.opaque(cfg.structureColor);
        double scale = Math.min(1.0, 64.0 / dist);
        double ex = dx * scale, ez = dz * scale, ey = -1.0;
        Vec3d look = Vec3d.fromPolar(camera.getPitch(), camera.getYaw()).multiply(0.4);

        MatrixStack.Entry entry = ms.peek();
        BufferBuilder b = RenderUtil.beginLines(2.5f);
        RenderUtil.line(b, entry, look.x, look.y - 0.2, look.z, ex, ey, ez, argb);
        double size = 0.5 + Math.sqrt(ex * ex + ez * ez) * 0.02;
        RenderUtil.diamond(b, entry, ex, ey, ez, size, argb);
        if (dist <= 256) { // vertical beam at the real location
            RenderUtil.line(b, entry, dx, -64 - cam.y, dz, dx, 320 - cam.y, dz, argb);
        }
        RenderUtil.end(b);
    }

    // ------------------------------------------------------------ HUD
    public static void renderHud(DrawContext ctx, float td) {
        ModConfig cfg = ConfigManager.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        Waypoint wp = waypoint;
        if (wp == null || mc.player == null || mc.world == null) return;
        if (!mc.world.getRegistryKey().getValue().equals(wp.dim())) return;

        TextRenderer tr = mc.textRenderer;
        int color = ColorUtil.opaque(cfg.structureColor);
        double dx = wp.pos().getX() + 0.5 - mc.player.getX();
        double dz = wp.pos().getZ() + 0.5 - mc.player.getZ();
        int dist = (int) Math.sqrt(dx * dx + dz * dz);
        String label = wp.name() + " - " + dist + "m";
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();

        if (cfg.structureAutoPathLine) {
            Camera cam = mc.gameRenderer.getCamera();
            Vec3d target = new Vec3d(wp.pos().getX() + 0.5, mc.player.getEyeY(), wp.pos().getZ() + 0.5);
            float[] s = RenderUtil.project(target, cam, sw, sh, mc.options.getFov().getValue(), 60, 24);
            ctx.drawCenteredTextWithShadow(tr, Text.literal("◆ " + label), (int) s[0], (int) s[1], color);
        } else {
            // simple directional compass bar
            float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            float rel = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
            int half = 90, cx = sw / 2, y = 30;
            ctx.fill(cx - half, y, cx + half, y + 1, 0x90FFFFFF);
            ctx.fill(cx - 1, y - 3, cx + 1, y + 4, 0xC0FFFFFF);
            int ax = cx + Math.round(MathHelper.clamp(rel / 90f, -1f, 1f) * half);
            ctx.drawCenteredTextWithShadow(tr, Text.literal("▼"), ax, y - 11, color);
            ctx.drawCenteredTextWithShadow(tr, Text.literal(label), cx, y + 8, color);
        }
    }
}
