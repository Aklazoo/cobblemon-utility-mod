package com.example.cobbleutility.structure;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.List;

/** Saved waypoints: click one to track it, or delete it. */
public class WaypointsScreen extends Screen {
    private static final int PER_PAGE = 7;

    private final Screen parent;
    private int page = 0;

    public WaypointsScreen(Screen parent) {
        super(Text.literal("Saved waypoints"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        MinecraftClient mc = MinecraftClient.getInstance();
        List<WaypointStore.Saved> list = WaypointStore.list();
        int maxPage = Math.max(0, (list.size() - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, maxPage));

        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < list.size(); i++) {
            WaypointStore.Saved s = list.get(start + i);
            int y = 44 + i * 24;
            String dimShort = s.dim.contains(":") ? s.dim.substring(s.dim.indexOf(':') + 1) : s.dim;
            String label = textRenderer.trimToWidth(s.name + "  (" + s.x + ", " + s.z + ")  [" + dimShort + "]", 258);
            addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> {
                StructureFinder.track(s);
                close();
            }).dimensions(width / 2 - 170, y, 268, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Delete"), b -> {
                WaypointStore.remove(s);
                clearAndInit();
            }).dimensions(width / 2 + 102, y, 68, 20).build());
        }

        int by = height - 28;
        ButtonWidget prev = addDrawableChild(ButtonWidget.builder(Text.literal("< Prev"), b -> {
            page--;
            clearAndInit();
        }).dimensions(width / 2 - 170, by, 54, 20).build());
        prev.active = page > 0;
        ButtonWidget next = addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), b -> {
            page++;
            clearAndInit();
        }).dimensions(width / 2 - 112, by, 54, 20).build());
        next.active = page < maxPage;
        addDrawableChild(ButtonWidget.builder(Text.literal("Save my position"), b -> {
            if (mc.player != null && mc.world != null) {
                int x = (int) mc.player.getX(), z = (int) mc.player.getZ();
                WaypointStore.add("Position " + x + "," + z, x, z, mc.world.getRegistryKey().getValue().toString());
                clearAndInit();
            }
        }).dimensions(width / 2 - 54, by, 120, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
                .dimensions(width / 2 + 70, by, 100, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFFFF);
        int n = WaypointStore.list().size();
        String sub = n == 0 ? "Nothing saved yet - located structures are saved here automatically"
                : n + " saved - click to track";
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(sub), width / 2, 28, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }
}
