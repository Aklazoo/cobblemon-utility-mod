package com.example.cobbleutility.esp;

import com.example.cobbleutility.CobblemonUtilityMod;
import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.inventory.Inventory;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * The client cannot see loot tables, so a container's state is learned from what you do:
 *  UNOPENED - never opened;
 *  PARTIAL  - you opened it and closed it while items were still inside (loot left!);
 *  EMPTY    - opened and emptied (or marked by hand).
 * Stored per world / server in config/cobblemon_utility_mod_opened.json and ..._partial.json.
 */
public final class OpenedContainers {
    public enum State { UNOPENED, PARTIAL, EMPTY }

    private static final class Store {
        final Path file;
        Map<String, Map<String, Set<Long>>> data = new HashMap<>();
        boolean dirty;

        Store(String name) {
            file = FabricLoader.getInstance().getConfigDir().resolve(name);
        }

        void load() {
            try {
                if (Files.exists(file)) {
                    Map<String, Map<String, Set<Long>>> read =
                            GSON.fromJson(Files.readString(file, StandardCharsets.UTF_8), TYPE);
                    if (read != null) data = read;
                }
            } catch (Exception e) {
                CobblemonUtilityMod.LOGGER.warn("Could not read " + file.getFileName(), e);
            }
        }

        void save() {
            if (!dirty) return;
            try {
                Files.writeString(file, GSON.toJson(data, TYPE), StandardCharsets.UTF_8);
                dirty = false;
            } catch (Exception e) {
                CobblemonUtilityMod.LOGGER.warn("Could not save " + file.getFileName(), e);
            }
        }

        boolean has(String wk, Identifier dim, long pos) {
            Map<String, Set<Long>> perDim = data.get(wk);
            if (perDim == null) return false;
            Set<Long> set = perDim.get(dim.toString());
            return set != null && set.contains(pos);
        }

        void set(String wk, Identifier dim, long pos, boolean on) {
            if (on) {
                data.computeIfAbsent(wk, k -> new HashMap<>())
                        .computeIfAbsent(dim.toString(), k -> new HashSet<>()).add(pos);
            } else {
                Map<String, Set<Long>> m = data.get(wk);
                if (m != null) {
                    Set<Long> set = m.get(dim.toString());
                    if (set != null) set.remove(pos);
                }
            }
            dirty = true;
        }

        void clearWorld(String wk) {
            data.remove(wk);
            dirty = true;
        }
    }

    private static final Gson GSON = new Gson();
    private static final Type TYPE = new TypeToken<Map<String, Map<String, Set<Long>>>>() {}.getType();
    private static final Store OPENED = new Store("cobblemon_utility_mod_opened.json");
    private static final Store PARTIAL = new Store("cobblemon_utility_mod_partial.json");

    private static String worldKey = "unknown";
    private static int tick;

    // leftover observation
    private static BlockPos usedPos;
    private static BlockState usedState;
    private static Identifier usedDim;
    private static int sinceUse = 9999;
    private static int openTicks;
    private static boolean sawItems;
    private static boolean ignoreScreen;
    private static Boolean lastEmpty;

    private OpenedContainers() {}

    public static String worldKey() {
        return worldKey;
    }

    public static void init() {
        OPENED.load();
        PARTIAL.load();
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> worldKey = computeKey(client));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> saveAll());
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (++tick % 1200 == 0) saveAll();
            observe(mc);
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.isClient || !ConfigManager.get().chestAutoMarkOpened) return ActionResult.PASS;
            if (player.isSneaking() && !player.getMainHandStack().isEmpty()) return ActionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            BlockEntity be = world.getBlockEntity(pos);
            if (be == null || !ContainerEsp.isContainer(ContainerEsp.kindOf(be))) return ActionResult.PASS;

            Identifier dim = world.getRegistryKey().getValue();
            applyOpened(dim, pos, be.getCachedState(), true);
            usedPos = pos;
            usedState = be.getCachedState();
            usedDim = dim;
            sinceUse = 0;
            return ActionResult.PASS;
        });
    }

    // ------------------------------------------------------------ queries
    public static State stateOf(Identifier dim, long posKey) {
        if (PARTIAL.has(worldKey, dim, posKey)) return State.PARTIAL;
        if (OPENED.has(worldKey, dim, posKey)) return State.EMPTY;
        return State.UNOPENED;
    }

    // ------------------------------------------------------------ edits
    private static BlockPos partner(BlockPos pos, BlockState st) {
        if (st != null && st.contains(ChestBlock.CHEST_TYPE) && st.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
            return pos.offset(ChestBlock.getFacing(st));
        }
        return null;
    }

    private static void applyOpened(Identifier dim, BlockPos pos, BlockState st, boolean opened) {
        OPENED.set(worldKey, dim, pos.asLong(), opened);
        BlockPos other = partner(pos, st);
        if (other != null) OPENED.set(worldKey, dim, other.asLong(), opened);
        if (!opened) {
            PARTIAL.set(worldKey, dim, pos.asLong(), false);
            if (other != null) PARTIAL.set(worldKey, dim, other.asLong(), false);
        }
        ContainerEsp.rescanSoon();
    }

    private static void commitLeftover(boolean empty) {
        if (usedPos == null || usedDim == null) return;
        PARTIAL.set(worldKey, usedDim, usedPos.asLong(), !empty);
        BlockPos other = partner(usedPos, usedState);
        if (other != null) PARTIAL.set(worldKey, usedDim, other.asLong(), !empty);
        ContainerEsp.rescanSoon();
    }

    /** Key action: flips a container between "unopened" and "looted" (clears any leftover mark). */
    public static void toggleLookedAt(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            mc.player.sendMessage(Text.literal("§cLook at a container first."), true);
            return;
        }
        BlockPos pos = hit.getBlockPos();
        BlockEntity be = mc.world.getBlockEntity(pos);
        if (be == null || !ContainerEsp.isContainer(ContainerEsp.kindOf(be))) {
            mc.player.sendMessage(Text.literal("§cThat is not a tracked container."), true);
            return;
        }
        Identifier dim = mc.world.getRegistryKey().getValue();
        boolean nowLooted = stateOf(dim, pos.asLong()) == State.UNOPENED;
        applyOpened(dim, pos, be.getCachedState(), nowLooted);
        mc.player.sendMessage(Text.literal(nowLooted ? "§7Marked as looted" : "§aMarked as unopened"), true);
    }

    /** Forgets everything known about containers in the current world / server. */
    public static void clearCurrentWorld() {
        OPENED.clearWorld(worldKey);
        PARTIAL.clearWorld(worldKey);
        saveAll();
        ContainerEsp.rescanSoon();
    }

    // ------------------------------------------------------------ leftover observation
    private static void observe(MinecraftClient mc) {
        sinceUse++;
        ModConfig cfg = ConfigManager.get();
        if (mc.player != null && cfg.chestTrackLeftovers && mc.currentScreen instanceof HandledScreen<?> hs) {
            if (openTicks == 0) {
                ignoreScreen = usedPos == null || sinceUse > 80 || hs.getScreenHandler() instanceof PlayerScreenHandler;
                sawItems = false;
                lastEmpty = null;
            }
            openTicks++;
            if (!ignoreScreen) {
                Boolean empty = containerEmpty(hs.getScreenHandler(), mc);
                if (empty != null) {
                    if (!empty) sawItems = true;
                    // wait until the server synced the contents (items seen, or 15 ticks elapsed)
                    if (sawItems || openTicks >= 15) lastEmpty = empty;
                }
            }
        } else if (openTicks > 0) {
            if (!ignoreScreen && lastEmpty != null) commitLeftover(lastEmpty);
            openTicks = 0;
            sawItems = false;
            ignoreScreen = false;
            lastEmpty = null;
            usedPos = null;
        }
    }

    /** null = no container slots found; true = all container slots empty. */
    private static Boolean containerEmpty(ScreenHandler handler, MinecraftClient mc) {
        try {
            Inventory playerInv = mc.player.getInventory();
            int total = 0, filled = 0;
            for (Slot slot : handler.slots) {
                if (slot.inventory == playerInv) continue;
                total++;
                if (!slot.getStack().isEmpty()) filled++;
            }
            return total == 0 ? null : filled == 0;
        } catch (Throwable t) {
            return null;
        }
    }

    // ------------------------------------------------------------ persistence
    private static void saveAll() {
        OPENED.save();
        PARTIAL.save();
    }

    private static String computeKey(MinecraftClient mc) {
        try {
            if (mc.getServer() != null) {
                return "sp:" + mc.getServer().getSaveProperties().getLevelName();
            }
            if (mc.getCurrentServerEntry() != null) {
                return "mp:" + mc.getCurrentServerEntry().address;
            }
        } catch (Throwable ignored) {
        }
        return "unknown";
    }
}
