package com.example.cobbleutility.shiny;

import com.example.cobbleutility.CobblemonUtilityMod;
import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Local shiny-odds multiplier.
 *
 * In singleplayer / LAN the game server runs inside this same game, so we can temporarily lower
 * Cobblemon's in-memory "shinyRate" (the N in 1/N). It is never written to disk by this mod and is
 * restored when you leave the world, switch to a remote server, or close the game.
 * All Cobblemon access is reflective: if the setting is not found the boost simply stays inactive.
 */
public final class ShinyBoost {
    private static Float original;   // value before we touched it
    private static Float applied;    // value we set
    private static boolean warned;
    private static int tick;

    private ShinyBoost() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(ShinyBoost::onTick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> restore(client, false));
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> restore(client, false));
    }

    private static void onTick(MinecraftClient mc) {
        if (++tick % 20 != 0) return;
        ModConfig cfg = ConfigManager.get();
        boolean should = cfg.shinyBoostEnabled && mc.world != null && mc.player != null && mc.getServer() != null;
        if (!should) {
            if (applied != null) restore(mc, true);
            return;
        }

        Object config = cobblemonConfig();
        if (config == null) {
            warnOnce(mc, "Cobblemon not found: shiny boost unavailable.");
            return;
        }
        Float current = readRate(config);
        if (current == null || current <= 0f) {
            warnOnce(mc, "Could not read Cobblemon's shiny rate: shiny boost unavailable.");
            return;
        }

        // If the current value is not the one we set, it is the new "real" base (config reload etc.)
        boolean firstTime = applied == null;
        if (firstTime || Math.abs(current - applied) > 0.01f) original = current;

        float target = Math.max(1f, original / Math.max(1, cfg.shinyMultiplier));
        if (firstTime || Math.abs(current - target) > 0.01f) {
            if (!writeRate(config, target)) {
                warnOnce(mc, "Could not change Cobblemon's shiny rate: shiny boost unavailable.");
                original = null;
                applied = null;
                return;
            }
            applied = target;
            if (cfg.shinyBoostNotify) {
                mc.player.sendMessage(Text.literal("§6[Shiny Boost] §fshiny odds 1/" + Math.round(original)
                        + " §7->§f 1/" + Math.round(target) + " §7(x" + cfg.shinyMultiplier + ")"), false);
            }
        }
    }

    private static void restore(MinecraftClient mc, boolean notify) {
        if (original != null && applied != null) {
            Object config = cobblemonConfig();
            if (config != null) {
                Float current = readRate(config);
                if (current != null && Math.abs(current - applied) < 0.01f) writeRate(config, original);
            }
            if (notify && mc.player != null && ConfigManager.get().shinyBoostNotify) {
                mc.player.sendMessage(Text.literal("§6[Shiny Boost] §7removed, odds back to 1/" + Math.round(original)), false);
            }
        }
        original = null;
        applied = null;
    }

    private static void warnOnce(MinecraftClient mc, String msg) {
        if (warned) return;
        warned = true;
        CobblemonUtilityMod.LOGGER.warn(msg);
        if (mc.player != null) mc.player.sendMessage(Text.literal("§c[Shiny Boost] " + msg), false);
    }

    // ------------------------------------------------------------ reflection
    private static Object cobblemonConfig() {
        if (!FabricLoader.getInstance().isModLoaded("cobblemon")) return null;
        try {
            Class<?> cls = Class.forName("com.cobblemon.mod.common.Cobblemon", true, ShinyBoost.class.getClassLoader());
            Object instance = cls.getField("INSTANCE").get(null);
            Method getter = cls.getMethod("getConfig");
            return getter.invoke(instance);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Float readRate(Object config) {
        try {
            for (Method m : config.getClass().getMethods()) {
                if (m.getName().equals("getShinyRate") && m.getParameterCount() == 0) {
                    Object v = m.invoke(config);
                    if (v instanceof Number n) return n.floatValue();
                }
            }
            Field f = findField(config.getClass(), "shinyRate");
            if (f != null) {
                Object v = f.get(config);
                if (v instanceof Number n) return n.floatValue();
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static boolean writeRate(Object config, float value) {
        try {
            for (Method m : config.getClass().getMethods()) {
                if (m.getName().equals("setShinyRate") && m.getParameterCount() == 1) {
                    Class<?> t = m.getParameterTypes()[0];
                    if (t == float.class || t == Float.class) m.invoke(config, value);
                    else if (t == double.class || t == Double.class) m.invoke(config, (double) value);
                    else continue;
                    return true;
                }
            }
            Field f = findField(config.getClass(), "shinyRate");
            if (f != null) {
                if (f.getType() == double.class) f.setDouble(config, value); else f.setFloat(config, value);
                return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static Field findField(Class<?> cls, String name) {
        for (Class<?> c = cls; c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {
            }
        }
        return null;
    }
}
