package com.example.cobbleutility.render;

import com.example.cobbleutility.esp.ContainerEsp;
import com.example.cobbleutility.radar.RadarManager;
import com.example.cobbleutility.structure.StructureFinder;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

/** Single registration point for all per-frame drawing. Everything reads ModConfig live. */
public final class Overlay {
    private Overlay() {}

    public static void init() {
        WorldRenderEvents.LAST.register(ctx -> {
            MatrixStack ms = ctx.matrixStack();
            if (ms == null) return;
            Vec3d cam = ctx.camera().getPos();
            float td = ctx.tickCounter().getTickDelta(false);
            ContainerEsp.render(ms, cam, ctx.camera());
            RadarManager.renderWorld(ms, cam, td, ctx.camera());
            StructureFinder.renderWorld(ms, cam, ctx.camera());
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden || mc.player == null) return;
            float td = tickCounter.getTickDelta(false);
            RadarManager.renderHud(drawContext, td);
            StructureFinder.renderHud(drawContext, td);
        });
    }
}
