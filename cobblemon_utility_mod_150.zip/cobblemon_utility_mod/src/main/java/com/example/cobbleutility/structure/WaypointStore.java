package com.example.cobbleutility.structure;

import com.example.cobbleutility.CobblemonUtilityMod;
import com.example.cobbleutility.esp.OpenedContainers;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Saved waypoints, kept per world / server in config/cobblemon_utility_mod_waypoints.json. */
public final class WaypointStore {
    public static final class Saved {
        public String name;
        public int x;
        public int z;
        public String dim;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type TYPE = new TypeToken<Map<String, List<Saved>>>() {}.getType();
    private static final Path FILE =
            FabricLoader.getInstance().getConfigDir().resolve("cobblemon_utility_mod_waypoints.json");
    private static final int MAX = 200;

    private static Map<String, List<Saved>> data = new HashMap<>();

    private WaypointStore() {}

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                Map<String, List<Saved>> read = GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), TYPE);
                if (read != null) data = read;
            }
        } catch (Exception e) {
            CobblemonUtilityMod.LOGGER.warn("Could not read waypoints file", e);
        }
    }

    private static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(data, TYPE), StandardCharsets.UTF_8);
        } catch (Exception e) {
            CobblemonUtilityMod.LOGGER.warn("Could not save waypoints file", e);
        }
    }

    public static List<Saved> list() {
        return data.computeIfAbsent(OpenedContainers.worldKey(), k -> new ArrayList<>());
    }

    public static void add(String name, int x, int z, String dim) {
        List<Saved> l = list();
        for (Saved s : l) {
            if (s.dim.equals(dim) && s.name.equals(name) && Math.abs(s.x - x) < 8 && Math.abs(s.z - z) < 8) return;
        }
        if (l.size() >= MAX) l.remove(0);
        Saved s = new Saved();
        s.name = name;
        s.x = x;
        s.z = z;
        s.dim = dim;
        l.add(s);
        save();
    }

    public static void remove(Saved s) {
        list().remove(s);
        save();
    }
}
