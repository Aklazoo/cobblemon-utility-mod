package com.example.cobbleutility.structure;

import com.example.cobbleutility.config.ConfigScreenBuilder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Search box + paged list of every structure (modpack structures included in singleplayer). */
public class StructureFinderScreen extends Screen {
    private static final String[] SOURCES = {"All", "Modded only", "Vanilla only"};

    private final Screen parent;
    private List<StructureFinder.Entry> all = List.of();
    private final List<StructureFinder.Entry> filtered = new ArrayList<>();
    private final List<ButtonWidget> grid = new ArrayList<>();
    private TextFieldWidget search;
    private ButtonWidget prevBtn, nextBtn, sourceBtn;
    private int page = 0;
    private int source = 0;
    private String keepText = "";

    private static final int COLS = 2, CELL_W = 170, CELL_H = 20, GAP = 4, GRID_TOP = 62;

    public StructureFinderScreen(Screen parent) {
        super(Text.literal("Structure Finder"));
        this.parent = parent;
    }

    private int rows() {
        return Math.max(3, Math.min(8, (height - GRID_TOP - 64) / (CELL_H + GAP)));
    }

    @Override
    protected void init() {
        MinecraftClient mc = MinecraftClient.getInstance();
        all = StructureFinder.availableEntries(mc);

        search = new TextFieldWidget(textRenderer, width / 2 - 170, 34, 230, 20, Text.literal("Search"));
        search.setMaxLength(120);
        search.setPlaceholder(Text.literal("Search, or type an id (e.g. cobblemon:xyz)"));
        search.setText(keepText);
        search.setChangedListener(s -> {
            keepText = s;
            page = 0;
            applyFilter();
        });
        addDrawableChild(search);
        setInitialFocus(search);

        sourceBtn = addDrawableChild(ButtonWidget.builder(Text.literal(SOURCES[source]), b -> {
            source = (source + 1) % SOURCES.length;
            b.setMessage(Text.literal(SOURCES[source]));
            page = 0;
            applyFilter();
        }).dimensions(width / 2 + 66, 34, 104, 20).build());

        int rowA = height - 52, rowB = height - 28;
        prevBtn = addDrawableChild(ButtonWidget.builder(Text.literal("< Prev"), b -> {
            page--;
            rebuildGrid();
        }).dimensions(width / 2 - 170, rowA, 54, 20).build());
        nextBtn = addDrawableChild(ButtonWidget.builder(Text.literal("Next >"), b -> {
            page++;
            rebuildGrid();
        }).dimensions(width / 2 - 112, rowA, 54, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Locate typed id"), b -> {
            StructureFinder.locateTyped(search.getText());
            close();
        }).dimensions(width / 2 - 54, rowA, 120, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Saved (" + WaypointStore.list().size() + ")"),
                        b -> MinecraftClient.getInstance().setScreen(new WaypointsScreen(this)))
                .dimensions(width / 2 + 70, rowA, 100, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Clear waypoint"), b -> StructureFinder.clear())
                .dimensions(width / 2 - 170, rowB, 108, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Settings"),
                        b -> MinecraftClient.getInstance().setScreen(ConfigScreenBuilder.create(this)))
                .dimensions(width / 2 - 54, rowB, 108, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(width / 2 + 62, rowB, 108, 20).build());

        grid.clear();
        applyFilter();
    }

    private void applyFilter() {
        String q = search == null ? "" : search.getText().toLowerCase(Locale.ROOT).trim();
        filtered.clear();
        for (StructureFinder.Entry e : all) {
            boolean vanilla = StructureFinder.isVanilla(e.query());
            if (source == 1 && vanilla) continue;
            if (source == 2 && !vanilla) continue;
            if (q.isEmpty() || e.query().toLowerCase(Locale.ROOT).contains(q)
                    || e.name().toLowerCase(Locale.ROOT).contains(q)) {
                filtered.add(e);
            }
        }
        rebuildGrid();
    }

    private void rebuildGrid() {
        for (ButtonWidget b : grid) remove(b);
        grid.clear();

        int perPage = COLS * rows();
        int maxPage = Math.max(0, (filtered.size() - 1) / perPage);
        page = Math.max(0, Math.min(page, maxPage));

        int total = COLS * CELL_W + (COLS - 1) * GAP;
        int x0 = (width - total) / 2;
        int start = page * perPage;
        for (int i = 0; i < perPage && start + i < filtered.size(); i++) {
            StructureFinder.Entry entry = filtered.get(start + i);
            int x = x0 + (i % COLS) * (CELL_W + GAP);
            int y = GRID_TOP + (i / COLS) * (CELL_H + GAP);
            String label = textRenderer.trimToWidth(entry.name(), CELL_W - 10);
            ButtonWidget btn = ButtonWidget.builder(Text.literal(label), b -> {
                StructureFinder.locate(entry);
                close();
            }).dimensions(x, y, CELL_W, CELL_H).tooltip(Tooltip.of(Text.literal(entry.query()))).build();
            grid.add(addDrawableChild(btn));
        }
        if (prevBtn != null) prevBtn.active = page > 0;
        if (nextBtn != null) nextBtn.active = page < maxPage;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 10, 0xFFFFFFFF);
        StructureFinder.Waypoint wp = StructureFinder.getWaypoint();
        String sub = wp == null ? "Pick a structure to track" : "Tracking: " + wp.name();
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(sub), width / 2, 22, 0xFFAAAAAA);

        int perPage = COLS * rows();
        int maxPage = Math.max(0, (filtered.size() - 1) / perPage);
        String info = filtered.size() + " results - page " + (page + 1) + "/" + (maxPage + 1);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(info), width / 2, height - 66, 0xFF888888);
        if (MinecraftClient.getInstance().getServer() == null) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Remote server: only vanilla list. Type any modded id and use 'Locate typed id'."),
                    width / 2, 52, 0xFFFFAA55);
        }
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }
}
