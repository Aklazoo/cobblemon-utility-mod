package com.example.cobbleutility.util;

public final class ColorUtil {
    private ColorUtil() {}

    public static int argb(int rgb, int alpha) {
        return ((alpha & 0xFF) << 24) | (rgb & 0xFFFFFF);
    }

    public static int opaque(int rgb) {
        return argb(rgb, 255);
    }
}
