package com.example.cobbleutility.config;

import dev.isxander.yacl3.api.NameableEnum;
import net.minecraft.text.Text;

public enum RenderStyle implements NameableEnum {
    TRACERS("Tracer lines"),
    HUD_WAYPOINTS("2D HUD waypoints"),
    BOXES("3D bounding boxes"),
    ALL("All");

    private final String label;

    RenderStyle(String label) {
        this.label = label;
    }

    @Override
    public Text getDisplayName() {
        return Text.literal(label);
    }
}
