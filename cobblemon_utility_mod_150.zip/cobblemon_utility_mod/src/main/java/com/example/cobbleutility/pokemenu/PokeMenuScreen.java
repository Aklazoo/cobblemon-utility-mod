package com.example.cobbleutility.pokemenu;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ConfigScreenBuilder;
import com.example.cobbleutility.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Builds /givepokemon and /spawnpokemon commands and sends them as the player.
 * The server decides: you need operator rights (or cheats in singleplayer).
 * Species names are Cobblemon names in lowercase without spaces (e.g. mrmime, hooh).
 */
public class PokeMenuScreen extends Screen {
    private static final String[] LEGENDARIES = {
            "articuno", "zapdos", "moltres", "mewtwo", "mew", "raikou", "entei", "suicune", "lugia", "hooh",
            "celebi", "regirock", "regice", "registeel", "latias", "latios", "kyogre", "groudon", "rayquaza",
            "jirachi", "deoxys", "dialga", "palkia", "giratina", "darkrai", "arceus", "reshiram", "zekrom",
            "kyurem", "victini", "keldeo", "meloetta", "genesect", "xerneas", "yveltal", "zygarde", "diancie",
            "solgaleo", "lunala", "necrozma", "marshadow", "zacian", "zamazenta", "eternatus", "calyrex",
            "koraidon", "miraidon"};

    private final Screen parent;
    private TextFieldWidget species, level, extra;
    private boolean shiny;
    private int legPage = 0;
    private final List<ButtonWidget> legButtons = new ArrayList<>();
    private ButtonWidget shinyBtn;

    private static final int LEG_COLS = 6, LEG_ROWS = 3;

    public PokeMenuScreen(Screen parent) {
        super(Text.literal("Pokémon Menu"));
        this.parent = parent;
        this.shiny = ConfigManager.get().pokeDefaultShiny;
    }

    @Override
    protected void init() {
        ModConfig cfg = ConfigManager.get();
        int cx = width / 2;

        species = new TextFieldWidget(textRenderer, cx - 160, 40, 150, 20, Text.literal("Species"));
        species.setPlaceholder(Text.literal("species (e.g. eevee)"));
        species.setMaxLength(40);
        addDrawableChild(species);
        level = new TextFieldWidget(textRenderer, cx - 4, 40, 40, 20, Text.literal("Level"));
        level.setText(String.valueOf(cfg.pokeDefaultLevel));
        level.setMaxLength(3);
        addDrawableChild(level);
        shinyBtn = addDrawableChild(ButtonWidget.builder(shinyLabel(), b -> {
            shiny = !shiny;
            b.setMessage(shinyLabel());
        }).dimensions(cx + 42, 40, 118, 20).build());

        extra = new TextFieldWidget(textRenderer, cx - 160, 66, 320, 20, Text.literal("Extra"));
        extra.setPlaceholder(Text.literal("extra properties (optional), e.g. ability=synchronize"));
        extra.setMaxLength(200);
        extra.setText(cfg.pokeExtraProps);
        addDrawableChild(extra);
        setInitialFocus(species);

        addDrawableChild(ButtonWidget.builder(Text.literal("Give to me"), b -> send("givepokemon"))
                .dimensions(cx - 160, 92, 158, 20).tooltip(Tooltip.of(Text.literal("/givepokemon ..."))).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Spawn here"), b -> send("spawnpokemon"))
                .dimensions(cx + 2, 92, 158, 20).tooltip(Tooltip.of(Text.literal("/spawnpokemon ..."))).build());

        buildLegendaries();
        buildCustom();

        int by = height - 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("Settings"),
                        b -> MinecraftClient.getInstance().setScreen(ConfigScreenBuilder.create(this)))
                .dimensions(cx - 104, by, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(cx + 4, by, 100, 20).build());
    }

    private Text shinyLabel() {
        return Text.literal("Shiny: " + (shiny ? "§aYES" : "§7no"));
    }

    private void buildLegendaries() {
        for (ButtonWidget b : legButtons) remove(b);
        legButtons.clear();
        int cx = width / 2;
        int per = LEG_COLS * LEG_ROWS;
        int maxPage = (LEGENDARIES.length - 1) / per;
        legPage = Math.max(0, Math.min(legPage, maxPage));
        int w = 52, gap = 2, total = LEG_COLS * w + (LEG_COLS - 1) * gap;
        int x0 = cx - total / 2, y0 = 134;
        for (int i = 0; i < per && legPage * per + i < LEGENDARIES.length; i++) {
            String name = LEGENDARIES[legPage * per + i];
            int x = x0 + (i % LEG_COLS) * (w + gap), y = y0 + (i / LEG_COLS) * 22;
            ButtonWidget btn = ButtonWidget.builder(Text.literal(textRenderer.trimToWidth(name, w - 6)),
                    b -> species.setText(name)).dimensions(x, y, w, 20).build();
            legButtons.add(addDrawableChild(btn));
        }
        int py = y0 + LEG_ROWS * 22;
        legButtons.add(addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
            legPage--;
            buildLegendaries();
        }).dimensions(cx - 60, py, 28, 18).build()));
        legButtons.add(addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
            legPage++;
            buildLegendaries();
        }).dimensions(cx + 32, py, 28, 18).build()));
    }

    private void buildCustom() {
        String raw = ConfigManager.get().pokeCustomCommands;
        if (raw == null || raw.isBlank()) return;
        int cx = width / 2, x0 = cx - 160, y = 134 + LEG_ROWS * 22 + 28, i = 0;
        for (String part : raw.split(";;")) {
            int eq = part.indexOf('=');
            if (eq <= 0) continue;
            String label = part.substring(0, eq).trim();
            String cmd = part.substring(eq + 1).trim();
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            if (label.isEmpty() || cmd.isEmpty()) continue;
            final String command = cmd;
            int col = i % 3, row = i / 3;
            int yy = y + row * 22;
            if (yy > height - 56) break;
            addDrawableChild(ButtonWidget.builder(Text.literal(textRenderer.trimToWidth(label, 98)),
                            b -> run(command)).dimensions(x0 + col * 108, yy, 104, 20)
                    .tooltip(Tooltip.of(Text.literal("/" + command))).build());
            i++;
        }
    }

    private void send(String base) {
        String sp = species.getText().trim().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_:\\-]", "");
        if (sp.isEmpty()) {
            msg("§cType or pick a species first.");
            return;
        }
        int lvl = 50;
        try {
            lvl = Math.max(1, Math.min(100, Integer.parseInt(level.getText().trim())));
        } catch (NumberFormatException ignored) {
        }
        StringBuilder sb = new StringBuilder(base).append(' ').append(sp).append(" level=").append(lvl);
        if (shiny) sb.append(" shiny");
        String ex = extra.getText().trim();
        if (!ex.isEmpty()) sb.append(' ').append(ex);
        run(sb.toString());
    }

    private void run(String command) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.player.networkHandler == null) return;
        mc.player.networkHandler.sendChatCommand(command);
        msg("§7/" + command);
    }

    private void msg(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal(s), true);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 10, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Needs operator rights (your server) or cheats in singleplayer"), width / 2, 24, 0xFFAAAAAA);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Legendaries (click to fill the species)"),
                width / 2, 122, 0xFFAAAAAA);
        String raw = ConfigManager.get().pokeCustomCommands;
        if (raw != null && !raw.isBlank()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Your commands"), width / 2,
                    134 + LEG_ROWS * 22 + 18, 0xFFAAAAAA);
        }
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }
}
