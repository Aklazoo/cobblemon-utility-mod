package com.example.cobbleutility.finder;

import com.example.cobbleutility.config.ConfigScreenBuilder;
import com.example.cobbleutility.net.ServerLink;
import com.example.cobbleutility.structure.StructureFinder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Type an item (e.g. "golden fossil" or "cobblemon:...") and see which containers hold it. */
public class ChestFilterScreen extends Screen {
    static String lastText = "";
    private static final String[] QUICK = {"fossil", "ball", "apricorn", "evolution", "rare candy", "gold"};

    private final Screen parent;
    private TextFieldWidget field;
    private final List<ButtonWidget> rowButtons = new ArrayList<>();
    private final List<JsonObject> hits = new ArrayList<>();
    private int seen = -1;

    private static final int ROW_H = 22, LIST_TOP = 110;

    public ChestFilterScreen(Screen parent) {
        super(Text.literal("Container Filter"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        field = new TextFieldWidget(textRenderer, cx - 160, 32, 220, 20, Text.literal("Item"));
        field.setPlaceholder(Text.literal("item name or id (e.g. golden fossil)"));
        field.setMaxLength(80);
        field.setText(lastText);
        addDrawableChild(field);
        setInitialFocus(field);
        addDrawableChild(ButtonWidget.builder(Text.literal("Search"), b -> search(field.getText()))
                .dimensions(cx + 64, 32, 96, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Pick item (icons, all mods)"),
                        b -> MinecraftClient.getInstance().setScreen(new ItemPickerScreen(this, id -> {
                            field.setText(id);
                            search(id);
                        }))).dimensions(cx - 160, 58, 320, 20).build());

        int bw = 58, gap = 3, total = QUICK.length * bw + (QUICK.length - 1) * gap;
        for (int i = 0; i < QUICK.length; i++) {
            final String q = QUICK[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(q), b -> {
                field.setText(q);
                search(q);
            }).dimensions(cx - total / 2 + i * (bw + gap), 82, bw, 20).build());
        }

        int by = height - 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("Stop / clear"), b -> {
                    ChestFilter.clear();
                    StructureFinder.clear();
                })
                .dimensions(cx - 160, by, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Settings"),
                        b -> MinecraftClient.getInstance().setScreen(ConfigScreenBuilder.create(this)))
                .dimensions(cx - 50, by, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(cx + 60, by, 100, 20).build());
        seen = -1;
        rebuild();
    }

    private void search(String text) {
        lastText = text.trim();
        if (lastText.length() < 2) return;
        ServerLink.scanChests(lastText, false);
        ChestFilter.setActive(lastText);
    }

    @Override
    public void tick() {
        super.tick();
        if (ServerLink.chestsVersion() != seen) rebuild();
    }

    private void rebuild() {
        seen = ServerLink.chestsVersion();
        for (ButtonWidget b : rowButtons) remove(b);
        rowButtons.clear();
        hits.clear();
        JsonObject res = ServerLink.lastChests();
        if (res == null || !res.has("hits")) return;
        JsonArray arr = res.getAsJsonArray("hits");
        int rows = Math.max(1, (height - LIST_TOP - 40) / ROW_H);
        int cx = width / 2;
        for (int i = 0; i < Math.min(rows, arr.size()); i++) {
            JsonObject h = arr.get(i).getAsJsonObject();
            hits.add(h);
            final int x = h.get("x").getAsInt(), z = h.get("z").getAsInt();
            final String label = h.get("item").getAsString();
            rowButtons.add(addDrawableChild(ButtonWidget.builder(Text.literal("Track"), btn -> {
                StructureFinder.trackPos(label, x, z);
                close();
            }).dimensions(cx + 142, LIST_TOP + (hits.size() - 1) * ROW_H, 46, 18).build()));
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = width / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, title, cx, 10, 0xFFFFFFFF);
        if (!ServerLink.available()) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Server mod not found: only containers you opened before are searched."), cx, 22, 0xFFFFAA55);
        } else {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Scans while you walk. Also searches containers you opened before (memory)."), cx, 22, 0xFFAAAAAA);
        }
        if (ServerLink.waitingChests()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Searching..."), cx, LIST_TOP, 0xFFFFFF55);
            return;
        }
        String err = ServerLink.lastError();
        if (err != null) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(err), cx, LIST_TOP, 0xFFFF5555);
            return;
        }
        JsonObject res = ServerLink.lastChests();
        if (res == null) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Type an item and press Search."), cx, LIST_TOP, 0xFF888888);
            return;
        }
        if (hits.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("No container holds that within " + res.get("radius").getAsInt() + " blocks."),
                    cx, LIST_TOP, 0xFF888888);
            if (res.has("containers")) {
                ctx.drawCenteredTextWithShadow(textRenderer,
                        Text.literal("Server checked " + res.get("containers").getAsInt() + " containers in "
                                + res.get("chunks").getAsInt() + " loaded chunks."), cx, LIST_TOP + 12, 0xFF666666);
            }
            return;
        }
        for (int i = 0; i < hits.size(); i++) {
            JsonObject h = hits.get(i);
            int y = LIST_TOP + i * ROW_H;
            ctx.fill(cx - 190, y - 2, cx + 190, y + ROW_H - 4, 0x55000000);
            ctx.drawTextWithShadow(textRenderer,
                    Text.literal(h.get("count").getAsInt() + "x " + h.get("item").getAsString()
                            + "  (" + h.get("block").getAsString() + ")" + (h.has("mem") ? "  §7[remembered]" : "")),
                    cx - 186, y, 0xFFFFD700);
            ctx.drawTextWithShadow(textRenderer,
                    Text.literal(h.get("dist").getAsInt() + "m  " + h.get("x").getAsInt() + ", "
                            + h.get("y").getAsInt() + ", " + h.get("z").getAsInt()), cx - 186, y + 10, 0xFFBBBBBB);
        }
        int total = res.get("total").getAsInt();
        if (total > hits.size()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("+" + (total - hits.size()) + " more"),
                    cx, height - 42, 0xFF888888);
        }
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }
}
