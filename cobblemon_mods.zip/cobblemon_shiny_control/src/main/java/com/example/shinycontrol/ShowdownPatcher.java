package com.example.shinycontrol;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Adds the "forced damage" hook to Showdown's battle-actions.js (the battle engine of Cobblemon).
 * It runs while Showdown is being prepared, after Cobblemon (and Mega Showdown) have written their files, and before the engine
 * reads them. It is safe to call several times: the file is only changed once.
 * A Pokemon whose team entry carries an extra "moves info" element with maxPp 777777 always deals exactly "pp" damage.
 */
public final class ShowdownPatcher {
    private static final Logger LOGGER = LoggerFactory.getLogger("cobblemon_shiny_control");
    private static final String MARK = "SCB forced damage";

    private static final String HELPER = """
            // ---- SCB forced damage (Cobblemon Shiny Control) : START ----
            function __scbForced(source) {
              try {
                const set = source && source.set;
                if (!set || !set.movesInfo || !set.moves) return null;
                const e = set.movesInfo[set.moves.length];
                if (e && e.maxPp === 777777 && e.pp >= 0) return e.pp;
              } catch (err) {}
              return null;
            }
            // ---- SCB forced damage : END ----
            """;

    private static final String HOOK = """
                const __scbF = __scbForced(source);
                if (__scbF !== null) return __scbF;
                if (move.ohko) return target.maxhp;""";

    private ShowdownPatcher() {}

    public static synchronized void apply() {
        try {
            if (!ControlConfig.get().damageEnabled) return;
        } catch (Throwable ignored) {
            // config not loaded yet: patch anyway, the hook does nothing without marked Pokemon
        }
        try {
            Path file = Path.of("./showdown/sim/battle-actions.js");
            if (!Files.exists(file)) return;
            String s = Files.readString(file, StandardCharsets.UTF_8);
            if (s.contains(MARK)) return;
            if (!s.contains("class BattleActions {") || !s.contains("    if (move.ohko) return target.maxhp;")) {
                LOGGER.warn("Forced damage: battle-actions.js has an unexpected layout, it was not changed.");
                return;
            }
            s = s.replaceFirst("class BattleActions \\{", java.util.regex.Matcher.quoteReplacement(HELPER) + "class BattleActions {");
            s = s.replace("    if (move.ohko) return target.maxhp;", HOOK);
            Files.writeString(file, s, StandardCharsets.UTF_8);
            LOGGER.info("Forced damage: Showdown's battle-actions.js was prepared.");
        } catch (Throwable t) {
            LOGGER.warn("Forced damage: could not prepare battle-actions.js ({})", t.toString());
        }
    }
}
