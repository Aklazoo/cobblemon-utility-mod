package com.example.shinycontrol;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Extra spawns of Ultra Beasts / legendaries / mythicals / paradox Pokémon around a boosted player.
 * Every second, for each boosted player who asked for it, there is a 1/(minutes*60) chance to spawn one at a
 * valid spot 24-48 blocks away, using Cobblemon's own /spawnpokemonat command run silently by the server.
 * The spawned Pokémon are tracked, limited per player, and removed when nobody is near them any more.
 */
final class BoostSpawner {
    static final String TAG = "scb_boostspawn";

    private record Tracked(UUID player, long expiresAt, boolean gift) {}

    private static final Map<UUID, Tracked> TRACKED = new HashMap<>();
    private static final Map<UUID, Long> NEXT = new HashMap<>();
    /** Set while our own command runs, so the entity it creates can be recognised when it joins the world. */
    private static UUID expecting;
    private static boolean captureDone;
    private static boolean expectingGift;
    private static Entity lastCaptured;
    private static long tick;
    private static int failures;
    private static Map<String, List<String>> speciesByCat;
    private static final Random RNG = new Random();

    private BoostSpawner() {}

    // ------------------------------------------------------------------ called when a Pokémon entity joins a world
    static boolean captured(Entity entity) {
        if (expecting == null || captureDone) return false;
        captureDone = true;
        lastCaptured = entity;
        entity.addCommandTag(TAG);
        ControlConfig cfg = ControlConfig.get();
        TRACKED.put(entity.getUuid(), new Tracked(expecting, System.currentTimeMillis() + cfg.boostSpawnDespawnMinutes * 60_000L, expectingGift));
        return true;
    }

    // ------------------------------------------------------------------ once per tick
    static void tick(MinecraftServer server) {
        if (++tick % 20 != 0) return; // once per second
        ControlConfig cfg = ControlConfig.get();
        if (!cfg.boostSpawnEnabled) return;
        cleanup(server);
        long now = System.currentTimeMillis();
        java.util.Set<UUID> online = new java.util.HashSet<>();
        for (ServerPlayerEntity player : new ArrayList<>(server.getPlayerManager().getPlayerList())) {
            PlayerBoost.Boost boost = PlayerBoost.boostOf(player.getUuid());
            if (boost == null || boost.spawns() == null || boost.spawns().cats().isEmpty()) continue;
            online.add(player.getUuid());
            Long due = NEXT.get(player.getUuid());
            if (due == null) { // boost just switched on: first extra spawn soon, then one every few minutes on average
                NEXT.put(player.getUuid(), now + 15_000L);
                ShinyControlMod.LOGGER.info("Extra spawns armed for {} (categories {}, about every {} min)",
                        player.getName().getString(), boost.spawns().cats(), boost.spawns().minutes());
                continue;
            }
            if (now < due || player.isSpectator()) continue;
            if (activeCount(player.getUuid()) >= cfg.boostSpawnMaxActive) continue;
            try {
                if (spawnOne(server, player, boost.spawns())) {
                    long avg = Math.max(1, boost.spawns().minutes()) * 60_000L;
                    NEXT.put(player.getUuid(), now + (long) (avg * (0.5 + RNG.nextDouble())));
                } else {
                    NEXT.put(player.getUuid(), now + 5_000L); // a species or a spot did not work: try another in 5 s
                }
            } catch (Throwable t) {
                NEXT.put(player.getUuid(), now + 5_000L);
                PlayerBoost.warnOnce("spawnfail", "Extra spawn failed: " + t);
            }
        }
        NEXT.keySet().retainAll(online); // boost switched off or player left: start over next time
    }

    private static int activeCount(UUID player) {
        int n = 0;
        for (Tracked t : TRACKED.values()) if (t.player().equals(player) && !t.gift()) n++;
        return n;
    }

    private static void cleanup(MinecraftServer server) {
        if (TRACKED.isEmpty()) return;
        long now = System.currentTimeMillis();
        List<UUID> remove = new ArrayList<>();
        for (Map.Entry<UUID, Tracked> e : TRACKED.entrySet()) {
            Entity found = null;
            for (ServerWorld w : server.getWorlds()) {
                found = w.getEntity(e.getKey());
                if (found != null) break;
            }
            if (found == null || found.isRemoved()) { remove.add(e.getKey()); continue; } // gone or caught
            if (found instanceof net.minecraft.entity.passive.TameableEntity t && t.getOwnerUuid() != null) { // someone caught it
                remove.add(e.getKey());
                found.removeCommandTag(TAG);
                continue;
            }
            if (now >= e.getValue().expiresAt()) {
                PlayerEntity near = found.getWorld().getClosestPlayer(found.getX(), found.getY(), found.getZ(), 48, false);
                if (near != null) { // somebody is still around it: give it more time
                    TRACKED.put(e.getKey(), new Tracked(e.getValue().player(), now + 120_000L, e.getValue().gift()));
                } else {
                    found.discard();
                    remove.add(e.getKey());
                }
            }
        }
        for (UUID id : remove) TRACKED.remove(id);
    }

    // ------------------------------------------------------------------ spawning
    private static boolean spawnOne(MinecraftServer server, ServerPlayerEntity player, PlayerBoost.Spawns spawns) throws Exception {
        List<String> pool = pool(spawns.cats());
        if (pool.isEmpty()) {
            PlayerBoost.warnOnce("emptypool", "Extra spawns: no species found for " + spawns.cats());
            return false;
        }
        ServerWorld world = (ServerWorld) player.getWorld();
        BlockPos spot = findSpot(world, player, 24, 48);
        if (spot == null) { // try again next second
            PlayerBoost.warnOnce("nospot", "Extra spawns: no free spot found around " + player.getName().getString() + " (will keep trying).");
            return false;
        }
        String species = pool.get(RNG.nextInt(pool.size()));
        int level = spawns.levelMin() + RNG.nextInt(Math.max(1, spawns.levelMax() - spawns.levelMin() + 1));
        String cmd = "spawnpokemonat " + spot.getX() + " " + spot.getY() + " " + spot.getZ() + " " + species + " level=" + level;

        expecting = player.getUuid();
        captureDone = false;
        try {
            // Cobblemon's command needs a real player as its source (the console crashes it), so run it as the player, silently, with full rights
            var source = player.getCommandSource().withLevel(4).withSilent();
            server.getCommandManager().executeWithPrefix(source, cmd);
        } finally {
            expecting = null;
        }
        if (!captureDone) {
            PlayerBoost.warnOnce("nocapture", "Extra spawn: the command '" + cmd + "' did not create a Pokémon.");
            return false;
        }
        failures = 0;
        applyPower(lastCaptured, spawns, world);
        if (ControlConfig.get().boostSpawnNotify) {
            Vec3d d = new Vec3d(spot.getX() - player.getX(), 0, spot.getZ() - player.getZ());
            player.sendMessage(Text.literal("§6[Boost] §fA §e" + pretty(species) + " §fappeared about §e" + (int) d.length()
                    + " blocks §fto the §e" + compass(d) + "§f."), false);
        }
        ShinyControlMod.LOGGER.info("Extra spawn: {} (level {}) near {}", species, level, player.getName().getString());
        return true;
    }

    // ------------------------------------------------------------------ gift Pokémon
    static int giftCount(UUID player) {
        int n = 0;
        for (Tracked t : TRACKED.values()) if (t.player().equals(player) && t.gift()) n++;
        return n;
    }

    /** Spawns a Pokémon holding {@code stack} 4-8 blocks from the player. Returns null on success, else an error text. */
    static String spawnGift(MinecraftServer server, ServerPlayerEntity player, String species, int level,
                            net.minecraft.item.ItemStack stack) {
        ServerWorld world = (ServerWorld) player.getWorld();
        BlockPos spot = findSpot(world, player, 4, 8);
        if (spot == null) return "No free spot near you. Move to open ground and try again.";
        String cmd = "spawnpokemonat " + spot.getX() + " " + spot.getY() + " " + spot.getZ() + " " + species + " level=" + level;
        expecting = player.getUuid();
        expectingGift = true;
        captureDone = false;
        Entity created = null;
        try {
            var source = player.getCommandSource().withLevel(4).withSilent();
            server.getCommandManager().executeWithPrefix(source, cmd);
        } finally {
            expecting = null;
            expectingGift = false;
        }
        if (!captureDone) return "Cobblemon did not create \"" + species + "\". Check the species name.";
        // find the entity we just tagged and give it the item
        for (Map.Entry<UUID, Tracked> e : TRACKED.entrySet()) {
            if (!e.getValue().gift() || !e.getValue().player().equals(player.getUuid())) continue;
            for (ServerWorld w : server.getWorlds()) {
                Entity found = w.getEntity(e.getKey());
                if (found != null && found.getCommandTags().contains(TAG) && found.squaredDistanceTo(spot.getX(), spot.getY(), spot.getZ()) < 36
                        && found.age < 40 && !GIFTED.contains(found.getUuid())) {
                    created = found;
                }
            }
        }
        if (created == null) return "The Pokémon appeared but could not be found again.";
        try {
            Object pokemon = created.getClass().getMethod("getPokemon").invoke(created);
            java.lang.reflect.Method m = pokemon.getClass().getMethod("swapHeldItem", net.minecraft.item.ItemStack.class, boolean.class);
            m.invoke(pokemon, stack.copyWithCount(1), false);
        } catch (Throwable t) {
            created.discard();
            TRACKED.remove(created.getUuid());
            ShinyControlMod.LOGGER.warn("Gift Pokémon: could not give the held item ({})", t.toString());
            return "Could not put the item in the Pokémon's hand (see the server log).";
        }
        GIFTED.add(created.getUuid());
        Vec3d d = new Vec3d(spot.getX() - player.getX(), 0, spot.getZ() - player.getZ());
        ShinyControlMod.LOGGER.info("Gift Pokémon: {} (level {}) holding {} for {}", species, level,
                net.minecraft.registry.Registries.ITEM.getId(stack.getItem()), player.getName().getString());
        player.sendMessage(Text.literal("§6[Gift] §fA §e" + pretty(species) + " §fholding §e" + stack.getName().getString()
                + " §fappeared about §e" + (int) d.length() + " blocks §fto the §e" + compass(d) + "§f. Catch it to get the item."), false);
        return null;
    }
    private static final java.util.Set<UUID> GIFTED = new java.util.HashSet<>();

    /** Stronger stats for a Pokémon we spawned: EVs, perfect IVs, nature, ability, held item. Each part is optional. */
    private static void applyPower(Entity entity, PlayerBoost.Spawns sp, ServerWorld world) {
        if (entity == null || (sp.evs() <= 0 && sp.ivs() <= 0 && sp.nature().isEmpty() && sp.ability().isEmpty() && sp.item().isEmpty() && sp.damage() < 0)) return;
        Object pokemon;
        try {
            pokemon = entity.getClass().getMethod("getPokemon").invoke(entity);
        } catch (Throwable t) {
            PlayerBoost.warnOnce("power-get", "Stats boost: could not read the Pokémon (" + t + ")");
            return;
        }
        if (pokemon == null) return;
        if (sp.damage() >= 0) {
            try {
                Object data = pokemon.getClass().getMethod("getPersistentData").invoke(pokemon);
                if (data instanceof net.minecraft.nbt.NbtCompound nbt) nbt.putInt(ForcedDamage.KEY, sp.damage());
            } catch (Throwable t) {
                PlayerBoost.warnOnce("power-damage", "Forced damage: could not mark the Pokémon (" + t + ")");
            }
        }
        if (sp.ivs() > 0) {
            try {
                PlayerBoost.Quality.perfectIvs(pokemon, sp.ivs(), world);
            } catch (Throwable t) {
                PlayerBoost.warnOnce("power-iv", "Stats boost: could not set IVs (" + t + ")");
            }
        }
        if (sp.evs() > 0) {
            try {
                Class<?> statsC = Class.forName("com.cobblemon.mod.common.api.pokemon.stats.Stats");
                java.lang.reflect.Method setEv = null;
                for (java.lang.reflect.Method m : pokemon.getClass().getMethods()) {
                    if (m.getName().equals("setEV") && m.getParameterCount() == 2) { setEv = m; break; }
                }
                if (setEv == null) throw new NoSuchMethodException("setEV");
                for (String name : new String[]{"HP", "ATTACK", "DEFENCE", "SPECIAL_ATTACK", "SPECIAL_DEFENCE", "SPEED"}) {
                    setEv.invoke(pokemon, Enum.valueOf((Class) statsC, name), sp.evs());
                }
            } catch (Throwable t) {
                PlayerBoost.warnOnce("power-ev", "Stats boost: could not set EVs (" + t + ")");
            }
        }
        if (!sp.nature().isEmpty()) {
            try {
                PlayerBoost.Quality.applyProperties(pokemon, "nature=" + sp.nature());
            } catch (Throwable t) {
                PlayerBoost.warnOnce("power-nature", "Stats boost: could not set the nature (" + t + ")");
            }
        }
        if (!sp.ability().isEmpty()) {
            try {
                PlayerBoost.Quality.applyProperties(pokemon, "ability=" + sp.ability());
            } catch (Throwable t) {
                PlayerBoost.warnOnce("power-ability", "Stats boost: could not set the ability (" + t + ")");
            }
        }
        if (!sp.item().isEmpty()) {
            try {
                net.minecraft.item.ItemStack stack = new net.minecraft.item.ItemStack(
                        net.minecraft.registry.Registries.ITEM.get(net.minecraft.util.Identifier.of(sp.item())));
                pokemon.getClass().getMethod("swapHeldItem", net.minecraft.item.ItemStack.class, boolean.class).invoke(pokemon, stack, false);
            } catch (Throwable t) {
                PlayerBoost.warnOnce("power-item", "Stats boost: could not give the held item (" + t + ")");
            }
        }
        if (PlayerBoost.WARNED.add("power-first")) ShinyControlMod.LOGGER.info("Stats boost applied to a spawned Pokémon (evs={}, ivs={}, nature={}, ability={}, item={})",
                sp.evs(), sp.ivs(), sp.nature(), sp.ability(), sp.item());
    }

    private static String pretty(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private static String compass(Vec3d d) {
        double deg = Math.toDegrees(Math.atan2(d.x, -d.z)); // 0 = north (-z), 90 = east (+x)
        String[] names = {"north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"};
        int i = (int) Math.round(((deg % 360) + 360) % 360 / 45.0) % 8;
        return names[i];
    }

    private static BlockPos findSpot(ServerWorld world, ServerPlayerEntity player, double minD, double maxD) {
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = RNG.nextDouble() * Math.PI * 2;
            double dist = minD + RNG.nextDouble() * (maxD - minD);
            int x = (int) Math.floor(player.getX() + Math.cos(angle) * dist);
            int z = (int) Math.floor(player.getZ() + Math.sin(angle) * dist);
            if (!world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) continue;
            int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos pos = new BlockPos(x, y, z);
            if (!world.getFluidState(pos).isEmpty() || !world.getFluidState(pos.down()).isEmpty()) continue;
            if (!world.getBlockState(pos.down()).isSolidBlock(world, pos.down())) continue;
            if (!world.getBlockState(pos).isAir() && !world.getBlockState(pos).isReplaceable()) continue;
            if (world.getBlockState(pos.down()).getFluidState().isIn(FluidTags.WATER)) continue;
            return pos;
        }
        return null;
    }

    // ------------------------------------------------------------------ which species can be spawned
    private static List<String> pool(Set<String> cats) {
        if (speciesByCat == null) speciesByCat = loadSpecies();
        List<String> out = new ArrayList<>();
        for (String c : cats) {
            List<String> l = speciesByCat.get(c);
            if (l != null) for (String s : l) if (!out.contains(s)) out.add(s);
        }
        return out;
    }

    private static Map<String, List<String>> loadSpecies() {
        Map<String, List<String>> out = new HashMap<>();
        for (String c : new String[]{"legendary", "mythical", "ultrabeast", "paradox"}) out.put(c, new ArrayList<>());
        try {
            Class<?> cls = Class.forName("com.cobblemon.mod.common.api.pokemon.PokemonSpecies");
            Object instance = cls.getField("INSTANCE").get(null);
            Object all = PlayerBoost.call(instance, "getSpecies");
            if (all instanceof Collection<?> species) {
                for (Object sp : species) {
                    Object nameObj = PlayerBoost.call(sp, "getName");
                    if (nameObj == null) continue;
                    // Cobblemon ids have no spaces or punctuation: "Iron Treads" -> irontreads, "Type: Null" -> typenull, "Ho-Oh" -> hooh
                    String name = String.valueOf(nameObj).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
                    if (name.isEmpty()) continue;
                    Object labels = PlayerBoost.call(sp, "getLabels");
                    if (!(labels instanceof Collection<?> ls)) continue;
                    for (Object l : ls) {
                        String key = PlayerBoost.norm(String.valueOf(l));
                        List<String> list = out.get(key);
                        if (list != null) list.add(name);
                    }
                }
            }
        } catch (Throwable t) {
            ShinyControlMod.LOGGER.warn("Extra spawns: could not read the Pokémon list ({})", t.toString());
        }
        ShinyControlMod.LOGGER.info("Extra spawns: legendary={} mythical={} ultrabeast={} paradox={}",
                out.get("legendary").size(), out.get("mythical").size(), out.get("ultrabeast").size(), out.get("paradox").size());
        return out;
    }
}
