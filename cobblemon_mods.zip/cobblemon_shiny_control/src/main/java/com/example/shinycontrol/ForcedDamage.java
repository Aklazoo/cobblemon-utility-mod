package com.example.shinycontrol;

import net.minecraft.nbt.NbtCompound;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Called when Cobblemon packs a team for Showdown. For every Pokemon that carries a "scb_damage" value in its own saved data
 * (set when it was spawned by the boost, kept when it is caught), an extra "moves info" element is appended. The patched
 * Showdown reads it and makes that Pokemon deal exactly that much damage.
 */
public final class ForcedDamage {
    public static final String KEY = "scb_damage";
    private static final Logger LOGGER = LoggerFactory.getLogger("cobblemon_shiny_control");
    private static boolean logged;

    private ForcedDamage() {}

    public static String mark(List<?> team, String packed) {
        try {
            ControlConfig cfg = ControlConfig.get();
            if (!cfg.damageEnabled || packed == null || team == null || team.isEmpty()) return packed;
            String[] mons = packed.split("\\]", -1);
            if (mons.length != team.size()) return packed; // unexpected shape: leave it alone
            boolean changed = false;
            for (int i = 0; i < mons.length; i++) {
                Object bp = team.get(i);
                Object pokemon = call(bp, "getOriginalPokemon");
                if (pokemon == null) continue;
                Object data = call(pokemon, "getPersistentData");
                if (!(data instanceof NbtCompound nbt) || !nbt.contains(KEY)) continue;
                if (cfg.damageOnlyWhenOwned && call(pokemon, "getOwnerUUID") == null) continue; // a wild Pokemon: no
                int dmg = Math.max(0, Math.min(cfg.damageMax, nbt.getInt(KEY)));
                String[] f = mons[i].split("\\|", -1);
                if (f.length <= 9 || !f[9].matches("\\d+/\\d+(,\\d+/\\d+)*")) continue;
                f[9] = f[9] + "," + dmg + "/777777";
                mons[i] = String.join("|", f);
                changed = true;
                if (!logged) {
                    logged = true;
                    LOGGER.info("Forced damage: a Pokemon with {} damage was sent to the battle engine.", dmg);
                }
            }
            return changed ? String.join("]", mons) : packed;
        } catch (Throwable t) {
            LOGGER.warn("Forced damage: could not mark the team ({})", t.toString());
            return packed;
        }
    }

    private static Object call(Object target, String method) {
        try {
            return target.getClass().getMethod(method).invoke(target);
        } catch (Throwable t) {
            return null;
        }
    }
}
