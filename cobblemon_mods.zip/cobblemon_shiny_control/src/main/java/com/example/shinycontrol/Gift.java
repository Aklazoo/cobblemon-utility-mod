package com.example.shinycontrol;

import com.google.gson.JsonObject;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** "Gift Pokémon": spawns a weak Pokémon holding the chosen item next to the player. Catching it gives the item. */
final class Gift {
    private static final Map<UUID, Long> LAST = new HashMap<>();

    private Gift() {}

    static void handle(ServerPlayerEntity player, JsonObject req) {
        String err = run(player, req);
        JsonObject out = new JsonObject();
        out.addProperty("t", "gift");
        out.addProperty("ok", err == null);
        out.addProperty("msg", err == null ? "Gift Pokémon spawned near you." : err);
        ServerNet.reply(player, out);
    }

    private static String run(ServerPlayerEntity player, JsonObject req) {
        ControlConfig cfg = ControlConfig.get();
        if (!cfg.giftEnabled) return "Gift Pokémon is disabled on this server.";
        if (!PlayerBoost.mayBoost(player)) return "You are not allowed to use this on this server.";

        String itemText = req.has("item") ? req.get("item").getAsString().trim().toLowerCase(Locale.ROOT) : "";
        Identifier id = Identifier.tryParse(itemText);
        if (id == null || !Registries.ITEM.containsId(id)) return "Unknown item: " + itemText;
        Item item = Registries.ITEM.get(id);
        if (item == net.minecraft.item.Items.AIR) return "Unknown item: " + itemText;
        for (String banned : cfg.giftBannedItems) {
            if (banned != null && banned.trim().equalsIgnoreCase(id.toString())) return "This item is not allowed on this server.";
        }

        String species = req.has("species") ? req.get("species").getAsString().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "") : "";
        if (species.isEmpty()) species = "magikarp";
        int level = req.has("level") ? req.get("level").getAsInt() : 1;
        level = Math.max(1, Math.min(100, level));

        long now = System.currentTimeMillis();
        Long last = LAST.get(player.getUuid());
        if (last != null && now - last < cfg.giftCooldownSeconds * 1000L) {
            long wait = (cfg.giftCooldownSeconds * 1000L - (now - last) + 999) / 1000;
            return "Please wait " + wait + " s.";
        }
        if (BoostSpawner.giftCount(player.getUuid()) >= cfg.giftMaxActive) {
            return "You already have " + cfg.giftMaxActive + " gift Pokémon waiting. Catch them first.";
        }
        String error = BoostSpawner.spawnGift(player.getServer(), player, species, level, new ItemStack(item));
        if (error == null) LAST.put(player.getUuid(), now);
        return error;
    }
}
