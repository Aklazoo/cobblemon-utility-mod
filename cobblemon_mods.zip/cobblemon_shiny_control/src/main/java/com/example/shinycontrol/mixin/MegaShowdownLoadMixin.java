package com.example.shinycontrol.mixin;

import com.example.shinycontrol.ShowdownPatcher;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Mega Showdown overwrites Showdown's files when it loads: patch again right after it, so the hook is never lost. */
@Pseudo
@Mixin(targets = "com.cobblemon.yajatkaul.mega_showdown.utility.showdown.LoadMethods", remap = false)
public abstract class MegaShowdownLoadMixin {
    @Inject(method = "load", at = @At("TAIL"), remap = false, require = 0)
    private void shinycontrol$patch(CallbackInfo ci) {
        ShowdownPatcher.apply();
    }
}
