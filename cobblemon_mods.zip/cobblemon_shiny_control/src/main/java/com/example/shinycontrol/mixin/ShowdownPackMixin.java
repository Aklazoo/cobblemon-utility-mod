package com.example.shinycontrol.mixin;

import com.example.shinycontrol.ForcedDamage;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

/** Marks the Pokemon that must deal forced damage when Cobblemon packs a team for the battle engine. */
@Pseudo
@Mixin(targets = "com.cobblemon.mod.common.battles.BattleRegistry", remap = false)
public abstract class ShowdownPackMixin {
    @Inject(method = "packTeam", at = @At("RETURN"), cancellable = true, remap = false, require = 0)
    private void shinycontrol$pack(List<?> team, CallbackInfoReturnable<String> cir) {
        cir.setReturnValue(ForcedDamage.mark(team, cir.getReturnValue()));
    }
}
