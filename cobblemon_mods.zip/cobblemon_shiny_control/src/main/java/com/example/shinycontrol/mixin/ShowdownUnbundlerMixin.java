package com.example.shinycontrol.mixin;

import com.example.shinycontrol.ShowdownPatcher;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Prepares Showdown's files at the end of Cobblemon's unbundling (later than Mega Showdown's own hook: higher priority). */
@Pseudo
@Mixin(targets = "com.cobblemon.mod.common.battles.runner.graal.GraalShowdownUnbundler", priority = 2000, remap = false)
public abstract class ShowdownUnbundlerMixin {
    @Inject(method = "attemptUnbundle", at = @At("TAIL"), remap = false, require = 0)
    private void shinycontrol$patch(CallbackInfo ci) {
        ShowdownPatcher.apply();
    }
}
