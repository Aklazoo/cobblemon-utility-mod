package com.example.shinycontrol;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.text.Text;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Changes Cobblemon's in-memory "shinyRate" (the N of 1/N) at runtime.
 * Nothing is written to Cobblemon's own config file; the original value is put back on shutdown.
 * Cobblemon is reached by reflection: if its setting cannot be found, commands say so and nothing breaks.
 */
public final class ShinyRate {
    private static MinecraftServer server;
    private static Float original;   // Cobblemon's own value
    private static Float applied;    // value we wrote
    private static long tickCount;

    private static boolean boostRunning;
    private static double boostMult = 1.0;
    private static long boostEndTick = -1;

    private ShinyRate() {}

    // ------------------------------------------------------------ lifecycle
    public static void onServerStarted(MinecraftServer s) {
        server = s;
        if (!apply()) ShinyControlMod.LOGGER.warn("Cobblemon shiny rate not found: /shinyrate will be unavailable.");
    }

    public static void onTick(MinecraftServer s) {
        tickCount++;
        if (boostRunning && tickCount >= boostEndTick) {
            boostRunning = false;
            boostMult = 1.0;
            apply();
            broadcast("§6[Shiny] §fThe shiny boost has ended.");
        }
        if (tickCount % 600 == 0) apply(); // re-apply if something reset the config
    }

    // ------------------------------------------------------------ state
    public static double persistentMultiplier() {
        return ControlConfig.get().multiplier;
    }

    public static boolean boostActive() {
        return boostRunning;
    }

    public static double boostMultiplier() {
        return boostMult;
    }

    public static long boostSecondsLeft() {
        return boostRunning ? Math.max(0, (boostEndTick - tickCount) / 20) : 0;
    }

    public static double effectiveMultiplier() {
        return persistentMultiplier() * (boostRunning ? boostMult : 1.0);
    }

    /** Cobblemon's own shiny denominator (before our multiplier), or null if unknown. */
    public static Float baseRate() {
        if (original != null) return original;
        Object config = cobblemonConfig();
        return config == null ? null : readRate(config);
    }

    public static Float currentRate() {
        Object config = cobblemonConfig();
        return config == null ? null : readRate(config);
    }

    // ------------------------------------------------------------ actions
    public static boolean setMultiplier(double m) {
        ControlConfig.get().multiplier = Math.max(1.0, Math.min(1000.0, m));
        ControlConfig.save();
        return apply();
    }

    public static boolean startBoost(double mult, int seconds) {
        boostMult = Math.max(1.0, Math.min(1000.0, mult));
        boostEndTick = tickCount + seconds * 20L;
        boostRunning = true;
        return apply();
    }

    public static boolean stopBoost() {
        boolean was = boostRunning;
        boostRunning = false;
        boostMult = 1.0;
        apply();
        return was;
    }

    public static void broadcast(String message) {
        if (server != null) server.getPlayerManager().broadcast(Text.literal(message), false);
    }

    /** Writes base / effectiveMultiplier into Cobblemon's config. */
    public static boolean apply() {
        Object config = cobblemonConfig();
        if (config == null) return false;
        Float current = readRate(config);
        if (current == null || current <= 0f) return false;

        // a value we did not write is Cobblemon's real value (first run, reload...)
        if (applied == null || Math.abs(current - applied) > 0.01f) original = current;

        float target = (float) Math.max(1.0, original / effectiveMultiplier());
        if (!writeRate(config, target)) return false;
        applied = target;
        return true;
    }

    /** Puts Cobblemon's original value back (called on shutdown). */
    public static void restore() {
        if (original != null && applied != null) {
            Object config = cobblemonConfig();
            if (config != null) {
                Float current = readRate(config);
                if (current != null && Math.abs(current - applied) < 0.01f) writeRate(config, original);
            }
        }
        original = null;
        applied = null;
    }

    // ------------------------------------------------------------ reflection
    private static Object cobblemonConfig() {
        if (!FabricLoader.getInstance().isModLoaded("cobblemon")) return null;
        try {
            Class<?> cls = Class.forName("com.cobblemon.mod.common.Cobblemon", true, ShinyRate.class.getClassLoader());
            Object instance = cls.getField("INSTANCE").get(null);
            return cls.getMethod("getConfig").invoke(instance);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Float readRate(Object config) {
        try {
            for (Method m : config.getClass().getMethods()) {
                if (m.getName().equals("getShinyRate") && m.getParameterCount() == 0) {
                    Object v = m.invoke(config);
                    if (v instanceof Number n) return n.floatValue();
                }
            }
            Field f = findField(config.getClass(), "shinyRate");
            if (f != null) {
                Object v = f.get(config);
                if (v instanceof Number n) return n.floatValue();
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static boolean writeRate(Object config, float value) {
        try {
            for (Method m : config.getClass().getMethods()) {
                if (m.getName().equals("setShinyRate") && m.getParameterCount() == 1) {
                    Class<?> t = m.getParameterTypes()[0];
                    if (t == float.class || t == Float.class) m.invoke(config, value);
                    else if (t == double.class || t == Double.class) m.invoke(config, (double) value);
                    else continue;
                    return true;
                }
            }
            Field f = findField(config.getClass(), "shinyRate");
            if (f != null) {
                if (f.getType() == double.class) f.setDouble(config, value); else f.setFloat(config, value);
                return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    private static Field findField(Class<?> cls, String name) {
        for (Class<?> c = cls; c != null; c = c.getSuperclass()) {
            try {
                Field f = c.getDeclaredField(name);
                f.setAccessible(true);
                return f;
            } catch (NoSuchFieldException ignored) {
            }
        }
        return null;
    }
}
