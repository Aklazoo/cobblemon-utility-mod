package com.example.shinycontrol;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Diagnostic only: when the Lootr mod is installed, writes the list of its classes, fields and methods to
 * config/cobblemon_shiny_control_lootr_dump.txt (once). It changes nothing in the game. The file lets the
 * developer see Lootr's real API instead of guessing it.
 */
final class LootrProbe {
    private LootrProbe() {}

    static void run() {
        for (String id : new String[]{"lootr", "cobblemonalphas", "cobblemonsizevariation"}) run(id);
    }

    static void run(String modId) {
        try {
            FabricLoader fl = FabricLoader.getInstance();
            Optional<ModContainer> mod = fl.getModContainer(modId);
            if (mod.isEmpty()) return;
            Path out = fl.getGameDir().resolve("cobblemon_shiny_control_" + modId + "_dump.txt");
            if (Files.exists(out)) return; // delete the file to regenerate it

            StringBuilder sb = new StringBuilder();
            sb.append(modId).append(" version: ").append(mod.get().getMetadata().getVersion().getFriendlyString()).append('\n');
            List<String> classes = new ArrayList<>();
            for (Path root : mod.get().getRootPaths()) {
                try (Stream<Path> s = Files.walk(root)) {
                    s.filter(p -> p.toString().endsWith(".class")).forEach(p -> {
                        String rel = root.relativize(p).toString().replace('\\', '/').replace('/', '.');
                        classes.add(rel.substring(0, rel.length() - 6));
                    });
                }
            }
            Collections.sort(classes);
            sb.append("classes in jar: ").append(classes.size()).append("\n\n");
            ClassLoader cl = LootrProbe.class.getClassLoader();
            for (String cn : classes) {
                String lower = cn.toLowerCase();
                if (lower.contains("mixin") || lower.contains(".client.") || lower.contains("datagen")
                        || lower.contains("render") || lower.contains("lang")) continue;
                try {
                    describe(sb, Class.forName(cn, false, cl));
                } catch (Throwable t) {
                    sb.append(cn).append("   (not readable: ").append(t.getClass().getSimpleName()).append(")\n\n");
                }
            }
            Files.writeString(out, sb.toString(), StandardCharsets.UTF_8);
            ShinyControlMod.LOGGER.info("Wrote the Lootr API listing to {}", out);
        } catch (Throwable t) {
            ShinyControlMod.LOGGER.warn("Lootr probe failed", t);
        }
    }

    private static String t(Class<?> c) {
        return c.getSimpleName();
    }

    private static void describe(StringBuilder sb, Class<?> c) {
        sb.append(Modifier.toString(c.getModifiers())).append(' ').append(c.isInterface() ? "interface " : "class ")
                .append(c.getName());
        if (c.getSuperclass() != null && c.getSuperclass() != Object.class) sb.append(" extends ").append(c.getSuperclass().getName());
        Class<?>[] ifs = c.getInterfaces();
        if (ifs.length > 0) {
            sb.append(" implements ");
            for (int i = 0; i < ifs.length; i++) sb.append(i > 0 ? ", " : "").append(ifs[i].getName());
        }
        sb.append('\n');
        try {
            for (Field f : c.getDeclaredFields()) {
                if (f.isSynthetic()) continue;
                sb.append("  F ").append(Modifier.toString(f.getModifiers())).append(' ').append(t(f.getType())).append(' ')
                        .append(f.getName()).append('\n');
            }
            for (Constructor<?> k : c.getDeclaredConstructors()) {
                sb.append("  C (");
                Class<?>[] p = k.getParameterTypes();
                for (int i = 0; i < p.length; i++) sb.append(i > 0 ? ", " : "").append(t(p[i]));
                sb.append(")\n");
            }
            for (Method m : c.getDeclaredMethods()) {
                if (m.isSynthetic() || m.isBridge()) continue;
                sb.append("  M ").append(Modifier.toString(m.getModifiers())).append(' ').append(t(m.getReturnType())).append(' ')
                        .append(m.getName()).append('(');
                Class<?>[] p = m.getParameterTypes();
                for (int i = 0; i < p.length; i++) sb.append(i > 0 ? ", " : "").append(t(p[i]));
                sb.append(")\n");
            }
        } catch (Throwable ex) {
            sb.append("  (members not readable: ").append(ex.getClass().getSimpleName()).append(")\n");
        }
        sb.append('\n');
    }
}
