package com.example.shinycontrol;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;

/** Public entry for the mixin (LootrPreview is package-private). */
public final class LootrCheck {
    private LootrCheck() {}

    public static void after(Object provider, PlayerEntity player, Inventory container) {
        LootrPreview.check(provider, player, container);
    }
}
