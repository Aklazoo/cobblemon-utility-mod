package com.example.shinycontrol;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Client -> server request. One JSON string, e.g. {"t":"find","filter":"shiny"}. */
public record RequestPayload(String json) implements CustomPayload {
    public static final CustomPayload.Id<RequestPayload> ID =
            new CustomPayload.Id<>(Identifier.of("cobblemon_shiny_control", "request"));
    public static final PacketCodec<ByteBuf, RequestPayload> CODEC =
            PacketCodecs.string(30000).xmap(RequestPayload::new, RequestPayload::json);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
