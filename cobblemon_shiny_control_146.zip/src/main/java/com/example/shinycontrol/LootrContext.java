package com.example.shinycontrol;

import java.util.UUID;

/**
 * Remembers which player a Lootr chest is being filled for, so the seed Lootr randomises can be replaced by one that
 * depends only on (chest seed, player). Every player still gets different loot (what randomise_seed=true is for),
 * but the result becomes predictable, which lets the server show the exact content of a never-opened chest.
 */
public final class LootrContext {
    private static final ThreadLocal<UUID> PLAYER = new ThreadLocal<>();
    private static boolean logged = false;

    private LootrContext() {}

    public static void set(UUID id) {
        PLAYER.set(id);
    }

    public static UUID get() {
        return PLAYER.get();
    }

    public static void clear() {
        PLAYER.remove();
    }

    public static long derive(long chestSeed, UUID player) {
        long h = chestSeed ^ 0x9E3779B97F4A7C15L;
        h ^= player.getMostSignificantBits() * 0xBF58476D1CE4E5B9L;
        h ^= player.getLeastSignificantBits() * 0x94D049BB133111EBL;
        h ^= h >>> 31;
        h *= 0xD6E8FEB86659FD93L;
        h ^= h >>> 32;
        return h;
    }

    public static void logOnce(long chestSeed, long used, UUID player) {
        if (logged) return;
        logged = true;
        ShinyControlMod.LOGGER.info("Lootr seed override is active: chest seed {} -> {} for player {}", chestSeed, used, player);
    }
}
