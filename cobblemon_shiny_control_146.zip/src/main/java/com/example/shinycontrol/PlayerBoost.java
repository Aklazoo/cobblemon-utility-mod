package com.example.shinycontrol;

import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Per-player shiny boost, switched by the Cobblemon Utility client (no chat command).
 * When a wild Pokémon appears (is added to the world) and the nearest player has the boost on, it gets an extra
 * shiny roll so that its total shiny chance is (multiplier x Cobblemon's chance), capped at 100%.
 * Other players are never affected: only Pokémon whose nearest player is boosted are touched.
 */
public final class PlayerBoost {
    static final String TAG = "scb_seen";
    private static final String POKEMON_ENTITY = "com.cobblemon.mod.common.entity.pokemon.PokemonEntity";
    /** Player -> total shiny chance (0..1) wanted for wild Pokémon around them. */
    record Boost(double chance, Filter filter, Quality quality, Spawns spawns) {}

    private static final Map<UUID, Boost> ACTIVE = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST = new ConcurrentHashMap<>();
    private static Class<?> pokemonEntityClass;
    private static boolean classLookedUp;
    private static boolean loggedFirst;
    private static final java.util.Set<String> WARNED = ConcurrentHashMap.newKeySet();

    private PlayerBoost() {}

    public static void init() {
        ServerEntityEvents.ENTITY_LOAD.register(PlayerBoost::onLoad);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> ACTIVE.remove(handler.getPlayer().getUuid()));
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK.register(BoostSpawner::tick);
    }

    // ------------------------------------------------------------------ requests from the client
    static void handle(ServerPlayerEntity player, JsonObject req) {
        ControlConfig cfg = ControlConfig.get();
        boolean on = req.has("on") && req.get("on").getAsBoolean();
        Float rate0 = ShinyRate.currentRate();
        double base0 = 1.0 / (rate0 != null && rate0 > 0 ? rate0 : 8192.0);
        // The client asks for a chance in percent ("chance"); an older client asks for a multiplier ("mult").
        double wanted;
        if (req.has("chance")) wanted = req.get("chance").getAsDouble() / 100.0;
        else wanted = (req.has("mult") ? req.get("mult").getAsInt() : 1000) * base0;
        double maxP = Math.min(1.0, Math.max(0.0, cfg.boostMaxChancePercent / 100.0));
        double target = Math.max(base0, Math.min(maxP, wanted));

        JsonObject out = new JsonObject();
        out.addProperty("t", "boost");
        if (!cfg.boostEnabled) {
            ACTIVE.remove(player.getUuid());
            out.addProperty("on", false);
            out.addProperty("msg", "The shiny boost is disabled on this server.");
            ServerNet.reply(player, out);
            return;
        }
        if (!mayBoost(player)) {
            ACTIVE.remove(player.getUuid());
            out.addProperty("on", false);
            out.addProperty("msg", "You are not allowed to use the shiny boost on this server.");
            ServerNet.reply(player, out);
            return;
        }
        long now = System.currentTimeMillis();
        Long last = LAST.get(player.getUuid());
        if (last != null && now - last < 500) return; // ignore double clicks
        LAST.put(player.getUuid(), now);

        if (on) {
            Filter filter = Filter.parse(req.get("filter"));
            Quality quality = cfg.boostQualityEnabled ? Quality.parse(req.get("quality")) : null;
            Spawns spawns = cfg.boostSpawnEnabled ? Spawns.parse(req.get("spawns")) : null;
            ACTIVE.put(player.getUuid(), new Boost(target, filter, quality, spawns));
            double pct = Math.round(target * 1000.0) / 10.0;
            out.addProperty("msg", "Boost ON: " + pct + "% shiny for "
                    + (filter == null ? "all the wild Pokémon" : "the selected wild Pokémon") + " around you"
                    + (quality != null && quality.any() ? ", quality boost on" : "")
                    + (spawns != null && !spawns.cats().isEmpty() ? ", extra legendary spawns on" : "") + ".");
            ShinyControlMod.LOGGER.info("{} turned the shiny boost ON ({}% per wild Pokémon, filter: {})",
                    player.getName().getString(), pct, filter == null ? "none (all)" : filter.describe());
        } else {
            ACTIVE.remove(player.getUuid());
            out.addProperty("msg", "Shiny boost OFF.");
            ShinyControlMod.LOGGER.info("{} turned the shiny boost OFF", player.getName().getString());
        }
        out.addProperty("on", on);
        out.addProperty("chance", Math.round(target * 1000.0) / 10.0);
        ServerNet.reply(player, out);
    }

    private static boolean mayBoost(ServerPlayerEntity player) {
        ControlConfig cfg = ControlConfig.get();
        java.util.List<String> list = cfg.boostAllowedPlayers;
        String name = player.getName().getString().toLowerCase(Locale.ROOT);
        if (list != null && !list.isEmpty()) { // a list restricts the boost to these players
            for (String s : list) if (s != null && s.trim().toLowerCase(Locale.ROOT).equals(name)) return true;
            return false;
        }
        if (cfg.boostRequireOp) {
            return player.getServer() != null && player.getServer().getPlayerManager().isOperator(player.getGameProfile());
        }
        return true; // empty list and no op requirement: every player who has the client mod
    }

    // ------------------------------------------------------------------ the extra roll
    static Boost boostOf(UUID id) {
        return ACTIVE.get(id);
    }

    static void warnOnce(String key, String msg) {
        if (WARNED.add(key)) ShinyControlMod.LOGGER.warn("{}", msg);
    }

    private static void onLoad(Entity entity, ServerWorld world) {
        try {
            if (!isPokemonEntity(entity)) return;
            if (BoostSpawner.captured(entity)) { /* a Pokémon our own spawner just created: it is tracked and tagged */ }
            else if (entity.getCommandTags().contains(BoostSpawner.TAG)) {
                // a temporary boosted spawn left over from a previous session: remove it
                world.getServer().execute(entity::discard);
                return;
            }
            if (entity.getCommandTags().contains(TAG)) return; // already handled (saved with the entity)
            entity.addCommandTag(TAG);                          // so a reload of the chunk never rolls it again
            if (ACTIVE.isEmpty()) return;
            if (entity instanceof TameableEntity t && t.getOwnerUuid() != null) return; // someone's own Pokémon

            ControlConfig cfg = ControlConfig.get();
            PlayerEntity nearest = world.getClosestPlayer(entity.getX(), entity.getY(), entity.getZ(), cfg.boostRadius, false);
            if (nearest == null) return;
            Boost boost = ACTIVE.get(nearest.getUuid());
            if (boost == null) return; // the nearest player has no boost: leave it alone
            double wantedChance = boost.chance();

            Object pokemon = entity.getClass().getMethod("getPokemon").invoke(entity);
            if (pokemon == null) return;
            if (boost.filter() != null && !boost.filter().matches(pokemon)) return; // not one of the selected Pokémon

            Method getShiny = pokemon.getClass().getMethod("getShiny");
            if (!(Boolean) getShiny.invoke(pokemon)) {
                Float rate = ShinyRate.currentRate();
                double base = 1.0 / (rate != null && rate > 0 ? rate : 8192.0);
                double target = Math.min(1.0, wantedChance);
                double extra = target > base ? (target - base) / (1.0 - base) : 0.0; // chance of the additional roll
                if (world.getRandom().nextDouble() < extra) {
                    pokemon.getClass().getMethod("setShiny", boolean.class).invoke(pokemon, true);
                    if (!loggedFirst) {
                        loggedFirst = true;
                        ShinyControlMod.LOGGER.info("Shiny boost: made a {} shiny near {} (wanted chance {})",
                                entity.getName().getString(), nearest.getName().getString(), wantedChance);
                    }
                }
            }
            if (boost.quality() != null && boost.quality().any()) boost.quality().apply(pokemon, world);
        } catch (Throwable t) {
            ShinyControlMod.LOGGER.warn("Shiny boost roll failed: {}", t.toString());
        }
    }

    static boolean isPokemonEntity(Entity e) {
        if (!classLookedUp) {
            classLookedUp = true;
            try {
                pokemonEntityClass = Class.forName(POKEMON_ENTITY, false, PlayerBoost.class.getClassLoader());
            } catch (Throwable t) {
                pokemonEntityClass = null;
            }
        }
        return pokemonEntityClass != null && pokemonEntityClass.isInstance(e);
    }

    // ------------------------------------------------------------------ which Pokémon are boosted
    /** null filter = every Pokémon. Otherwise a Pokémon is boosted if it matches ANY selected type, category or species. */
    private record Filter(Set<String> types, Set<String> cats, Set<String> species) {
        static Filter parse(JsonElement e) {
            if (e == null || !e.isJsonObject()) return null;
            JsonObject o = e.getAsJsonObject();
            if (!o.has("enabled") || !o.get("enabled").getAsBoolean()) return null;
            return new Filter(set(o, "types"), set(o, "cats"), set(o, "species"));
        }

        static Set<String> set(JsonObject o, String key) {
            Set<String> out = new HashSet<>();
            if (o.has(key) && o.get(key).isJsonArray()) {
                JsonArray a = o.getAsJsonArray(key);
                for (JsonElement x : a) out.add(norm(x.getAsString()));
            }
            out.remove("");
            return out;
        }

        String describe() {
            return "types=" + types + " categories=" + cats + " species=" + species;
        }

        boolean matches(Object pokemon) {
            try {
                Object species = call(pokemon, "getSpecies");
                if (!this.species.isEmpty() && species != null) {
                    if (this.species.contains(norm(String.valueOf(call(species, "getName"))))) return true;
                }
                if (!types.isEmpty()) {
                    Object ts = call(pokemon, "getTypes");
                    if (ts instanceof Iterable<?> it) {
                        for (Object t : it) if (types.contains(norm(String.valueOf(call(t, "getName"))))) return true;
                    } else if (species != null) {
                        Object p = call(species, "getPrimaryType"), q = call(species, "getSecondaryType");
                        if (p != null && types.contains(norm(String.valueOf(call(p, "getName"))))) return true;
                        if (q != null && types.contains(norm(String.valueOf(call(q, "getName"))))) return true;
                    }
                }
                if (!cats.isEmpty()) {
                    Set<String> labels = new HashSet<>();
                    addLabels(labels, species);
                    addLabels(labels, call(pokemon, "getForm"));
                    boolean legendary = Boolean.TRUE.equals(call(pokemon, "isLegendary")) || labels.contains("legendary");
                    boolean mythical = Boolean.TRUE.equals(call(pokemon, "isMythical")) || labels.contains("mythical");
                    boolean ub = labels.contains("ultrabeast");
                    boolean paradox = labels.contains("paradox");
                    if (cats.contains("legendary") && legendary) return true;
                    if (cats.contains("mythical") && mythical) return true;
                    if (cats.contains("ultrabeast") && ub) return true;
                    if (cats.contains("paradox") && paradox) return true;
                    if (cats.contains("normal") && !legendary && !mythical && !ub && !paradox) return true;
                }
            } catch (Throwable t) {
                // unreadable: not matching
            }
            return false;
        }

        private static void addLabels(Set<String> out, Object holder) {
            if (holder == null) return;
            Object labels = call(holder, "getLabels");
            if (labels instanceof Collection<?> c) for (Object o : c) out.add(norm(String.valueOf(o)));
        }
    }


    // ------------------------------------------------------------------ quality of the boosted Pokémon
    /**
     * Every field is a separate roll, so boosts stack on one Pokémon (shiny + alpha + giant + perfect IVs...).
     * ivs = minimum perfect (31) IVs given with chance ivsChance %, ha = hidden ability chance %,
     * size = 0 off / 1 big / 2 small / 3 big or small / 4 gigantic with chance sizeChance %, alpha = alpha chance %.
     */
    record Quality(int ivs, int ivsChance, int ha, int size, int sizeChance, int alpha) {
        static Quality parse(JsonElement e) {
            if (e == null || !e.isJsonObject()) return null;
            JsonObject o = e.getAsJsonObject();
            ControlConfig cfg = ControlConfig.get();
            int ivs = Math.max(0, Math.min(Math.min(6, cfg.boostMaxPerfectIvs), o.has("ivs") ? o.get("ivs").getAsInt() : 0));
            int ivsChance = Math.max(0, Math.min(100, o.has("ivsChance") ? o.get("ivsChance").getAsInt() : 100));
            int ha = Math.max(0, Math.min(100, o.has("ha") ? o.get("ha").getAsInt() : 0));
            int size = Math.max(0, Math.min(4, o.has("size") ? o.get("size").getAsInt() : 0));
            int sizeChance = Math.max(0, Math.min(100, o.has("sizeChance") ? o.get("sizeChance").getAsInt() : 100));
            int alpha = Math.max(0, Math.min(100, o.has("alpha") ? o.get("alpha").getAsInt() : 0));
            return new Quality(ivs, ivsChance, ha, size, sizeChance, alpha);
        }

        boolean any() {
            return ivs > 0 || ha > 0 || size > 0 || alpha > 0;
        }

        void apply(Object pokemon, ServerWorld world) {
            if (ivs > 0 && world.getRandom().nextInt(100) < ivsChance) {
                try {
                    perfectIvs(pokemon, ivs, world);
                } catch (Throwable t) {
                    warnOnce("ivs", "Quality boost: could not set IVs (" + t + ")");
                }
            }
            if (ha > 0 && world.getRandom().nextInt(100) < ha) {
                try {
                    hiddenAbility(pokemon);
                } catch (Throwable t) {
                    warnOnce("ha", "Quality boost: could not set the hidden ability (" + t + ")");
                }
            }
            if (size > 0 && world.getRandom().nextInt(100) < sizeChance) {
                try {
                    int mode = size == 3 ? 1 + world.getRandom().nextInt(2) : size;
                    float scale = switch (mode) {
                        case 1 -> 1.5f + world.getRandom().nextFloat() * 0.7f;
                        case 2 -> 0.4f + world.getRandom().nextFloat() * 0.3f;
                        default -> 2.5f + world.getRandom().nextFloat() * 1.0f; // gigantic
                    };
                    scale = Math.min(scale, (float) ControlConfig.get().boostMaxScale);
                    pokemon.getClass().getMethod("setScaleModifier", float.class).invoke(pokemon, scale);
                } catch (Throwable t) {
                    warnOnce("size", "Quality boost: could not set the size (" + t + ")");
                }
            }
            if (alpha > 0 && world.getRandom().nextInt(100) < alpha) {
                try {
                    String prop = ControlConfig.get().boostAlphaProperty;
                    if (prop != null && !prop.isBlank()) {
                        applyProperties(pokemon, prop.trim());
                        if (WARNED.add("alpha-first")) ShinyControlMod.LOGGER.info("Quality boost: applied '{}' to a Pokémon (alpha)", prop);
                    }
                } catch (Throwable t) {
                    warnOnce("alpha", "Quality boost: could not make a Pokémon alpha (" + t + ")");
                }
            }
        }

        private static final String[] STATS = {"HP", "ATTACK", "DEFENCE", "SPECIAL_ATTACK", "SPECIAL_DEFENCE", "SPEED"};

        private static void perfectIvs(Object pokemon, int wanted, ServerWorld world) throws Exception {
            Class<?> statsC = Class.forName("com.cobblemon.mod.common.api.pokemon.stats.Stats");
            Object ivs = call(pokemon, "getIvs");
            Method get = null;
            for (Method m : ivs.getClass().getMethods()) {
                if (m.getName().equals("get") && m.getParameterCount() == 1 && m.getParameterTypes()[0].isAssignableFrom(statsC)) { get = m; break; }
            }
            Method setIv = null;
            for (Method m : pokemon.getClass().getMethods()) {
                if (m.getName().equals("setIV") && m.getParameterCount() == 2) { setIv = m; break; }
            }
            if (get == null || setIv == null) throw new NoSuchMethodException("IV accessors");
            java.util.List<Object> notPerfect = new java.util.ArrayList<>();
            int perfect = 0;
            for (String name : STATS) {
                Object stat = Enum.valueOf((Class) statsC, name);
                Object v = get.invoke(ivs, stat);
                if (v instanceof Number n && n.intValue() >= 31) perfect++; else notPerfect.add(stat);
            }
            java.util.Collections.shuffle(notPerfect, new java.util.Random(world.getRandom().nextLong()));
            for (Object stat : notPerfect) {
                if (perfect >= wanted) break;
                setIv.invoke(pokemon, stat, 31);
                perfect++;
            }
        }

        private static void hiddenAbility(Object pokemon) throws Exception {
            Object species = call(pokemon, "getSpecies");
            Object pool = call(species, "getAbilities");
            String name = null;
            if (pool instanceof Iterable<?> it) {
                for (Object potential : it) {
                    Object type = call(potential, "getType");
                    if (type != null && type.getClass().getSimpleName().toLowerCase(Locale.ROOT).contains("hidden")) {
                        Object template = call(potential, "getTemplate");
                        Object n = call(template, "getName");
                        if (n != null) { name = String.valueOf(n); break; }
                    }
                }
            }
            if (name == null) return; // this species has no hidden ability
            applyProperties(pokemon, "ability=" + name);
        }

        /** Applies Cobblemon property text (like the spawn commands use) to a Pokémon. */
        static void applyProperties(Object pokemon, String text) throws Exception {
            Class<?> ppC = Class.forName("com.cobblemon.mod.common.api.pokemon.PokemonProperties");
            Object companion = ppC.getField("Companion").get(null);
            Object props = null;
            for (Method m : companion.getClass().getMethods()) {
                if (!m.getName().equals("parse")) continue;
                if (m.getParameterCount() == 1 && m.getParameterTypes()[0] == String.class) { props = m.invoke(companion, text); break; }
                if (m.getParameterCount() == 3 && m.getParameterTypes()[0] == String.class) { props = m.invoke(companion, text, " ", "="); break; }
            }
            if (props == null) throw new NoSuchMethodException("PokemonProperties.parse");
            for (Method m : props.getClass().getMethods()) {
                if (m.getName().equals("apply") && m.getParameterCount() == 1 && m.getParameterTypes()[0].isInstance(pokemon)) {
                    m.invoke(props, pokemon);
                    return;
                }
            }
            throw new NoSuchMethodException("PokemonProperties.apply");
        }
    }

    // ------------------------------------------------------------------ extra spawns of special Pokémon around the player
    /** cats = ultrabeast / legendary / mythical / paradox; minutes = average time between two extra spawns; levels. */
    record Spawns(Set<String> cats, int minutes, int levelMin, int levelMax) {
        static Spawns parse(JsonElement e) {
            if (e == null || !e.isJsonObject()) return null;
            JsonObject o = e.getAsJsonObject();
            Set<String> cats = Filter.set(o, "cats");
            if (cats.isEmpty()) return null;
            ControlConfig cfg = ControlConfig.get();
            int minutes = Math.max(cfg.boostSpawnMinMinutes, Math.min(240, o.has("minutes") ? o.get("minutes").getAsInt() : 10));
            int lmin = Math.max(1, Math.min(100, o.has("lmin") ? o.get("lmin").getAsInt() : 50));
            int lmax = Math.max(lmin, Math.min(100, o.has("lmax") ? o.get("lmax").getAsInt() : 70));
            return new Spawns(cats, minutes, lmin, lmax);
        }
    }

    static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    static Object call(Object target, String method) {
        if (target == null) return null;
        try {
            Method m = target.getClass().getMethod(method);
            return m.invoke(target);
        } catch (Throwable t) {
            return null;
        }
    }
}
