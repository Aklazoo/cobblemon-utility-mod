package com.example.shinycontrol;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContextParameterSet;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Exact content of a Lootr chest for one player.
 * <ol>
 *   <li>If this player already opened the chest, Lootr keeps their inventory: it is read as is (the truth).</li>
 *   <li>Otherwise Lootr's own filler ({@code DefaultLootFiller.unpackLootTable}) is run on a scratch inventory. It is
 *       the very code Lootr runs when the chest is opened, and our seed hook makes its random seed depend only on
 *       (chest seed, player), so the result is what the player will get. It is run twice and must agree.</li>
 *   <li>If Lootr's classes cannot be used, a rebuilt roll of the loot table is the last resort.</li>
 * </ol>
 */
final class LootrPreview {
    private static final String P = "noobanidus.mods.lootr.";
    private static boolean ready, broken;
    private static Method mResolve, mHasBeenOpened, mGetData, mGetInvByUuid, mContents, mGetFiller, mUnpack, mSize, mGetSeed;
    private static Object filler;
    /** True while we run Lootr's filler ourselves, so the opening check does not react to it. */
    static boolean busy = false;
    private static int checks = 0;

    private LootrPreview() {}

    private static void init() throws Exception {
        if (ready) return;
        Class<?> api = Class.forName(P + "common.api.LootrAPI");
        Class<?> provider = Class.forName(P + "common.api.data.ILootrInfoProvider");
        Class<?> savedData = Class.forName(P + "common.api.data.ILootrSavedData");
        Class<?> lootrInv = Class.forName(P + "common.api.data.inventory.ILootrInventory");
        Class<?> fillerCls = Class.forName(P + "common.api.data.DefaultLootFiller");
        mResolve = api.getMethod("resolveBlockEntity", BlockEntity.class);
        mGetData = api.getMethod("getData", provider);
        mGetSeed = api.getMethod("getLootSeed", long.class);
        mHasBeenOpened = provider.getMethod("hasBeenOpened");
        mSize = provider.getMethod("getInfoContainerSize");
        mGetInvByUuid = savedData.getMethod("getInventory", UUID.class);
        mContents = lootrInv.getMethod("getInventoryContents");
        mGetFiller = fillerCls.getMethod("getInstance");
        mUnpack = fillerCls.getMethod("unpackLootTable", provider, PlayerEntity.class, Inventory.class);
        filler = mGetFiller.invoke(null);
        ready = true;
    }

    /** Items (registry id -> count) this player gets from the chest, or null if it cannot be known exactly. */
    static Map<String, Integer> items(ServerWorld world, ServerPlayerEntity player, BlockEntity be) {
        if (broken) return null;
        try {
            init();
            Object provider = mResolve.invoke(null, be);
            if (provider != null) {
                Map<String, Integer> opened = alreadyOpened(provider, player);
                if (opened != null) return opened;
                Map<String, Integer> rolled = roll(provider, player);
                if (rolled != null) return rolled;
            }
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            broken = true; // Lootr changed: use the fallback only
        } catch (Throwable t) {
            // fall through to the fallback
        }
        return legacy(world, player, be);
    }

    private static Map<String, Integer> alreadyOpened(Object provider, ServerPlayerEntity player) throws Exception {
        if (!(Boolean) mHasBeenOpened.invoke(provider)) return null; // nobody opened it: no stored data to read
        Object data = mGetData.invoke(null, provider);
        if (data == null) return null;
        Object inv = mGetInvByUuid.invoke(data, player.getUuid());
        if (inv == null) return null;
        Object contents = mContents.invoke(inv);
        Map<String, Integer> m = new HashMap<>();
        for (Object o : (Iterable<?>) contents) tally(m, (ItemStack) o);
        return m;
    }

    private static Map<String, Integer> roll(Object provider, ServerPlayerEntity player) throws Exception {
        int size = (Integer) mSize.invoke(provider);
        if (size <= 0 || size > 256) size = 27;
        Map<String, Integer> a = rollOnce(provider, player, size);
        Map<String, Integer> b = rollOnce(provider, player, size);
        return a.equals(b) ? a : null; // different = the seed hook is not active
    }

    private static Map<String, Integer> rollOnce(Object provider, PlayerEntity player, int size) throws Exception {
        boolean wasBusy = busy;
        UUID prev = LootrContext.get();
        busy = true;
        LootrContext.set(player.getUuid());
        try {
            SimpleInventory scratch = new SimpleInventory(size);
            mUnpack.invoke(filler, provider, player, scratch);
            Map<String, Integer> m = new HashMap<>();
            for (int i = 0; i < scratch.size(); i++) tally(m, scratch.getStack(i));
            return m;
        } finally {
            busy = wasBusy;
            if (prev == null) LootrContext.clear(); else LootrContext.set(prev);
        }
    }

    private static void tally(Map<String, Integer> m, ItemStack st) {
        if (st == null || st.isEmpty()) return;
        m.merge(Registries.ITEM.getId(st.getItem()).toString(), st.getCount(), Integer::sum);
    }

    /**
     * Runs after Lootr really fills a chest for a player: compares what they got with what the preview would have
     * said and logs the verdict (first 25 times), to prove or disprove the preview on the real server.
     */
    static void check(Object provider, PlayerEntity player, Inventory container) {
        if (busy || checks >= 25 || !(player instanceof ServerPlayerEntity)) return;
        try {
            init();
            Map<String, Integer> actual = new HashMap<>();
            for (int i = 0; i < container.size(); i++) tally(actual, container.getStack(i));
            int size = Math.max(1, container.size());
            Map<String, Integer> preview = rollOnce(provider, player, size);
            checks++;
            if (actual.equals(preview)) {
                ShinyControlMod.LOGGER.info("Lootr preview check #{}: MATCH ({} item kinds)", checks, actual.size());
            } else {
                ShinyControlMod.LOGGER.warn("Lootr preview check #{}: MISMATCH actual={} preview={}", checks, actual, preview);
            }
        } catch (Throwable t) {
            ShinyControlMod.LOGGER.warn("Lootr preview check failed: {}", t.toString());
        }
    }

    // ---------------------------------------------------------------- last resort: rebuilt roll
    private static Map<String, Integer> legacy(ServerWorld world, ServerPlayerEntity player, BlockEntity be) {
        try {
            NbtCompound nbt = be.createNbt(world.getRegistryManager());
            if (!nbt.contains("LootTable", NbtElement.STRING_TYPE)) return null;
            Identifier table = Identifier.tryParse(nbt.getString("LootTable"));
            if (table == null) return null;
            long chestSeed = nbt.getLong("LootTableSeed");
            Long seed = legacySeed(chestSeed, player);
            if (seed == null) return null;
            LootTable lt = world.getServer().getReloadableRegistries()
                    .getLootTable(RegistryKey.of(RegistryKeys.LOOT_TABLE, table));
            if (lt == LootTable.EMPTY) return null;
            LootContextParameterSet params = new LootContextParameterSet.Builder(world)
                    .add(LootContextParameters.ORIGIN, Vec3d.ofCenter(be.getPos()))
                    .luck(player.getLuck())
                    .add(LootContextParameters.THIS_ENTITY, player)
                    .build(LootContextTypes.CHEST);
            SimpleInventory inv = new SimpleInventory(27);
            lt.supplyInventory(inv, params, seed);
            Map<String, Integer> m = new HashMap<>();
            for (int i = 0; i < inv.size(); i++) tally(m, inv.getStack(i));
            return m;
        } catch (Throwable t) {
            return null;
        }
    }

    private static Long legacySeed(long chestSeed, ServerPlayerEntity player) {
        try {
            init();
            UUID prev = LootrContext.get();
            LootrContext.set(player.getUuid());
            try {
                long a = (Long) mGetSeed.invoke(null, chestSeed);
                long b = (Long) mGetSeed.invoke(null, chestSeed);
                return a == b ? a : null;
            } finally {
                if (prev == null) LootrContext.clear(); else LootrContext.set(prev);
            }
        } catch (Throwable t) {
            return null;
        }
    }
}
