package com.example.shinycontrol;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

/**
 * /shinyrate                         status
 * /shinyrate multiplier <x>          permanent multiplier (saved, survives restarts)
 * /shinyrate set <N>                 make shiny odds 1/N (computes the multiplier for you)
 * /shinyrate boost <x> <seconds>     temporary boost, announced to all players
 * /shinyrate boost stop              end the boost now
 * /shinyrate reset                   back to Cobblemon's own rate
 * Requires operator level 2 (the Exaroton console always has it).
 */
public final class ShinyCommand {
    private ShinyCommand() {}

    public static void register(CommandDispatcher<ServerCommandSource> d) {
        d.register(CommandManager.literal("shinyrate")
                .requires(src -> src.hasPermissionLevel(2))
                .executes(ctx -> status(ctx.getSource()))
                .then(CommandManager.literal("status").executes(ctx -> status(ctx.getSource())))
                .then(CommandManager.literal("multiplier")
                        .then(CommandManager.argument("value", DoubleArgumentType.doubleArg(1.0, 1000.0))
                                .executes(ctx -> multiplier(ctx.getSource(), DoubleArgumentType.getDouble(ctx, "value")))))
                .then(CommandManager.literal("set")
                        .then(CommandManager.argument("denominator", DoubleArgumentType.doubleArg(1.0, 1000000.0))
                                .executes(ctx -> setDenominator(ctx.getSource(), DoubleArgumentType.getDouble(ctx, "denominator")))))
                .then(CommandManager.literal("boost")
                        .then(CommandManager.literal("stop").executes(ctx -> boostStop(ctx.getSource())))
                        .then(CommandManager.argument("multiplier", DoubleArgumentType.doubleArg(1.0, 1000.0))
                                .then(CommandManager.argument("seconds", IntegerArgumentType.integer(1, 86400))
                                        .executes(ctx -> boost(ctx.getSource(),
                                                DoubleArgumentType.getDouble(ctx, "multiplier"),
                                                IntegerArgumentType.getInteger(ctx, "seconds"))))))
                .then(CommandManager.literal("reset").executes(ctx -> multiplier(ctx.getSource(), 1.0))));
    }

    private static int status(ServerCommandSource src) {
        Float base = ShinyRate.baseRate();
        Float current = ShinyRate.currentRate();
        if (base == null || current == null) return unavailable(src);
        StringBuilder sb = new StringBuilder();
        sb.append("Cobblemon base: 1/").append(Math.round(base))
                .append(" | permanent multiplier: x").append(fmt(ShinyRate.persistentMultiplier()));
        if (ShinyRate.boostActive()) {
            sb.append(" | boost: x").append(fmt(ShinyRate.boostMultiplier()))
                    .append(" (").append(ShinyRate.boostSecondsLeft()).append("s left)");
        }
        sb.append(" | current odds: 1/").append(Math.round(current));
        String msg = sb.toString();
        src.sendFeedback(() -> Text.literal(msg), false);
        return 1;
    }

    private static int multiplier(ServerCommandSource src, double value) {
        if (!ShinyRate.setMultiplier(value)) return unavailable(src);
        Float cur = ShinyRate.currentRate();
        String msg = "Permanent multiplier set to x" + fmt(value) + (cur == null ? "" : " (odds now 1/" + Math.round(cur) + ")");
        src.sendFeedback(() -> Text.literal(msg), true);
        return 1;
    }

    private static int setDenominator(ServerCommandSource src, double n) {
        Float base = ShinyRate.baseRate();
        if (base == null) return unavailable(src);
        double mult = Math.max(1.0, Math.min(1000.0, base / n));
        return multiplier(src, mult);
    }

    private static int boost(ServerCommandSource src, double mult, int seconds) {
        if (!ShinyRate.startBoost(mult, seconds)) return unavailable(src);
        Float cur = ShinyRate.currentRate();
        ShinyRate.broadcast("§6[Shiny] §fShiny boost x" + fmt(mult) + " for " + formatDuration(seconds)
                + (cur == null ? "" : " §7(odds 1/" + Math.round(cur) + ")") + "§f!");
        src.sendFeedback(() -> Text.literal("Boost started."), false);
        return 1;
    }

    private static int boostStop(ServerCommandSource src) {
        boolean was = ShinyRate.stopBoost();
        if (was) ShinyRate.broadcast("§6[Shiny] §fThe shiny boost has ended.");
        src.sendFeedback(() -> Text.literal(was ? "Boost stopped." : "No boost was running."), false);
        return 1;
    }

    private static int unavailable(ServerCommandSource src) {
        src.sendError(Text.literal("Cobblemon's shiny rate could not be read or changed (Cobblemon missing or API changed)."));
        return 0;
    }

    private static String fmt(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.format("%.2f", v);
    }

    private static String formatDuration(int s) {
        if (s >= 3600) return (s / 3600) + "h" + ((s % 3600) / 60 > 0 ? " " + ((s % 3600) / 60) + "min" : "");
        if (s >= 60) return (s / 60) + "min" + (s % 60 > 0 ? " " + (s % 60) + "s" : "");
        return s + "s";
    }
}
