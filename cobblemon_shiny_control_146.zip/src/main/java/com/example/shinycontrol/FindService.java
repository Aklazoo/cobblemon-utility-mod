package com.example.shinycontrol;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Scans the Pokémon loaded in the player's world and returns the interesting ones.
 * Filter strings: all | shiny | legendary | ha | iv:<1-6> | species:<name>
 */
public final class FindService {
    private record Hit(PokemonReader.Info info, double dist, double x, double y, double z) {}

    private FindService() {}

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    public static JsonObject find(ServerPlayerEntity player, String filter) {
        ControlConfig cfg = ControlConfig.get();
        ServerWorld world = (ServerWorld) player.getWorld();
        Vec3d origin = player.getPos();
        double maxSq = (double) cfg.findMaxRadius * cfg.findMaxRadius;

        String f = filter == null ? "all" : filter.trim().toLowerCase(Locale.ROOT);
        int minIv = 0;
        String species = null;
        if (f.startsWith("iv:")) {
            try {
                minIv = Math.max(1, Math.min(6, Integer.parseInt(f.substring(3).trim())));
            } catch (NumberFormatException e) {
                minIv = 6;
            }
            f = "iv";
        } else if (f.startsWith("species:")) {
            species = norm(f.substring(8));
            f = "species";
        }

        List<Hit> hits = new ArrayList<>();
        boolean sawAny = false;
        for (Entity e : world.iterateEntities()) {
            if (e.isRemoved() || !PokemonReader.isPokemon(e)) continue;
            sawAny = true;
            double d2 = e.squaredDistanceTo(origin);
            if (d2 > maxSq) continue;
            PokemonReader.Info info = PokemonReader.read(e);
            if (info == null) continue;
            if (info.owned() && !cfg.findIncludeOwned) continue;
            if (!matches(info, f, minIv, species, cfg)) continue;
            hits.add(new Hit(info, Math.sqrt(d2), e.getX(), e.getY(), e.getZ()));
        }
        hits.sort((a, b) -> Double.compare(a.dist(), b.dist()));

        JsonObject out = new JsonObject();
        out.addProperty("t", "find");
        out.addProperty("radius", cfg.findMaxRadius);
        out.addProperty("total", hits.size());
        out.addProperty("sawAny", sawAny);
        JsonArray arr = new JsonArray();
        int shown = Math.min(hits.size(), cfg.findMaxResults);
        for (int i = 0; i < shown; i++) arr.add(toJson(hits.get(i), origin, cfg));
        out.add("hits", arr);
        return out;
    }

    private static boolean matches(PokemonReader.Info i, String f, int minIv, String species, ControlConfig cfg) {
        switch (f) {
            case "shiny":
                return i.shiny();
            case "legendary":
                return i.legendary();
            case "ha":
                return i.hiddenAbility();
            case "iv":
                return i.ivKnown() && i.perfect() >= minIv;
            case "species":
                return species != null && !species.isEmpty()
                        && (norm(i.speciesId()).equals(species) || norm(i.name()).equals(species));
            default:
                return i.shiny() || i.legendary() || i.hiddenAbility()
                        || (i.ivKnown() && i.perfect() >= cfg.findDefaultMinPerfectIvs);
        }
    }

    private static JsonObject toJson(Hit h, Vec3d origin, ControlConfig cfg) {
        PokemonReader.Info i = h.info();
        JsonObject o = new JsonObject();
        o.addProperty("name", i.name());
        o.addProperty("level", i.level());
        o.addProperty("shiny", i.shiny());
        o.addProperty("legendary", i.legendary());
        o.addProperty("ha", i.hiddenAbility());
        o.addProperty("dist", (int) h.dist());
        o.addProperty("dir", direction(origin, h));
        if (i.ivKnown() && !"none".equals(cfg.findIvDisplay)) {
            o.addProperty("perfect", i.perfect());
            if ("full".equals(cfg.findIvDisplay)) o.addProperty("iv", i.ivText());
        }
        switch (cfg.findCoords) {
            case "exact" -> {
                o.addProperty("x", (int) h.x());
                o.addProperty("y", (int) h.y());
                o.addProperty("z", (int) h.z());
            }
            case "approx" -> {
                o.addProperty("x", (int) (Math.round(h.x() / 50.0) * 50));
                o.addProperty("z", (int) (Math.round(h.z() / 50.0) * 50));
                o.addProperty("approx", true);
            }
            default -> { }
        }
        return o;
    }

    private static String direction(Vec3d o, Hit h) {
        double ang = Math.toDegrees(Math.atan2(h.z() - o.z, h.x() - o.x)); // 0 = east, 90 = south
        String[] names = {"E", "SE", "S", "SW", "W", "NW", "N", "NE"};
        return names[((int) Math.round(ang / 45.0) + 8) % 8];
    }
}
