package com.example.shinycontrol;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.serialization.JsonOps;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.item.Item;
import net.minecraft.loot.LootTable;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Predicate;

/**
 * "What could this chest contain?" for chests whose real content does not exist yet (Lootr gives every player a
 * freshly rolled inventory when the chest is opened, so nothing can be read beforehand).
 * <ul>
 *   <li>{@link #findTable}: looks through the chest's saved data for any text that is a real loot table id.
 *       This needs no knowledge of the Lootr field names.</li>
 *   <li>{@link #chance}: walks that loot table and estimates the probability that one opening gives at least one
 *       item accepted by the predicate. Conditions (luck, random chance...) are ignored, so it is an estimate.</li>
 * </ul>
 */
final class LootChance {
    private static final Map<String, JsonObject> TABLE_JSON = new HashMap<>();
    private static boolean dumpedNbt = false;

    private LootChance() {}

    static void clearCache() {
        TABLE_JSON.clear();
    }

    /** The loot table id stored in this block entity, or null. */
    static Identifier findTable(MinecraftServer server, BlockEntity be) {
        try {
            NbtCompound nbt = be.createNbt(server.getRegistryManager());
            if (!dumpedNbt && Registries.BLOCK_ENTITY_TYPE.getId(be.getType()).getNamespace().equals("lootr")) {
                dumpedNbt = true;
                ShinyControlMod.LOGGER.info("First Lootr container data seen (for debugging): {} at {}", nbt, be.getPos());
            }
            return scan(server, nbt, 0);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Identifier scan(MinecraftServer server, NbtElement e, int depth) {
        if (depth > 6 || e == null) return null;
        if (e instanceof NbtString s) {
            String v = s.asString();
            if (v.indexOf(':') > 0 && v.indexOf('/') > 0 && v.length() < 200) {
                Identifier id = Identifier.tryParse(v);
                if (id != null && exists(server, id)) return id;
            }
            return null;
        }
        if (e instanceof NbtCompound c) {
            for (String k : c.getKeys()) {
                Identifier r = scan(server, c.get(k), depth + 1);
                if (r != null) return r;
            }
        } else if (e instanceof NbtList l) {
            for (NbtElement x : l) {
                Identifier r = scan(server, x, depth + 1);
                if (r != null) return r;
            }
        }
        return null;
    }

    private static boolean exists(MinecraftServer server, Identifier id) {
        try {
            return server.getReloadableRegistries().getLootTable(RegistryKey.of(RegistryKeys.LOOT_TABLE, id)) != LootTable.EMPTY;
        } catch (Throwable t) {
            return false;
        }
    }

    private static JsonObject tableJson(MinecraftServer server, Identifier id) {
        String key = id.toString();
        if (TABLE_JSON.containsKey(key)) return TABLE_JSON.get(key);
        JsonObject out = null;
        try {
            LootTable lt = server.getReloadableRegistries().getLootTable(RegistryKey.of(RegistryKeys.LOOT_TABLE, id));
            if (lt != LootTable.EMPTY) {
                JsonElement je = LootTable.CODEC
                        .encodeStart(RegistryOps.of(JsonOps.INSTANCE, server.getRegistryManager()), lt)
                        .result().orElse(null);
                if (je != null && je.isJsonObject()) out = je.getAsJsonObject();
            }
        } catch (Throwable t) {
            ShinyControlMod.LOGGER.warn("Could not read loot table {}", id, t);
        }
        TABLE_JSON.put(key, out);
        return out;
    }

    /** Probability (0..1) that one opening of this loot table yields at least one accepted item. */
    static double chance(MinecraftServer server, Identifier table, Predicate<String> idMatches) {
        JsonObject t = tableJson(server, table);
        return t == null ? 0 : tableChance(server, t, idMatches, 0);
    }

    private static double tableChance(MinecraftServer server, JsonObject table, Predicate<String> m, int depth) {
        if (depth > 5 || !table.has("pools") || !table.get("pools").isJsonArray()) return 0;
        double none = 1;
        for (JsonElement pe : table.getAsJsonArray("pools")) {
            if (!pe.isJsonObject()) continue;
            JsonObject pool = pe.getAsJsonObject();
            JsonArray entries = pool.has("entries") && pool.get("entries").isJsonArray() ? pool.getAsJsonArray("entries") : new JsonArray();
            double totalW = 0, hitW = 0;
            for (JsonElement ee : entries) {
                if (!ee.isJsonObject()) continue;
                JsonObject en = ee.getAsJsonObject();
                double w = en.has("weight") ? en.get("weight").getAsDouble() : 1;
                if (w <= 0) continue;
                totalW += w;
                hitW += w * entryChance(server, en, m, depth);
            }
            if (totalW <= 0) continue;
            double q = Math.min(1, hitW / totalW);
            double rolls = Math.max(0, number(pool.get("rolls"), 1));
            double poolP = 1 - Math.pow(1 - q, rolls);
            none *= (1 - poolP);
        }
        return 1 - none;
    }

    private static double entryChance(MinecraftServer server, JsonObject en, Predicate<String> m, int depth) {
        String type = en.has("type") ? en.get("type").getAsString() : "";
        switch (type) {
            case "minecraft:item":
                return en.has("name") && m.test(en.get("name").getAsString()) ? 1 : 0;
            case "minecraft:tag": {
                if (!en.has("name")) return 0;
                Identifier tid = Identifier.tryParse(en.get("name").getAsString());
                if (tid == null) return 0;
                var list = Registries.ITEM.getEntryList(TagKey.of(RegistryKeys.ITEM, tid));
                if (list.isEmpty()) return 0;
                int n = 0, hit = 0;
                for (var entry : list.get()) {
                    n++;
                    if (m.test(Registries.ITEM.getId(entry.value()).toString())) hit++;
                }
                return n == 0 ? 0 : (double) hit / n;
            }
            case "minecraft:loot_table": {
                JsonElement v = en.get("value");
                if (v == null) return 0;
                if (v.isJsonObject()) return tableChance(server, v.getAsJsonObject(), m, depth + 1);
                Identifier id = Identifier.tryParse(v.getAsString());
                if (id == null) return 0;
                JsonObject sub = tableJson(server, id);
                return sub == null ? 0 : tableChance(server, sub, m, depth + 1);
            }
            case "minecraft:alternatives":
            case "minecraft:group":
            case "minecraft:sequence": {
                if (!en.has("children") || !en.get("children").isJsonArray()) return 0;
                double none = 1;
                double best = 0;
                for (JsonElement ce : en.getAsJsonArray("children")) {
                    if (!ce.isJsonObject()) continue;
                    double c = entryChance(server, ce.getAsJsonObject(), m, depth + 1);
                    none *= (1 - c);
                    best = Math.max(best, c);
                }
                return type.equals("minecraft:alternatives") ? best : 1 - none;
            }
            default:
                return 0;
        }
    }

    /** Reads a number provider: a plain number, constant, uniform or binomial. */
    private static double number(JsonElement e, double dflt) {
        if (e == null || e.isJsonNull()) return dflt;
        if (e.isJsonPrimitive()) {
            try {
                return e.getAsDouble();
            } catch (Exception ex) {
                return dflt;
            }
        }
        if (!e.isJsonObject()) return dflt;
        JsonObject o = e.getAsJsonObject();
        String type = o.has("type") ? o.get("type").getAsString() : "";
        if (type.endsWith("uniform")) return (number(o.get("min"), 0) + number(o.get("max"), 0)) / 2;
        if (type.endsWith("binomial")) return number(o.get("n"), 0) * number(o.get("p"), 0);
        if (o.has("value")) return number(o.get("value"), dflt);
        return dflt;
    }

    static boolean unused(Item i) {
        return i == null;
    }
}
