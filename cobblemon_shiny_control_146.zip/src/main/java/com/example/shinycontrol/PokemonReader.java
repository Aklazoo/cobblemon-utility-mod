package com.example.shinycontrol;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Reads a Cobblemon Pokémon entity on the SERVER (where the real IVs and ability are known).
 * Everything is reflective: if Cobblemon changes a method, that field is simply unknown instead of crashing.
 */
final class PokemonReader {
    record Info(String name, String speciesId, int level, boolean shiny, boolean legendary, boolean hiddenAbility,
                int perfect, String ivText, boolean ivKnown, boolean owned) {}

    private static EntityType<?> type;
    private static boolean warned;

    private PokemonReader() {}

    static boolean isPokemon(Entity e) {
        if (type == null) {
            type = Registries.ENTITY_TYPE.getOrEmpty(Identifier.of("cobblemon", "pokemon")).orElse(null);
            if (type == null) return false;
        }
        return e.getType() == type;
    }

    static Info read(Entity e) {
        try {
            Object pokemon = call(e, "getPokemon");
            if (pokemon == null) return null;

            Object species = call(pokemon, "getSpecies");
            String name = "Pokémon";
            Object translated = call(species, "getTranslatedName");
            if (translated instanceof Text t) name = t.getString();
            String speciesId = name;
            Object rawId = call(species, "getName");
            if (rawId != null) {
                speciesId = String.valueOf(rawId);
                if (translated == null) name = speciesId;
            }

            Object lvl = call(pokemon, "getLevel");
            int level = lvl instanceof Number n ? n.intValue() : 0;
            boolean shiny = Boolean.TRUE.equals(call(pokemon, "getShiny"));
            boolean legendary = Boolean.TRUE.equals(call(pokemon, "isLegendary"))
                    || Boolean.TRUE.equals(call(pokemon, "isMythical"))
                    || hasLabel(species, "legendary") || hasLabel(species, "mythical");
            boolean owned = call(pokemon, "getOwnerUUID") != null;

            int perfect = 0;
            boolean ivKnown = false;
            StringBuilder iv = new StringBuilder();
            Object ivs = call(pokemon, "getIvs");
            if (ivs instanceof Iterable<?> it) {
                for (Object o : it) {
                    if (o instanceof Map.Entry<?, ?> en && en.getValue() instanceof Number num) {
                        ivKnown = true;
                        int v = num.intValue();
                        if (v >= 31) perfect++;
                        if (iv.length() > 0) iv.append('/');
                        iv.append(statLabel(en.getKey())).append(' ').append(v);
                    }
                }
            }
            return new Info(name, speciesId, level, shiny, legendary, hiddenAbility(pokemon), perfect,
                    iv.toString(), ivKnown, owned);
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                ShinyControlMod.LOGGER.warn("Could not read a Cobblemon Pokémon (API change?)", t);
            }
            return null;
        }
    }

    private static String statLabel(Object stat) {
        Object id = call(stat, "getShowdownId");
        if (id == null) id = call(stat, "getName");
        String s = id == null ? String.valueOf(stat) : String.valueOf(id);
        return s.toUpperCase();
    }

    private static boolean hasLabel(Object species, String label) {
        Object labels = call(species, "getLabels");
        if (labels instanceof Collection<?> c) {
            for (Object o : c) if (label.equalsIgnoreCase(String.valueOf(o))) return true;
        }
        return false;
    }

    private static boolean hiddenAbility(Object pokemon) {
        try {
            Object template = call(call(pokemon, "getAbility"), "getTemplate");
            Object pool = call(call(pokemon, "getForm"), "getAbilities");
            if (template == null || !(pool instanceof Iterable<?> it)) return false;
            for (Object potential : it) {
                Object tpl = call(potential, "getTemplate");
                Object t = call(potential, "getType");
                if (tpl != null && tpl.equals(template) && t != null
                        && t.getClass().getSimpleName().toLowerCase().contains("hidden")) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    // ------------------------------------------------------------ reflection helper
    private static final Map<String, Optional<Method>> METHODS = new ConcurrentHashMap<>();

    private static Object call(Object target, String method) {
        if (target == null) return null;
        Class<?> cls = target.getClass();
        Optional<Method> m = METHODS.computeIfAbsent(cls.getName() + "#" + method, k -> find(cls, method));
        if (m.isEmpty()) return null;
        try {
            return m.get().invoke(target);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Optional<Method> find(Class<?> cls, String name) {
        for (Method m : cls.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == 0) {
                try {
                    m.setAccessible(true);
                } catch (Throwable ignored) {
                }
                return Optional.of(m);
            }
        }
        return Optional.empty();
    }
}
