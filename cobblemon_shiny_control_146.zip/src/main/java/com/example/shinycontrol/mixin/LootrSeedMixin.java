package com.example.shinycontrol.mixin;

import com.example.shinycontrol.LootrContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;

/**
 * Lootr's getLootSeed(seed) returns the chest seed unchanged, or a random one when randomise_seed is true.
 * When it was randomised and we know the player, replace the random value by one derived from (seed, player).
 * The Lootr config is left untouched.
 */
@Pseudo
@Mixin(targets = "noobanidus.mods.lootr.fabric.impl.LootrAPIImpl", remap = false)
public abstract class LootrSeedMixin {
    @Inject(method = "getLootSeed", at = @At("RETURN"), cancellable = true, remap = false, require = 0)
    private void shinycontrol$seed(long seed, CallbackInfoReturnable<Long> cir) {
        UUID p = LootrContext.get();
        if (p == null) return;
        Long used = cir.getReturnValue();
        if (used == null || used == seed) return; // not randomised: nothing to do
        long derived = LootrContext.derive(seed, p);
        LootrContext.logOnce(seed, derived, p);
        cir.setReturnValue(derived);
    }
}
