package com.example.shinycontrol.mixin;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Applies a Lootr mixin only when Lootr is installed AND the target method has exactly the expected signature
 * (checked in the class file itself), so a Lootr update can never crash the server because of this mod.
 */
public final class LootrMixinPlugin implements IMixinConfigPlugin {
    private static final String P = "Lnoobanidus/mods/lootr/";

    @Override public void onLoad(String mixinPackage) {}
    @Override public String getRefMapperConfig() { return null; }
    @Override public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}
    @Override public List<String> getMixins() { return null; }
    @Override public void preApply(String t, ClassNode c, String m, IMixinInfo i) {}
    @Override public void postApply(String t, ClassNode c, String m, IMixinInfo i) {}

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        try {
            if (mixinClassName.endsWith("LootrFillerMixin")) {
                return has(targetClassName, "unpackLootTable",
                        "(" + P + "common/api/data/ILootrInfoProvider;Lnet/minecraft/class_1657;Lnet/minecraft/class_1263;)V");
            }
            if (mixinClassName.endsWith("LootrSavedDataMixin")) {
                return has(targetClassName, "createInventory",
                        "(" + P + "common/api/data/ILootrInfoProvider;Lnet/minecraft/class_3222;" + P + "common/api/data/LootFiller;)"
                                + P + "common/data/LootrInventory;");
            }
            if (mixinClassName.endsWith("LootrSeedMixin")) {
                return has(targetClassName, "getLootSeed", "(J)J");
            }
        } catch (Throwable t) {
            // fall through
        }
        return false;
    }

    private static boolean has(String className, String method, String desc) throws Exception {
        Optional<ModContainer> mod = FabricLoader.getInstance().getModContainer("lootr");
        if (mod.isEmpty()) return false;
        String rel = className.replace('.', '/') + ".class";
        for (Path root : mod.get().getRootPaths()) {
            Path f = root.resolve(rel);
            if (Files.exists(f)) {
                String s = new String(Files.readAllBytes(f), StandardCharsets.ISO_8859_1);
                return s.contains(method) && s.contains(desc);
            }
        }
        return false;
    }
}
