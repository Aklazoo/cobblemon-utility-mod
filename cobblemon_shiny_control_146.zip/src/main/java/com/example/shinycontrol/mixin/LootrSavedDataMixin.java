package com.example.shinycontrol.mixin;

import com.example.shinycontrol.LootrContext;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Second place that knows the opening player (the inventory is created before the loot is rolled). */
@Pseudo
@Mixin(targets = "noobanidus.mods.lootr.common.data.LootrSavedData", remap = false)
public abstract class LootrSavedDataMixin {
    @Inject(method = "createInventory", at = @At("HEAD"), remap = false, require = 0)
    private void shinycontrol$ctx(@Coerce Object provider, ServerPlayerEntity player, @Coerce Object filler,
                                  CallbackInfoReturnable<Object> cir) {
        if (player != null) LootrContext.set(player.getUuid());
    }
}
