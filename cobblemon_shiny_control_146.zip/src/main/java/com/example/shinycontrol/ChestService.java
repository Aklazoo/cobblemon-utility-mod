package com.example.shinycontrol;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Finds loaded containers that hold an item matching a text (id or display name).
 * Reading a slot of a loot container (Inventory#getStack) makes vanilla generate its loot first, with the
 * chest's own fixed loot seed, so a never-opened structure chest reveals what it would give when opened
 * (the only difference: no player Luck bonus). Only chunks that are loaded on the server can be read.
 */
public final class ChestService {
    private record Hit(BlockPos pos, double dist, String block, String item, int count, double chance, boolean preview,
                       String label) {}

    private ChestService() {}

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    /** One search term: an exact id (contains ':') or a text matched against ids and display names. */
    private record Term(String raw, String q, String exact) {
        static Term of(String raw) {
            String t = raw.trim();
            return new Term(t, norm(t), t.indexOf(':') > 0 ? t.toLowerCase(Locale.ROOT) : null);
        }

        boolean ok() {
            return q.length() >= 2;
        }

        boolean matches(String id, String name) {
            if (exact != null) return id.equals(exact);
            return norm(id).contains(q) || (name != null && norm(name).contains(q));
        }

        boolean matchesId(String id) {
            if (exact != null) return id.equals(exact);
            if (norm(id).contains(q)) return true;
            Identifier ii = Identifier.tryParse(id);
            if (ii == null || !Registries.ITEM.containsId(ii)) return false;
            return norm(Registries.ITEM.get(ii).getName().getString()).contains(q);
        }
    }

    private static String itemName(String id) {
        Identifier ii = Identifier.tryParse(id);
        return ii != null && Registries.ITEM.containsId(ii) ? Registries.ITEM.get(ii).getName().getString() : id;
    }

    /** "2x Money Bag, 1x Master Ball" for every term that has a count; null if none. */
    private static String label(List<Term> terms, int[] counts, String[] names) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < terms.size(); i++) {
            if (counts[i] <= 0) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append(counts[i]).append("x ").append(names[i] != null ? names[i] : terms.get(i).raw());
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    public static JsonObject find(ServerPlayerEntity player, String query) {
        ControlConfig cfg = ControlConfig.get();
        ServerWorld world = (ServerWorld) player.getWorld();
        List<Term> terms = new ArrayList<>();
        if (query != null) {
            for (String part : query.split("[,;|]")) {
                Term t = Term.of(part);
                if (t.ok() && terms.size() < 200) terms.add(t);
            }
        }
        JsonObject out = new JsonObject();
        out.addProperty("t", "chests");
        out.addProperty("q", query);
        out.addProperty("radius", cfg.chestMaxRadius);
        JsonArray arr = new JsonArray();
        out.add("hits", arr);
        if (terms.isEmpty()) {
            out.addProperty("total", 0);
            return out;
        }
        final String displayName = String.join(", ", terms.stream().map(Term::raw).toList());
        final int n = terms.size();

        BlockPos origin = player.getBlockPos();
        int r = cfg.chestMaxRadius;
        double maxSq = (double) r * r;
        int cx0 = (origin.getX() - r) >> 4, cx1 = (origin.getX() + r) >> 4;
        int cz0 = (origin.getZ() - r) >> 4, cz1 = (origin.getZ() + r) >> 4;

        List<Hit> hits = new ArrayList<>();
        int chunksSeen = 0, containersSeen = 0, possibleSeen = 0, previews = 0, exactSeen = 0;
        for (int cx = cx0; cx <= cx1; cx++) {
            for (int cz = cz0; cz <= cz1; cz++) {
                WorldChunk chunk = world.getChunkManager().getWorldChunk(cx, cz); // loaded only
                if (chunk == null) continue;
                chunksSeen++;
                for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                    Inventory inv = be instanceof Inventory i0 ? i0 : null;
                    boolean lootr = Registries.BLOCK_ENTITY_TYPE.getId(be.getType()).getNamespace().equals("lootr");
                    if (inv == null && !(lootr && (cfg.chestExactEnabled || cfg.chestPossibleEnabled))) continue;
                    BlockPos p = be.getPos();
                    double d2 = p.getSquaredDistance(origin);
                    if (d2 > maxSq) continue;
                    containersSeen++;
                    String blockName = be.getCachedState().getBlock().getName().getString();

                    // 1) Lootr chests: exact content for this player (own opened inventory, or Lootr's own roll).
                    if (lootr && cfg.chestExactEnabled && previews < cfg.chestExactMax) {
                        previews++;
                        java.util.Map<String, Integer> items = LootrPreview.items(world, player, be);
                        if (items != null) {
                            exactSeen++;
                            int[] counts = new int[n];
                            String[] names = new String[n];
                            for (var e : items.entrySet()) {
                                for (int i = 0; i < n; i++) {
                                    if (terms.get(i).matchesId(e.getKey())) {
                                        counts[i] += e.getValue();
                                        if (names[i] == null) names[i] = itemName(e.getKey());
                                    }
                                }
                            }
                            String lbl = label(terms, counts, names);
                            if (lbl != null) {
                                int total = 0;
                                for (int c : counts) total += c;
                                hits.add(new Hit(p, Math.sqrt(d2), blockName, lbl, total, 1.0, true, lbl));
                            }
                            continue; // exact answer (yes or no)
                        }
                    }

                    // 2) Anything readable: normal chests, barrels, modded containers, vanilla loot chests.
                    int[] counts = new int[n];
                    String[] names = new String[n];
                    for (int i = 0; inv != null && i < inv.size(); i++) {
                        ItemStack st = inv.getStack(i);
                        if (st.isEmpty()) continue;
                        String id = Registries.ITEM.getId(st.getItem()).toString();
                        String name = st.getName().getString();
                        for (int k = 0; k < n; k++) {
                            if (terms.get(k).matches(id, name)) {
                                counts[k] += st.getCount();
                                if (names[k] == null) names[k] = name;
                            }
                        }
                    }
                    String lbl = label(terms, counts, names);
                    if (lbl != null) {
                        int total = 0;
                        for (int c : counts) total += c;
                        hits.add(new Hit(p, Math.sqrt(d2), blockName, lbl, total, 1.0, false, lbl));
                    } else if (cfg.chestPossibleEnabled) {
                        // 3) Last resort: estimate from the loot table.
                        Identifier tbl = LootChance.findTable(world.getServer(), be);
                        if (tbl != null) {
                            double none = 1;
                            for (Term t : terms) none *= 1 - LootChance.chance(world.getServer(), tbl, t::matchesId);
                            double c = 1 - none;
                            if (c * 100.0 >= cfg.chestMinChancePercent) {
                                hits.add(new Hit(p, Math.sqrt(d2), blockName, displayName, 0, c, false, null));
                            }
                            possibleSeen++;
                        }
                    }
                }
            }
        }
        hits.sort((a, b) -> {
            boolean ra = a.count() > 0, rb = b.count() > 0;
            if (ra != rb) return ra ? -1 : 1;
            if (!ra && Math.abs(a.chance() - b.chance()) > 0.005) return Double.compare(b.chance(), a.chance());
            return Double.compare(a.dist(), b.dist());
        });
        out.addProperty("total", hits.size());
        out.addProperty("chunks", chunksSeen);
        out.addProperty("containers", containersSeen);
        out.addProperty("possibleContainers", possibleSeen);
        out.addProperty("exactPreviews", exactSeen);
        for (int i = 0; i < Math.min(hits.size(), cfg.chestMaxResults); i++) {
            Hit h = hits.get(i);
            JsonObject o = new JsonObject();
            o.addProperty("x", h.pos().getX());
            o.addProperty("y", h.pos().getY());
            o.addProperty("z", h.pos().getZ());
            o.addProperty("dist", (int) h.dist());
            o.addProperty("block", h.block());
            o.addProperty("item", h.item());
            o.addProperty("count", h.count());
            if (h.label() != null) o.addProperty("label", h.label());
            if (h.preview()) o.addProperty("preview", true);
            if (h.count() == 0) o.addProperty("chance", Math.round(h.chance() * 1000.0) / 10.0);
            arr.add(o);
        }
        return out;
    }
}
