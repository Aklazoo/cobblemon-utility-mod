package com.example.shinycontrol;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mojang.datafixers.util.Pair;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.gen.structure.Structure;

import java.util.List;
import java.util.Optional;

/** Lists every registered structure (modded ones included) and locates one for the player, like /locate. */
public final class StructureService {
    private static final String[] TAGS = {
            "minecraft:village", "minecraft:shipwreck", "minecraft:ocean_ruin",
            "minecraft:mineshaft", "minecraft:ruined_portal"};

    private StructureService() {}

    public static JsonObject list(ServerPlayerEntity player) {
        ServerWorld world = (ServerWorld) player.getWorld();
        Registry<Structure> reg = world.getRegistryManager().get(RegistryKeys.STRUCTURE);
        JsonObject out = new JsonObject();
        out.addProperty("t", "structures");
        JsonArray ids = new JsonArray();
        for (Identifier id : reg.getIds()) ids.add(id.toString());
        out.add("ids", ids);
        JsonArray tags = new JsonArray();
        for (String t : TAGS) {
            if (reg.getEntryList(TagKey.of(RegistryKeys.STRUCTURE, Identifier.of(t))).isPresent()) tags.add(t);
        }
        out.add("tags", tags);
        return out;
    }

    public static JsonObject locate(ServerPlayerEntity player, String query) {
        ControlConfig cfg = ControlConfig.get();
        ServerWorld world = (ServerWorld) player.getWorld();
        JsonObject out = new JsonObject();
        out.addProperty("t", "located");
        out.addProperty("q", query);
        out.addProperty("dim", world.getRegistryKey().getValue().toString());

        BlockPos found = null;
        try {
            found = search(world, query, player.getBlockPos(), cfg.structureSearchRadius);
        } catch (Throwable t) {
            ShinyControlMod.LOGGER.warn("Structure search failed for " + query, t);
        }
        if (found == null) {
            out.addProperty("found", false);
        } else {
            out.addProperty("found", true);
            out.addProperty("x", found.getX());
            out.addProperty("z", found.getZ());
        }
        return out;
    }

    private static BlockPos search(ServerWorld sw, String query, BlockPos origin, int radius) {
        Registry<Structure> reg = sw.getRegistryManager().get(RegistryKeys.STRUCTURE);
        RegistryEntryList<Structure> list = null;
        if (query.startsWith("#")) {
            TagKey<Structure> tag = TagKey.of(RegistryKeys.STRUCTURE, Identifier.of(query.substring(1)));
            Optional<RegistryEntryList.Named<Structure>> named = reg.getEntryList(tag);
            if (named.isPresent()) list = named.get();
        } else {
            Optional<RegistryEntry.Reference<Structure>> ref =
                    reg.getEntry(RegistryKey.of(RegistryKeys.STRUCTURE, Identifier.of(query)));
            if (ref.isPresent()) list = RegistryEntryList.of(List.of(ref.get()));
        }
        if (list == null) return null;
        Pair<BlockPos, RegistryEntry<Structure>> pair =
                sw.getChunkManager().getChunkGenerator().locateStructure(sw, list, origin, radius, false);
        return pair == null ? null : pair.getFirst();
    }
}
