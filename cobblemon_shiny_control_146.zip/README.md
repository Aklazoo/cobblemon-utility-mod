# Cobblemon Shiny Control (Fabric 1.21.1) - server-side

Put the jar in the server's mods/ folder (Exaroton: Files -> mods). No client install needed.
Needs Fabric API and Cobblemon on the server. Commands require op level 2 (console always works).

/shinyrate                       status
/shinyrate multiplier <x>        permanent multiplier (saved in config/cobblemon_shiny_control.json)
/shinyrate set <N>               shiny odds 1/N
/shinyrate boost <x> <seconds>   temporary boost, announced to all players
/shinyrate boost stop
/shinyrate reset

It changes Cobblemon's in-memory shinyRate only; Cobblemon's own config file is not modified.

## Finder (only through the Cobblemon Utility client mod, no chat command, no op needed)
The client mod (1.6.0+) sends a request packet; this mod answers. Typing anything in chat does nothing.
Pokémon finder: shiny / legendary / hidden ability / N perfect IVs / species, nearest first.
Structure finder: lists every registered structure (modded included) and returns coordinates.

Config (config/cobblemon_shiny_control.json, restart after editing):
findEnabled, structuresEnabled, allowedPlayers (empty = everyone with the client mod),
findCooldownSeconds, findMaxRadius, findMaxResults, findDefaultMinPerfectIvs,
findCoords ("exact" | "approx" | "direction"), findIvDisplay ("full" | "count" | "none"), findIncludeOwned,
structureCooldownSeconds, structureSearchRadius,
chestsEnabled, chestCooldownSeconds, chestMaxRadius, chestMaxResults (container finder; loaded chunks only, never-opened
loot chests are revealed because their loot is generated from the chest's own seed when read). Operators ignore cooldowns.
It only sees Pokémon in chunks the server has loaded.

Lootr probe: if the Lootr mod is installed, cobblemon_shiny_control_lootr_dump.txt (server root folder) is written once (diagnostic only).


## Lootr / per-player chests (1.5.0)
Lootr rolls a fresh inventory for each player at the moment a chest is opened, so the real content cannot be read
beforehand. The container finder now also lists such chests as "possible": the mod finds the chest's loot table by itself,
walks it and estimates the chance (percent) that one opening gives the searched item. Config keys: chestPossibleEnabled,
chestMinChancePercent. Conditions such as luck are ignored, so the figure is an estimate. The first Lootr container data
is written to latest.log ("First Lootr container data seen") and the Lootr API to
cobblemon_shiny_control_lootr_dump.txt (server root folder), to help adjust the detection if needed.


## Exact Lootr preview (1.6.0)
A small mixin (applied only if Lootr's method signatures match, checked in the class file) replaces the *random* seed Lootr
draws when randomise_seed=true by one derived from (chest seed, player). Lootr's config is not touched and each player still
gets different loot, but the loot becomes predictable, so the container finder can show the exact content of a never-opened
Lootr chest for the asking player ("Nx item (exact)"). Config keys: chestExactEnabled, chestExactMax. Chests opened before
this version keep the content that was already rolled for them (the client memory shows those). If the hook cannot be used,
the finder falls back to the probability estimate.


## 1.6.1: stricter Lootr preview, several items
The preview now runs Lootr's own filler (DefaultLootFiller.unpackLootTable) on a scratch inventory, and reads the stored
inventory when the player already opened the chest. Every real opening is compared with the preview and the verdict is logged
("Lootr preview check #N: MATCH" or "MISMATCH ..."). The container finder accepts several items separated by commas.

## 1.6.2
chestMaxRadius now defaults to 256 (an old default of 128 is raised once). Only chunks loaded by the server can be searched.


## 1.7.0: per-player shiny boost (no chat command)
The Cobblemon Utility client (key F7 or Settings > Shiny Boost) asks the server to boost shiny odds around that player only.
When a wild Pokémon appears and its nearest player (within boostRadius blocks) has the boost on, it gets an extra shiny roll so the
total chance is multiplier x Cobblemon's chance (capped at 100%). Other players are not affected. Config: boostEnabled,
boostMaxMultiplier (1000), boostRadius (128), boostAllowedPlayers (empty = operators only). The boost is dropped when the player
leaves or the server restarts. Each handled Pokémon gets the tag scb_seen so a chunk reload never rolls it twice.

## 1.7.1
The shiny boost no longer needs operator rights. boostAllowedPlayers (names) restricts it to those players; boostRequireOp=true restricts it to operators; empty list and false = every player with the client mod.

## 1.8.0
The boost is now expressed as a target chance: the client asks for a percent (default 60) and each wild Pokémon appearing around the player is shiny with that total chance. boostMaxChancePercent (100) caps it. Older clients that send a multiplier still work.

## 1.9.0
The boost request can carry a Pokémon filter (types, categories legendary / mythical / ultra beast / paradox / regular, species). A wild Pokémon is boosted only if it matches at least one choice; without a filter every wild Pokémon is boosted. Labels and types are read from Cobblemon by reflection.

## 1.9.1
Container finder: up to 200 search terms and a 30000 character request limit (needed for the client's "All legendary-summon items" shortcut). Exact item ids are matched faster.

## 1.9.2
The "possible" estimates are off by default (chestPossibleEnabled=false, applied once to old configs): the container finder shows exact results only. Exact Lootr previews are unaffected.

## 1.10.0 – Quality boost and extra spawns
Per-player boosts that stack (each effect rolls separately): perfect IVs, hidden ability, size (big/small/gigantic), Alpha;
plus extra Ultra Beast / legendary / mythical / paradox spawns near the boosted player. Config keys: `boostQualityEnabled`,
`boostAlphaProperty`, `boostSpawn*`. Mod API dumps for the Alpha and size mods are written to the server root.
