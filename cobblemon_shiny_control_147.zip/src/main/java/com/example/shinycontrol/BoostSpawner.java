package com.example.shinycontrol;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * Extra spawns of Ultra Beasts / legendaries / mythicals / paradox Pokémon around a boosted player.
 * Every second, for each boosted player who asked for it, there is a 1/(minutes*60) chance to spawn one at a
 * valid spot 24-48 blocks away, using Cobblemon's own /spawnpokemonat command run silently by the server.
 * The spawned Pokémon are tracked, limited per player, and removed when nobody is near them any more.
 */
final class BoostSpawner {
    static final String TAG = "scb_boostspawn";

    private record Tracked(UUID player, long expiresAt) {}

    private static final Map<UUID, Tracked> TRACKED = new HashMap<>();
    /** Set while our own command runs, so the entity it creates can be recognised when it joins the world. */
    private static UUID expecting;
    private static boolean captureDone;
    private static long tick;
    private static int failures;
    private static Map<String, List<String>> speciesByCat;
    private static final Random RNG = new Random();

    private BoostSpawner() {}

    // ------------------------------------------------------------------ called when a Pokémon entity joins a world
    static boolean captured(Entity entity) {
        if (expecting == null || captureDone) return false;
        captureDone = true;
        entity.addCommandTag(TAG);
        ControlConfig cfg = ControlConfig.get();
        TRACKED.put(entity.getUuid(), new Tracked(expecting, System.currentTimeMillis() + cfg.boostSpawnDespawnMinutes * 60_000L));
        return true;
    }

    // ------------------------------------------------------------------ once per tick
    static void tick(MinecraftServer server) {
        if (++tick % 20 != 0) return; // once per second
        ControlConfig cfg = ControlConfig.get();
        if (!cfg.boostSpawnEnabled || failures >= 3) return;
        cleanup(server);
        for (ServerPlayerEntity player : new ArrayList<>(server.getPlayerManager().getPlayerList())) {
            PlayerBoost.Boost boost = PlayerBoost.boostOf(player.getUuid());
            if (boost == null || boost.spawns() == null || boost.spawns().cats().isEmpty()) continue;
            if (player.isSpectator()) continue;
            if (activeCount(player.getUuid()) >= cfg.boostSpawnMaxActive) continue;
            double p = 1.0 / (Math.max(1, boost.spawns().minutes()) * 60.0);
            if (RNG.nextDouble() >= p) continue;
            try {
                spawnOne(server, player, boost.spawns());
            } catch (Throwable t) {
                failures++;
                PlayerBoost.warnOnce("spawn" + failures, "Extra spawn failed: " + t);
            }
        }
    }

    private static int activeCount(UUID player) {
        int n = 0;
        for (Tracked t : TRACKED.values()) if (t.player().equals(player)) n++;
        return n;
    }

    private static void cleanup(MinecraftServer server) {
        if (TRACKED.isEmpty()) return;
        long now = System.currentTimeMillis();
        List<UUID> remove = new ArrayList<>();
        for (Map.Entry<UUID, Tracked> e : TRACKED.entrySet()) {
            Entity found = null;
            for (ServerWorld w : server.getWorlds()) {
                found = w.getEntity(e.getKey());
                if (found != null) break;
            }
            if (found == null || found.isRemoved()) { remove.add(e.getKey()); continue; } // gone or caught
            if (found instanceof net.minecraft.entity.passive.TameableEntity t && t.getOwnerUuid() != null) { // someone caught it
                remove.add(e.getKey());
                found.removeCommandTag(TAG);
                continue;
            }
            if (now >= e.getValue().expiresAt()) {
                PlayerEntity near = found.getWorld().getClosestPlayer(found.getX(), found.getY(), found.getZ(), 48, false);
                if (near != null) { // somebody is still around it: give it more time
                    TRACKED.put(e.getKey(), new Tracked(e.getValue().player(), now + 120_000L));
                } else {
                    found.discard();
                    remove.add(e.getKey());
                }
            }
        }
        for (UUID id : remove) TRACKED.remove(id);
    }

    // ------------------------------------------------------------------ spawning
    private static void spawnOne(MinecraftServer server, ServerPlayerEntity player, PlayerBoost.Spawns spawns) throws Exception {
        List<String> pool = pool(spawns.cats());
        if (pool.isEmpty()) {
            PlayerBoost.warnOnce("emptypool", "Extra spawns: no species found for " + spawns.cats());
            return;
        }
        ServerWorld world = (ServerWorld) player.getWorld();
        BlockPos spot = findSpot(world, player);
        if (spot == null) return; // try again next second
        String species = pool.get(RNG.nextInt(pool.size()));
        int level = spawns.levelMin() + RNG.nextInt(Math.max(1, spawns.levelMax() - spawns.levelMin() + 1));
        String cmd = "spawnpokemonat " + spot.getX() + " " + spot.getY() + " " + spot.getZ() + " " + species + " level=" + level;

        expecting = player.getUuid();
        captureDone = false;
        try {
            // Cobblemon's command needs a real player as its source (the console crashes it), so run it as the player, silently, with full rights
            var source = player.getCommandSource().withLevel(4).withSilent();
            server.getCommandManager().executeWithPrefix(source, cmd);
        } finally {
            expecting = null;
        }
        if (!captureDone) {
            failures++;
            PlayerBoost.warnOnce("nocapture" + failures, "Extra spawn: the command '" + cmd + "' did not create a Pokémon.");
            return;
        }
        failures = 0;
        if (ControlConfig.get().boostSpawnNotify) {
            Vec3d d = new Vec3d(spot.getX() - player.getX(), 0, spot.getZ() - player.getZ());
            player.sendMessage(Text.literal("§6[Boost] §fA §e" + pretty(species) + " §fappeared about §e" + (int) d.length()
                    + " blocks §fto the §e" + compass(d) + "§f."), false);
        }
        ShinyControlMod.LOGGER.info("Extra spawn: {} (level {}) near {}", species, level, player.getName().getString());
    }

    private static String pretty(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private static String compass(Vec3d d) {
        double deg = Math.toDegrees(Math.atan2(d.x, -d.z)); // 0 = north (-z), 90 = east (+x)
        String[] names = {"north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"};
        int i = (int) Math.round(((deg % 360) + 360) % 360 / 45.0) % 8;
        return names[i];
    }

    private static BlockPos findSpot(ServerWorld world, ServerPlayerEntity player) {
        for (int attempt = 0; attempt < 10; attempt++) {
            double angle = RNG.nextDouble() * Math.PI * 2;
            double dist = 24 + RNG.nextDouble() * 24;
            int x = (int) Math.floor(player.getX() + Math.cos(angle) * dist);
            int z = (int) Math.floor(player.getZ() + Math.sin(angle) * dist);
            if (!world.getChunkManager().isChunkLoaded(x >> 4, z >> 4)) continue;
            int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
            BlockPos pos = new BlockPos(x, y, z);
            if (!world.getFluidState(pos).isEmpty() || !world.getFluidState(pos.down()).isEmpty()) continue;
            if (!world.getBlockState(pos.down()).isSolidBlock(world, pos.down())) continue;
            if (!world.getBlockState(pos).isAir() && !world.getBlockState(pos).isReplaceable()) continue;
            if (world.getBlockState(pos.down()).getFluidState().isIn(FluidTags.WATER)) continue;
            return pos;
        }
        return null;
    }

    // ------------------------------------------------------------------ which species can be spawned
    private static List<String> pool(Set<String> cats) {
        if (speciesByCat == null) speciesByCat = loadSpecies();
        List<String> out = new ArrayList<>();
        for (String c : cats) {
            List<String> l = speciesByCat.get(c);
            if (l != null) for (String s : l) if (!out.contains(s)) out.add(s);
        }
        return out;
    }

    private static Map<String, List<String>> loadSpecies() {
        Map<String, List<String>> out = new HashMap<>();
        for (String c : new String[]{"legendary", "mythical", "ultrabeast", "paradox"}) out.put(c, new ArrayList<>());
        try {
            Class<?> cls = Class.forName("com.cobblemon.mod.common.api.pokemon.PokemonSpecies");
            Object instance = cls.getField("INSTANCE").get(null);
            Object all = PlayerBoost.call(instance, "getSpecies");
            if (all instanceof Collection<?> species) {
                for (Object sp : species) {
                    Object nameObj = PlayerBoost.call(sp, "getName");
                    if (nameObj == null) continue;
                    String name = String.valueOf(nameObj).toLowerCase(Locale.ROOT);
                    Object labels = PlayerBoost.call(sp, "getLabels");
                    if (!(labels instanceof Collection<?> ls)) continue;
                    for (Object l : ls) {
                        String key = PlayerBoost.norm(String.valueOf(l));
                        List<String> list = out.get(key);
                        if (list != null) list.add(name);
                    }
                }
            }
        } catch (Throwable t) {
            ShinyControlMod.LOGGER.warn("Extra spawns: could not read the Pokémon list ({})", t.toString());
        }
        ShinyControlMod.LOGGER.info("Extra spawns: legendary={} mythical={} ultrabeast={} paradox={}",
                out.get("legendary").size(), out.get("mythical").size(), out.get("ultrabeast").size(), out.get("paradox").size());
        return out;
    }
}
