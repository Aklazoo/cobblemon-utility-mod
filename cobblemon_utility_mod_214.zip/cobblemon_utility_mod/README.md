# Cobblemon Utility Mod 1.7.0 (Fabric 1.21.1) - itemless, client-side

Tested target: Minecraft 1.21.1 + Fabric, e.g. the "Cobblemon Academy (Legacy)" modpack.

## Features (all configurable in-game, JSON at config/cobblemon_utility_mod.json)
- Keybinds: click an action in the settings, press the key you want (conflicts are shown).
  Defaults: O settings, K structure finder, C chest ESP, R radar, mark-container unbound.
- Cobblemon radar overlay: shiny / legendary-mythical / hidden ability / perfect IVs,
  tracers, 3D boxes, HUD waypoints, colors, optional see-through-walls.
- Spawn alerts (chat): shiny, legendary/mythical, ultra beast/paradox, hidden ability, N x 31 IV,
  and a species watchlist ("rare" Pokémon you choose). Coordinates + direction + distance, sound.
- Chest ESP: chests, trapped chests, barrels, shulkers AND modded containers (any loot container of
  any mod + extra block ids you list). See-through-walls, tracers, per-type colors, opacity,
  hide opened, hide nearby, auto/manual "opened" marking.
- Pokémon menu (key H): give / spawn any Pokémon (level, shiny, legendaries list, extra properties) and custom command buttons.
  Sends /givepokemon and /spawnpokemon as you: needs operator rights or cheats.
- Shiny Boost: local multiplier on Cobblemon's shiny odds (singleplayer / LAN host only, restored on exit).
- Leftover-loot memory: a container you closed with items still inside is drawn in its own color
  (orange by default), emptied ones in gray, untouched ones in green.
- Points of interest: highlight any block-entity block you list (e.g. cobblemon:*).
- Saved waypoints: every located structure is saved per world/server; track / delete from a list.
- Structure finder: search box + list of EVERY registered structure (modpack structures included,
  singleplayer). On a remote server type any id and press "Locate typed id".

## Required mods in mods/
Fabric Loader >= 0.16, Fabric API, YetAnotherConfigLib 3.6.x (Fabric, 1.21), Cobblemon 1.6.x.
(The Cobblemon Academy modpack already contains Fabric API and Cobblemon; add YACL if missing.)

## Build
GitHub Actions workflow in .github/workflows (or locally: JDK 21 + Gradle 8.10 -> `gradle build`).
Jar: build/libs/cobblemon_utility_mod-1.7.0.jar

## Limits (Minecraft / Cobblemon, not the mod)
- IVs / hidden ability of wild Pokémon are only known in singleplayer (integrated server).
  Cobblemon spawn rarity buckets are not known to the client -> use the watchlist.
- The client cannot see loot tables: "opened" = containers you opened or marked yourself.
- Structure registry is not sent to remote clients; /locate on a server needs permission.
- Entities / chunks only exist client-side within the server's view / tracking distance.
- ESP/radar are unfair advantages on most multiplayer servers: use only where allowed.


## 1.7.0 - server finder + ball aim
- J: Pokémon finder (shiny / legendary / HA / 5-6 IV / species) across the Pokémon loaded on the server. Needs the
  server mod "Cobblemon Shiny Control" 1.2.0+. No chat command exists, no admin needed.
- K: structure finder now lists EVERY structure of the server (modded included) when the server mod is present.
- G: Poké Ball aim (disabled by default). Settings > Ball Aim. Physics limit the reachable range (~60 blocks).

## 1.7.0
- N: Container Filter. Type an item (e.g. golden fossil); containers holding it are listed and highlighted. Needs server mod 1.3.0+.

## 1.7.1
- Container Filter: item picker with icons for every registered item (all mods); chest overlay can show only matches.

## 1.7.2
- Container Filter reveals unopened loot chests (server generates loot from the chest seed).

## 1.8.0
- Container Filter scans automatically while you walk; new matching chests are announced and highlighted. HUD shows the active filter. "Stop / clear" ends it.

## 1.9.0
- B: Type Advisor. Battle advisor HUD, ball advice HUD, automatic Pokémon alerts (server mod needed for alerts).

## 1.9.1
- F8: Stream mode. Hides all overlays, HUD, messages and sounds of the mod (starts OFF every launch).

## 1.10.0
- New HUD look (glass panels, pills, toasts, floating labels, off-screen arrows).

## 1.10.2
- Automatic Pokémon alerts can be filtered (shiny, legendary, hidden ability, perfect IVs). Hidden ability alone is off by default.

## 1.11.0
- Container Filter remembers the contents of every container you open (works with Lootr / modded chests) and searches that memory too.

## 1.11.1
- Container Filter: "Stop / clear" also removes the tracked waypoint.
