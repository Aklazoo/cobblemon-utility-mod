package com.example.cobbleutility.radar;

import com.example.cobbleutility.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** Sends ONE chat message per Pokémon the first time it matches one of the enabled triggers. */
public final class SpawnAlerts {
    private static final Set<UUID> alerted = new HashSet<>();
    private static String cachedRaw = null;
    private static Set<String> cachedWatch = Set.of();

    private SpawnAlerts() {}

    public static void reset() {
        alerted.clear();
    }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private static Set<String> watchlist(ModConfig cfg) {
        String raw = cfg.alertWatchlist == null ? "" : cfg.alertWatchlist;
        if (!raw.equals(cachedRaw)) {
            Set<String> set = new HashSet<>();
            for (String part : raw.split("[,;\\n]")) {
                String n = norm(part);
                if (!n.isEmpty()) set.add(n);
            }
            cachedWatch = set;
            cachedRaw = raw;
        }
        return cachedWatch;
    }

    /** True if the species is in the watchlist (shared with the radar overlay). */
    public static boolean isWatched(ModConfig cfg, CobblemonBridge.Info info) {
        Set<String> wl = watchlist(cfg);
        return !wl.isEmpty() && (wl.contains(norm(info.speciesId())) || wl.contains(norm(info.name())));
    }

    public static void check(MinecraftClient mc, ModConfig cfg, Entity e, CobblemonBridge.Info info, double dist) {
        if (!cfg.alertsEnabled || mc.player == null) return;
        if (dist > cfg.alertMaxDistance) return;
        if (cfg.alertIgnoreOwned && info.owned()) return;
        if (alerted.contains(e.getUuid())) return;

        List<String> reasons = new ArrayList<>();
        int color = 0xFFFFFF;
        boolean colorSet = false;

        if (cfg.alertShiny && info.shiny()) {
            reasons.add("Shiny");
            color = cfg.radarShinyColor; colorSet = true;
        }
        if (cfg.alertLegendary && info.legendary()) {
            reasons.add("Legendary/Mythical");
            if (!colorSet) { color = cfg.radarLegendaryColor; colorSet = true; }
        }
        if (cfg.alertUltraBeast && info.ultraBeast()) {
            reasons.add("Ultra Beast/Paradox");
            if (!colorSet) { color = cfg.radarLegendaryColor; colorSet = true; }
        }
        if (cfg.alertHiddenAbility && info.hiddenAbility()) {
            reasons.add("Hidden Ability");
            if (!colorSet) { color = cfg.radarHiddenAbilityColor; colorSet = true; }
        }
        if (cfg.alertPerfectIvs && info.ivKnown() && info.perfectIvs() >= cfg.alertMinPerfectIvs) {
            reasons.add(info.perfectIvs() + "x31 IV");
            if (!colorSet) { color = cfg.radarHighIvColor; colorSet = true; }
        }
        if (cfg.alertWatchlistEnabled) {
            Set<String> wl = watchlist(cfg);
            if (!wl.isEmpty() && (wl.contains(norm(info.speciesId())) || wl.contains(norm(info.name())))) {
                reasons.add("Watchlist");
                if (!colorSet) { color = cfg.alertWatchlistColor; colorSet = true; }
            }
        }
        if (reasons.isEmpty()) return;

        if (alerted.size() > 2048) alerted.clear();
        alerted.add(e.getUuid());
        notify(mc, cfg, e, info, reasons, color, dist);
    }

    private static void notify(MinecraftClient mc, ModConfig cfg, Entity e, CobblemonBridge.Info info,
                               List<String> reasons, int color, double dist) {
        final int c = color;
        MutableText msg = Text.literal("[Cobblemon Alert] ").formatted(Formatting.GOLD)
                .append(Text.literal(info.name()).styled(s -> s.withColor(c).withBold(true)));
        if (info.level() > 0) msg.append(Text.literal(" Lv." + info.level()).formatted(Formatting.GRAY));
        msg.append(Text.literal(" (" + String.join(", ", reasons) + ")").formatted(Formatting.YELLOW));
        msg.append(Text.literal(" - " + (int) dist + " blocks " + direction(e, mc)).formatted(Formatting.GRAY));
        if (cfg.alertShowCoords) {
            msg.append(Text.literal(String.format(" @ %d %d %d", (int) e.getX(), (int) e.getY(), (int) e.getZ()))
                    .formatted(Formatting.WHITE));
        }
        if (cfg.alertInChat) com.example.cobbleutility.util.StreamMode.say(mc.player, msg, false);
        if (cfg.alertActionBar) com.example.cobbleutility.util.StreamMode.say(mc.player, msg, true);
        if (cfg.alertSound && !com.example.cobbleutility.util.StreamMode.active()) mc.player.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 0.8f, 1.2f);
    }

    private static String direction(Entity e, MinecraftClient mc) {
        double dx = e.getX() - mc.player.getX();
        double dz = e.getZ() - mc.player.getZ();
        double ang = Math.toDegrees(Math.atan2(dz, dx)); // 0 = east, 90 = south
        String[] names = {"E", "SE", "S", "SW", "W", "NW", "N", "NE"};
        int idx = ((int) Math.round(ang / 45.0) + 8) % 8;
        return names[idx];
    }
}
