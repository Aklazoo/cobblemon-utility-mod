package com.example.cobbleutility.render;

import com.example.cobbleutility.util.StreamMode;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Short notifications stacked at the top center of the screen (instead of flooding the chat). */
public final class Toasts {
    private record Toast(String title, String body, int rgb, long start) {}

    private static final long LIFE = 6000, FADE_IN = 250, FADE_OUT = 600;
    private static final List<Toast> LIST = new ArrayList<>();

    private Toasts() {}

    public static void push(String title, String body, int rgb) {
        if (StreamMode.active()) return;
        synchronized (LIST) {
            LIST.add(new Toast(title, body, rgb, System.currentTimeMillis()));
            while (LIST.size() > 4) LIST.remove(0);
        }
    }

    public static void render(DrawContext ctx) {
        long now = System.currentTimeMillis();
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        List<Toast> copy;
        synchronized (LIST) {
            LIST.removeIf(t -> now - t.start() > LIFE);
            copy = new ArrayList<>(LIST);
        }
        int sw = ctx.getScaledWindowWidth();
        int y = 6;
        for (Toast t : copy) {
            long age = now - t.start();
            float a = age < FADE_IN ? age / (float) FADE_IN : (age > LIFE - FADE_OUT ? (LIFE - age) / (float) FADE_OUT : 1f);
            a = Math.max(0.05f, Math.min(1f, a));
            int w = Math.max(tr.getWidth(t.title()), tr.getWidth(t.body())) + 16;
            int x = (sw - w) / 2;
            int slide = Math.round((1f - a) * -8);
            Hud.panel(ctx, x, y + slide, w, 26, t.rgb(), a);
            ctx.drawText(tr, Text.literal(t.title()), x + 8, y + slide + 4, Hud.alpha(0xFF000000 | t.rgb(), a), true);
            ctx.drawText(tr, Text.literal(t.body()), x + 8, y + slide + 14, Hud.alpha(0xFFFFFFFF, a), true);
            y += 30;
        }
    }
}
