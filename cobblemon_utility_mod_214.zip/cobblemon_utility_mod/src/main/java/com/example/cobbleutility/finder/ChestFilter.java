package com.example.cobbleutility.finder;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.net.ServerLink;
import com.example.cobbleutility.render.RenderUtil;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import java.util.HashSet;
import java.util.Set;
import com.example.cobbleutility.util.ColorUtil;
import com.google.gson.JsonObject;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Keeps the containers returned by the last search and draws them in the world. */
public final class ChestFilter {
    private record Detail(BlockPos pos, String item, int count, double chance, boolean preview, String label0) {
        String label() {
            if (count > 0) return (label0 != null ? label0 : count + "x " + item) + (preview ? " (exact)" : "");
            String c = chance >= 10 ? String.valueOf(Math.round(chance)) : String.valueOf(Math.round(chance * 10) / 10.0);
            return "~" + c + "% " + item + " (possible)";
        }
    }
    private static List<BlockPos> hits = new ArrayList<>();
    private static List<Detail> details = new ArrayList<>();
    private static String activeQuery;
    private static final Set<Long> announced = new HashSet<>();
    private static int sinceScan;
    private static Vec3d lastScanPos;
    private static boolean registered;

    private ChestFilter() {}

    /** Called when the player starts a search: from now on the mod keeps scanning on its own. */
    public static void setActive(String query) {
        if (!query.equals(activeQuery)) announced.clear();
        activeQuery = query;
        sinceScan = 0;
        lastScanPos = null;
        if (!registered) {
            registered = true;
            ClientTickEvents.END_CLIENT_TICK.register(ChestFilter::tick);
        }
    }

    public static String activeQuery() {
        return activeQuery;
    }

    private static void tick(MinecraftClient mc) {
        ModConfig cfg = ConfigManager.get();
        if (activeQuery == null || !cfg.chestFilterAuto || mc.player == null || mc.world == null) return;
        if (mc.currentScreen != null || ServerLink.waitingChests()) return;
        sinceScan++;
        int interval = Math.max(3, cfg.chestFilterIntervalSeconds) * 20;
        if (sinceScan < interval) return;
        Vec3d pos = mc.player.getPos();
        boolean moved = lastScanPos == null || pos.squaredDistanceTo(lastScanPos) > 36; // 6 blocks
        if (!moved && sinceScan < interval * 6) return; // standing still: re-check rarely (chunks may load)
        if (ServerLink.scanChests(activeQuery, true)) {
            sinceScan = 0;
            lastScanPos = pos;
        }
    }

    public static String statusText() {
        if (activeQuery == null) return null;
        return "Filter: " + activeQuery + " (" + hits.size() + ")";
    }

    public static void onResult(JsonObject o) {
        List<BlockPos> list = new ArrayList<>();
        List<Detail> det = new ArrayList<>();
        if (o.has("hits")) {
            o.getAsJsonArray("hits").forEach(e -> {
                JsonObject h = e.getAsJsonObject();
                BlockPos bp = new BlockPos(h.get("x").getAsInt(), h.get("y").getAsInt(), h.get("z").getAsInt());
                list.add(bp);
                double chance = h.has("chance") ? h.get("chance").getAsDouble() : 100.0;
                det.add(new Detail(bp, h.get("item").getAsString(), h.get("count").getAsInt(), chance, h.has("preview"),
                        h.has("label") ? h.get("label").getAsString() : null));
                String lbl = det.get(det.size() - 1).label();
                if (announced.add(bp.asLong())) {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    if (mc.player != null) {
                        if (ConfigManager.get().hudToasts) {
                            com.example.cobbleutility.render.Toasts.push("Container found",
                                    lbl + " - " + h.get("dist").getAsInt()
                                            + "m  (" + bp.getX() + ", " + bp.getY() + ", " + bp.getZ() + ")",
                                    ConfigManager.get().chestFilterColor & 0xFFFFFF);
                        } else {
                            com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal("§6Found: §f" + lbl + " §7at §f" + bp.getX() + ", " + bp.getY() + ", " + bp.getZ()), true);
                        }
                        if (!com.example.cobbleutility.util.StreamMode.active()) mc.player.playSound(net.minecraft.sound.SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 0.7f, 1.2f);
                    }
                }
            });
        }
        hits = list;
        details = det;
    }

    public static boolean active() {
        return !hits.isEmpty();
    }

    /** True if one of the last search results lies inside this box (a double chest spans two blocks). */
    public static boolean matches(Box box) {
        Box b = box.expand(0.01);
        for (BlockPos p : hits) {
            if (b.contains(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5)) return true;
        }
        return false;
    }

    public static void clear() {
        activeQuery = null;
        announced.clear();
        hits = new ArrayList<>();
        details = new ArrayList<>();
    }

    public static void renderLabels(net.minecraft.client.gui.DrawContext ctx, float td) {
        ModConfig cfg = ConfigManager.get();
        List<Detail> list = details;
        if (!cfg.hudFloatingLabels || list.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        net.minecraft.client.render.Camera cam = mc.gameRenderer.getCamera();
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double fov = mc.options.getFov().getValue();
        int shown = 0;
        for (Detail d : list) {
            if (shown >= 10) break;
            Vec3d p = new Vec3d(d.pos().getX() + 0.5, d.pos().getY() + 1.4, d.pos().getZ() + 0.5);
            float[] s = RenderUtil.project(p, cam, sw, sh, fov, 40, 20);
            if (s[2] < 0.5f) continue; // only labels in view
            int dist = (int) Math.sqrt(mc.player.squaredDistanceTo(p));
            com.example.cobbleutility.render.Hud.tag(ctx, mc.textRenderer, d.label() + "  " + dist + "m",
                    (int) s[0], (int) s[1], cfg.chestFilterColor & 0xFFFFFF, 1f);
            shown++;
        }
    }

    public static void renderWorld(MatrixStack ms, Vec3d cam) {
        List<BlockPos> list = hits;
        if (list.isEmpty()) return;
        ModConfig cfg = ConfigManager.get();
        int argb = ColorUtil.opaque(cfg.chestFilterColor);
        MatrixStack.Entry entry = ms.peek();
        BufferBuilder b = RenderUtil.beginLines(3.0f, cfg.chestFilterThroughWalls);
        for (BlockPos p : list) {
            RenderUtil.boxOutline(b, entry, new Box(p).expand(0.02), cam.x, cam.y, cam.z, argb);
            RenderUtil.line(b, entry, p.getX() + 0.5 - cam.x, p.getY() - cam.y, p.getZ() + 0.5 - cam.z,
                    p.getX() + 0.5 - cam.x, p.getY() + 40 - cam.y, p.getZ() + 0.5 - cam.z, argb);
        }
        RenderUtil.end(b);
    }
}
