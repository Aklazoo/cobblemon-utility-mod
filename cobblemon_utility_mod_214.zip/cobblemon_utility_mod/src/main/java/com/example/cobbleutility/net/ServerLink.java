package com.example.cobbleutility.net;

import com.example.cobbleutility.CobblemonUtilityMod;
import com.example.cobbleutility.structure.StructureFinder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/**
 * Talks to the server-side "Cobblemon Shiny Control" mod (v1.2.0+) through custom packets.
 * No chat command is involved, and no operator rights are needed.
 */
public final class ServerLink {
    private static List<String> structureIds = new ArrayList<>();
    private static List<String> structureTags = new ArrayList<>();
    private static int structuresVersion = 0;
    private static boolean structuresRequested;

    private static JsonObject lastFind;
    private static String lastFindFilter = "";
    private static int findVersion = 0;
    private static String lastError;
    private static boolean waitingFind;
    private static JsonObject lastChests;
    private static int chestsVersion = 0;
    private static boolean waitingChests;
    private static boolean silentChests;
    private static boolean silentFind;

    private ServerLink() {}

    public static void init() {
        try {
            PayloadTypeRegistry.playC2S().register(RequestPayload.ID, RequestPayload.CODEC);
        } catch (Throwable ignored) {
            // already registered by the server mod in the same JVM (singleplayer)
        }
        try {
            PayloadTypeRegistry.playS2C().register(ReplyPayload.ID, ReplyPayload.CODEC);
        } catch (Throwable ignored) {
        }
        ClientPlayNetworking.registerGlobalReceiver(ReplyPayload.ID, (payload, context) -> {
            try {
                onReply(JsonParser.parseString(payload.json()).getAsJsonObject());
            } catch (Throwable t) {
                CobblemonUtilityMod.LOGGER.warn("Bad reply from server", t);
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> reset());
    }

    private static void reset() {
        structureIds = new ArrayList<>();
        structureTags = new ArrayList<>();
        structuresRequested = false;
        structuresVersion++;
        lastFind = null;
        lastChests = null;
        waitingChests = false;
        com.example.cobbleutility.finder.FinderAlerts.reset();
        com.example.cobbleutility.finder.ChestFilter.clear();
        lastError = null;
        waitingFind = false;
    }

    /** True when the server we are connected to has the server-side mod. */
    public static boolean available() {
        try {
            return MinecraftClient.getInstance().getNetworkHandler() != null
                    && ClientPlayNetworking.canSend(RequestPayload.ID);
        } catch (Throwable t) {
            return false;
        }
    }

    private static void send(String json) {
        ClientPlayNetworking.send(new RequestPayload(json));
    }

    // ------------------------------------------------------------ requests
    public static boolean requestBoost(boolean on, int chancePercent, JsonObject filter) {
        if (!available()) return false;
        JsonObject o = new JsonObject();
        o.addProperty("t", "boost");
        o.addProperty("on", on);
        o.addProperty("chance", chancePercent);
        if (filter != null) o.add("filter", filter);
        send(o.toString());
        return true;
    }

    public static boolean requestFind(String filter) {
        return requestFind(filter, false);
    }

    public static boolean requestFind(String filter, boolean silent) {
        if (!available()) return false;
        silentFind = silent;
        JsonObject o = new JsonObject();
        o.addProperty("t", "find");
        o.addProperty("filter", filter);
        lastFindFilter = filter;
        if (!silent) lastError = null;
        waitingFind = true;
        send(o.toString());
        return true;
    }

    public static void requestStructuresOnce() {
        if (structuresRequested || !available()) return;
        structuresRequested = true;
        JsonObject o = new JsonObject();
        o.addProperty("t", "structures");
        send(o.toString());
    }

    public static boolean requestLocate(String query) {
        if (!available()) return false;
        JsonObject o = new JsonObject();
        o.addProperty("t", "locate");
        o.addProperty("q", query);
        send(o.toString());
        return true;
    }

    public static boolean requestChests(String query) {
        return requestChests(query, false);
    }

    /** silent = automatic re-scan: errors (e.g. cooldown) are ignored instead of shown. */
    public static boolean requestChests(String query, boolean silent) {
        if (!available()) return false;
        silentChests = silent;
        JsonObject o = new JsonObject();
        o.addProperty("t", "chests");
        o.addProperty("q", query);
        if (!silent) lastError = null;
        waitingChests = true;
        send(o.toString());
        return true;
    }

    /** Server search when the server mod exists, plus remembered containers; otherwise remembered containers only. */
    public static boolean scanChests(String query, boolean silent) {
        if (requestChests(query, silent)) return true;
        JsonObject o = new JsonObject();
        o.addProperty("t", "chests");
        o.addProperty("q", query);
        o.addProperty("total", 0);
        o.add("hits", new com.google.gson.JsonArray());
        com.example.cobbleutility.finder.ChestMemory.mergeInto(o, query);
        lastChests = o;
        waitingChests = false;
        chestsVersion++;
        com.example.cobbleutility.finder.ChestFilter.onResult(o);
        return true;
    }

    // ------------------------------------------------------------ replies
    private static void onReply(JsonObject o) {
        String t = o.has("t") ? o.get("t").getAsString() : "";
        switch (t) {
            case "structures" -> {
                List<String> ids = new ArrayList<>();
                o.getAsJsonArray("ids").forEach(e -> ids.add(e.getAsString()));
                List<String> tags = new ArrayList<>();
                o.getAsJsonArray("tags").forEach(e -> tags.add(e.getAsString()));
                structureIds = ids;
                structureTags = tags;
                structuresVersion++;
            }
            case "located" -> StructureFinder.onLocated(o);
            case "boost" -> com.example.cobbleutility.shiny.ShinyBoost.onServerReply(o);
            case "find" -> {
                lastFind = o;
                waitingFind = false;
                findVersion++;
                com.example.cobbleutility.finder.FinderAlerts.onResult(o);
            }
            case "chests" -> {
                com.example.cobbleutility.finder.ChestMemory.mergeInto(o, o.has("q") ? o.get("q").getAsString() : "");
                lastChests = o;
                waitingChests = false;
                chestsVersion++;
                com.example.cobbleutility.finder.ChestFilter.onResult(o);
            }
            case "error" -> {
                if (silentFind && waitingFind && !(silentChests && waitingChests)) {
                    silentFind = false;
                    waitingFind = false;
                    com.example.cobbleutility.finder.FinderAlerts.reset();
                    return;
                }
                if (silentChests && waitingChests) {
                    silentChests = false;
                    waitingChests = false;
                    return;
                }
                waitingChests = false;
                chestsVersion++;
                String msg = o.has("msg") ? o.get("msg").getAsString() : "Error";
                lastError = msg;
                waitingFind = false;
                findVersion++;
                StructureFinder.onError(msg);
            }
            default -> { }
        }
    }

    static void toast(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal(s), true);
    }

    // ------------------------------------------------------------ state for the screens
    public static List<String> structureIds() { return structureIds; }
    public static List<String> structureTags() { return structureTags; }
    public static int structuresVersion() { return structuresVersion; }
    public static JsonObject lastChests() { return lastChests; }
    public static int chestsVersion() { return chestsVersion; }
    public static boolean waitingChests() { return waitingChests; }
    public static JsonObject lastFind() { return lastFind; }
    public static String lastFindFilter() { return lastFindFilter; }
    public static int findVersion() { return findVersion; }
    public static String lastError() { return lastError; }
    public static boolean waitingFind() { return waitingFind; }
}
