package com.example.cobbleutility.finder;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ConfigScreenBuilder;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.net.ServerLink;
import com.example.cobbleutility.structure.StructureFinder;
import com.example.cobbleutility.util.ColorUtil;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Asks the server mod for the best Pokémon currently loaded around you (shiny, legendary, hidden ability,
 * perfect IVs, species) and lists them with distance / direction / coordinates. Click a line to track it.
 */
public class PokeFinderScreen extends Screen {
    private static final String[][] FILTERS = {
            {"All best", "all"}, {"Shiny", "shiny"}, {"Legendary", "legendary"}, {"Hidden ability", "ha"},
            {"5+ IV", "iv:5"}, {"6 IV", "iv:6"}};

    private final Screen parent;
    private TextFieldWidget speciesField;
    private final List<ButtonWidget> rowButtons = new ArrayList<>();
    private int seenVersion = -1;
    private final List<JsonObject> hits = new ArrayList<>();

    private static final int ROW_H = 22;
    private static final int LIST_TOP = 84;

    public PokeFinderScreen(Screen parent) {
        super(Text.literal("Pokémon Finder"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = width / 2;
        int bw = 80, gap = 3;
        int total = FILTERS.length * bw + (FILTERS.length - 1) * gap;
        int x0 = cx - total / 2;
        for (int i = 0; i < FILTERS.length; i++) {
            final String[] f = FILTERS[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(f[0]), b -> ask(f[1]))
                    .dimensions(x0 + i * (bw + gap), 34, bw, 20).build());
        }
        speciesField = new TextFieldWidget(textRenderer, cx - 150, 58, 190, 20, Text.literal("Species"));
        speciesField.setPlaceholder(Text.literal("species name (e.g. dratini)"));
        speciesField.setMaxLength(40);
        addDrawableChild(speciesField);
        addDrawableChild(ButtonWidget.builder(Text.literal("Find species"), b -> {
            String s = speciesField.getText().trim();
            if (!s.isEmpty()) ask("species:" + s.toLowerCase(Locale.ROOT));
        }).dimensions(cx + 44, 58, 106, 20).build());

        int by = height - 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("Clear waypoint"), b -> StructureFinder.clear())
                .dimensions(cx - 160, by, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Settings"),
                        b -> MinecraftClient.getInstance().setScreen(ConfigScreenBuilder.create(this)))
                .dimensions(cx - 50, by, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(cx + 60, by, 100, 20).build());

        seenVersion = -1; // force a rebuild of the list with the last reply (if any)
        rebuildRows();
    }

    private void ask(String filter) {
        if (!ServerLink.requestFind(filter)) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal("§cServer mod not found."), true);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (ServerLink.findVersion() != seenVersion) rebuildRows();
    }

    private int maxRows() {
        return Math.max(1, (height - LIST_TOP - 40) / ROW_H);
    }

    private void rebuildRows() {
        seenVersion = ServerLink.findVersion();
        for (ButtonWidget b : rowButtons) remove(b);
        rowButtons.clear();
        hits.clear();
        JsonObject res = ServerLink.lastFind();
        if (res == null || !res.has("hits")) return;
        JsonArray arr = res.getAsJsonArray("hits");
        int n = Math.min(arr.size(), maxRows());
        int cx = width / 2;
        for (int i = 0; i < n; i++) {
            JsonElement el = arr.get(i);
            if (!el.isJsonObject()) continue;
            JsonObject h = el.getAsJsonObject();
            hits.add(h);
            if (h.has("x") && h.has("z")) {
                final int x = h.get("x").getAsInt(), z = h.get("z").getAsInt();
                final String name = h.get("name").getAsString();
                ButtonWidget b = ButtonWidget.builder(Text.literal("Track"), btn -> {
                    StructureFinder.trackPos(name, x, z);
                    close();
                }).dimensions(cx + 142, LIST_TOP + i * ROW_H, 46, 18).build();
                rowButtons.add(addDrawableChild(b));
            }
        }
    }

    private static String str(JsonObject o, String k, String def) {
        return o.has(k) ? o.get(k).getAsString() : def;
    }

    private int colorFor(JsonObject h) {
        ModConfig c = ConfigManager.get();
        if (h.get("shiny").getAsBoolean()) return ColorUtil.opaque(c.radarShinyColor);
        if (h.get("legendary").getAsBoolean()) return ColorUtil.opaque(c.radarLegendaryColor);
        if (h.get("ha").getAsBoolean()) return ColorUtil.opaque(c.radarHiddenAbilityColor);
        return ColorUtil.opaque(c.radarHighIvColor);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int cx = width / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, title, cx, 10, 0xFFFFFFFF);

        if (!ServerLink.available()) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("The server does not have the Cobblemon Shiny Control mod (1.3.0+)."), cx, 22, 0xFFFF5555);
        } else {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal("Searches the Pokémon loaded around you on the server. No admin needed."), cx, 22, 0xFFAAAAAA);
        }

        if (ServerLink.waitingFind()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Searching..."), cx, LIST_TOP, 0xFFFFFF55);
            return;
        }
        String err = ServerLink.lastError();
        if (err != null) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(err), cx, LIST_TOP, 0xFFFF5555);
            return;
        }
        JsonObject res = ServerLink.lastFind();
        if (res == null) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Pick a filter to search."), cx, LIST_TOP, 0xFF888888);
            return;
        }
        if (hits.isEmpty()) {
            String msg = res.has("sawAny") && !res.get("sawAny").getAsBoolean()
                    ? "No Pokémon are loaded in this world right now."
                    : "Nothing matches within " + res.get("radius").getAsInt() + " blocks.";
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(msg), cx, LIST_TOP, 0xFF888888);
            return;
        }
        int total = res.get("total").getAsInt();
        for (int i = 0; i < hits.size(); i++) {
            JsonObject h = hits.get(i);
            int y = LIST_TOP + i * ROW_H;
            ctx.fill(cx - 190, y - 2, cx + 190, y + ROW_H - 4, 0x55000000);
            StringBuilder sb = new StringBuilder();
            if (h.get("shiny").getAsBoolean()) sb.append("★ ");
            sb.append(h.get("name").getAsString()).append(" Lv").append(h.get("level").getAsInt());
            if (h.get("legendary").getAsBoolean()) sb.append(" [Leg]");
            if (h.get("ha").getAsBoolean()) sb.append(" [HA]");
            if (h.has("iv")) sb.append("  ").append(h.get("iv").getAsString());
            else if (h.has("perfect")) sb.append("  ").append(h.get("perfect").getAsInt()).append("x31");
            ctx.drawTextWithShadow(textRenderer, Text.literal(sb.toString()), cx - 186, y, colorFor(h));

            StringBuilder where = new StringBuilder();
            where.append(h.get("dist").getAsInt()).append("m ").append(str(h, "dir", ""));
            if (h.has("x")) {
                where.append("  ").append(h.get("x").getAsInt()).append(", ");
                if (h.has("y")) where.append(h.get("y").getAsInt()).append(", ");
                where.append(h.get("z").getAsInt());
                if (h.has("approx")) where.append(" (~)");
            }
            ctx.drawTextWithShadow(textRenderer, Text.literal(where.toString()), cx - 186, y + 10, 0xFFBBBBBB);
        }
        if (total > hits.size()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("+" + (total - hits.size()) + " more (nearest shown)"),
                    cx, height - 42, 0xFF888888);
        }
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }
}
