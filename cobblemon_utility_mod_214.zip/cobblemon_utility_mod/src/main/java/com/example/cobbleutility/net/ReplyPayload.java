package com.example.cobbleutility.net;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Server -> client reply. One JSON string. */
public record ReplyPayload(String json) implements CustomPayload {
    public static final CustomPayload.Id<ReplyPayload> ID =
            new CustomPayload.Id<>(Identifier.of("cobblemon_shiny_control", "reply"));
    public static final PacketCodec<ByteBuf, ReplyPayload> CODEC =
            PacketCodecs.string(400000).xmap(ReplyPayload::new, ReplyPayload::json);

    @Override
    public CustomPayload.Id<? extends CustomPayload> getId() {
        return ID;
    }
}
