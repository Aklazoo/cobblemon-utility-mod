package com.example.cobbleutility.battle;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Standard 18-type effectiveness chart (attacker -> defender). */
public final class TypeChart {
    public static final String[] TYPES = {"normal", "fire", "water", "electric", "grass", "ice", "fighting", "poison",
            "ground", "flying", "psychic", "bug", "rock", "ghost", "dragon", "dark", "steel", "fairy"};

    private static final Map<String, Map<String, Double>> M = new HashMap<>();

    static {
        row("normal", "", "rock steel", "ghost");
        row("fire", "grass ice bug steel", "fire water rock dragon", "");
        row("water", "fire ground rock", "water grass dragon", "");
        row("electric", "water flying", "electric grass dragon", "ground");
        row("grass", "water ground rock", "fire grass poison flying bug dragon steel", "");
        row("ice", "grass ground flying dragon", "fire water ice steel", "");
        row("fighting", "normal ice rock dark steel", "poison flying psychic bug fairy", "ghost");
        row("poison", "grass fairy", "poison ground rock ghost", "steel");
        row("ground", "fire electric poison rock steel", "grass bug", "flying");
        row("flying", "grass fighting bug", "electric rock steel", "");
        row("psychic", "fighting poison", "psychic steel", "dark");
        row("bug", "grass psychic dark", "fire fighting poison flying ghost steel fairy", "");
        row("rock", "fire ice flying bug", "fighting ground steel", "");
        row("ghost", "psychic ghost", "dark", "normal");
        row("dragon", "dragon", "steel", "fairy");
        row("dark", "psychic ghost", "fighting dark fairy", "");
        row("steel", "ice rock fairy", "fire water electric steel", "");
        row("fairy", "fighting dragon dark", "fire poison steel", "");
    }

    private TypeChart() {}

    private static void row(String atk, String se, String nve, String imm) {
        Map<String, Double> r = new HashMap<>();
        for (String t : se.split(" ")) if (!t.isEmpty()) r.put(t, 2.0);
        for (String t : nve.split(" ")) if (!t.isEmpty()) r.put(t, 0.5);
        for (String t : imm.split(" ")) if (!t.isEmpty()) r.put(t, 0.0);
        M.put(atk, r);
    }

    public static double mult(String atk, String def) {
        Map<String, Double> r = M.get(atk == null ? "" : atk.toLowerCase(Locale.ROOT));
        if (r == null) return 1.0;
        return r.getOrDefault(def == null ? "" : def.toLowerCase(Locale.ROOT), 1.0);
    }

    public static double mult(String atk, List<String> defs) {
        double m = 1.0;
        for (String d : defs) m *= mult(atk, d);
        return m;
    }

    /** Every attacking type whose multiplier against these defending types is not 1, strongest first. */
    public static Map<String, Double> matchups(List<String> defs) {
        List<Map.Entry<String, Double>> list = new ArrayList<>();
        for (String t : TYPES) {
            double m = mult(t, defs);
            if (m != 1.0) list.add(Map.entry(t, m));
        }
        list.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        Map<String, Double> out = new LinkedHashMap<>();
        for (Map.Entry<String, Double> e : list) out.put(e.getKey(), e.getValue());
        return out;
    }

    public static String fmt(double m) {
        if (m == 0) return "0";
        if (m == 0.25) return "1/4";
        if (m == 0.5) return "1/2";
        return String.valueOf((int) m);
    }

    public static String cap(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
