package com.example.cobbleutility.ballaim;

import com.example.cobbleutility.battle.CobbleData;
import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.radar.CobblemonBridge;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * While you hold a Poké Ball and a wild Pokémon is near your crosshair, suggests the best ball you carry
 * (rules of thumb from the main games: Master for legendaries, Quick on the first throw, Net for water/bug,
 * Dive underwater, Dusk at night or in caves, Nest for low levels, then Ultra / Great / Poké).
 */
public final class BallAdvice {
    private static String line1, line2;
    private static int cooldown;

    private BallAdvice() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(BallAdvice::tick);
    }

    private static void tick(MinecraftClient mc) {
        line1 = null;
        line2 = null;
        if (mc.player == null || mc.world == null || !ConfigManager.get().ballAdviceEnabled) return;
        if (!BallAim.isBall(mc.player.getMainHandStack()) && !BallAim.isBall(mc.player.getOffHandStack())) return;
        Entity t = BallAim.currentTarget();
        if (t == null) return;
        try {
            CobblemonBridge.Info info = CobblemonBridge.inspect(t, mc);
            if (info == null || info.owned()) return;
            List<String> types = List.of();
            try {
                Object pokemon = CobblemonBridge.reflect(t, "getPokemon");
                types = CobbleData.typesOfPokemon(pokemon);
            } catch (Throwable ignored) {
            }

            long time = mc.world.getTimeOfDay() % 24000;
            boolean night = time >= 13000 && time <= 23000;
            boolean cave = !mc.world.isSkyVisible(t.getBlockPos());
            boolean water = t.isTouchingWater();

            Map<String, String> ideal = new LinkedHashMap<>();
            if (info.legendary() || info.ultraBeast()) ideal.put("master_ball", "legendary: never fails");
            ideal.put("quick_ball", "first throw bonus");
            if (water) ideal.put("dive_ball", "underwater");
            if (types.contains("water") || types.contains("bug")) ideal.put("net_ball", "water / bug type");
            if (night || cave) ideal.put("dusk_ball", night ? "night" : "dark / cave");
            if (info.level() > 0 && info.level() <= 25) ideal.put("nest_ball", "low level");
            ideal.put("ultra_ball", "strong general ball");
            ideal.put("great_ball", "better than a Poké Ball");
            ideal.put("poke_ball", "basic");

            List<String> have = new ArrayList<>();
            for (int i = 0; i < mc.player.getInventory().size(); i++) {
                ItemStack s = mc.player.getInventory().getStack(i);
                if (BallAim.isBall(s)) have.add(Registries.ITEM.getId(s.getItem()).getPath());
            }
            String bestIdeal = ideal.keySet().iterator().next();
            String pick = null;
            for (String id : ideal.keySet()) {
                if (have.contains(id)) {
                    pick = id;
                    break;
                }
            }
            line1 = info.name() + " Lv" + info.level() + ": throw " + (pick == null ? "any ball" : pretty(pick))
                    + (pick == null ? "" : " (" + ideal.get(pick) + ")");
            if (pick == null || !pick.equals(bestIdeal)) {
                line2 = "Ideal: " + pretty(bestIdeal) + " (" + ideal.get(bestIdeal) + ")" + (have.contains(bestIdeal) ? "" : " - you have none");
            }
        } catch (Throwable ignored) {
        }
    }

    private static String pretty(String id) {
        StringBuilder sb = new StringBuilder();
        for (String w : id.split("_")) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }

    public static void renderHud(DrawContext ctx) {
        if (line1 == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        int cx = ctx.getScaledWindowWidth() / 2, y = ctx.getScaledWindowHeight() / 2 + 28;
        com.example.cobbleutility.render.Hud.tag(ctx, mc.textRenderer, line1, cx, y, 0xFFD34E, 1f);
        if (line2 != null) com.example.cobbleutility.render.Hud.tag(ctx, mc.textRenderer, line2, cx, y + 15, 0x8899AA, 0.85f);
    }
}
