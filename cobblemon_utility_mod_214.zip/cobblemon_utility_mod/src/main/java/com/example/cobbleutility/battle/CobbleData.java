package com.example.cobbleutility.battle;

import com.example.cobbleutility.CobblemonUtilityMod;
import com.example.cobbleutility.radar.CobblemonBridge;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/** Reads species, party and battle data from Cobblemon by reflection (no compile dependency). */
public final class CobbleData {
    public record Species(String name, List<String> types) {}
    public record MoveInfo(String name, String type, double power) {}
    public record PartyMon(String name, int level, List<String> types, List<MoveInfo> moves) {}
    public record BattleView(List<String> names, List<List<String>> types) {}

    private static final String CLIENT = "com.cobblemon.mod.common.client.CobblemonClient";
    private static final String SPECIES = "com.cobblemon.mod.common.api.pokemon.PokemonSpecies";

    private static Map<String, Species> speciesByKey;
    private static boolean dumped;

    private CobbleData() {}

    static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private static Object call(Object o, String m) {
        return CobblemonBridge.reflect(o, m);
    }

    private static Object instance(String cls) {
        try {
            Field f = Class.forName(cls).getField("INSTANCE");
            return f.get(null);
        } catch (Throwable t) {
            return null;
        }
    }

    public static boolean cobblemonPresent() {
        return instance(SPECIES) != null;
    }

    // ------------------------------------------------------------ types / species
    private static String typeName(Object elementalType) {
        if (elementalType == null) return null;
        Object n = call(elementalType, "getName");
        String s = norm(n == null ? String.valueOf(elementalType) : String.valueOf(n));
        for (String t : TypeChart.TYPES) if (s.equals(t)) return t;
        for (String t : TypeChart.TYPES) if (s.contains(t)) return t;
        return null;
    }

    private static List<String> typesFrom(Object holder) {
        List<String> out = new ArrayList<>();
        if (holder == null) return out;
        String a = typeName(call(holder, "getPrimaryType"));
        String b = typeName(call(holder, "getSecondaryType"));
        if (a != null) out.add(a);
        if (b != null && !b.equals(a)) out.add(b);
        return out;
    }

    /** Types of a Pokémon object (uses its form, then its species). */
    public static List<String> typesOfPokemon(Object pokemon) {
        List<String> t = typesFrom(call(pokemon, "getForm"));
        if (t.isEmpty()) t = typesFrom(call(pokemon, "getSpecies"));
        return t;
    }

    public static synchronized Map<String, Species> species() {
        if (speciesByKey != null) return speciesByKey;
        Map<String, Species> map = new TreeMap<>();
        try {
            Object reg = instance(SPECIES);
            Object all = call(reg, "getSpecies");
            if (all instanceof Collection<?> c) {
                for (Object sp : c) {
                    Object n = call(sp, "getName");
                    if (n == null) continue;
                    List<String> types = typesFrom(sp);
                    if (types.isEmpty()) continue;
                    map.put(norm(String.valueOf(n)), new Species(String.valueOf(n), types));
                }
            }
        } catch (Throwable t) {
            CobblemonUtilityMod.LOGGER.warn("Could not read the species list", t);
        }
        if (!map.isEmpty()) speciesByKey = map; // retry later if empty (world not loaded yet)
        return map;
    }

    public static Species speciesByName(String name) {
        return species().get(norm(name));
    }

    // ------------------------------------------------------------ party
    public static List<PartyMon> party() {
        List<PartyMon> out = new ArrayList<>();
        try {
            Object client = instance(CLIENT);
            Object slots = call(call(call(client, "getStorage"), "getMyParty"), "getSlots");
            if (!(slots instanceof Iterable<?> it)) return out;
            for (Object p : it) {
                if (p == null) continue;
                Object sp = call(p, "getSpecies");
                Object n = call(sp, "getName");
                Object lvl = call(p, "getLevel");
                List<MoveInfo> moves = new ArrayList<>();
                Object mv = call(call(p, "getMoveSet"), "getMoves");
                if (mv instanceof Iterable<?> mi) {
                    for (Object m : mi) {
                        if (m == null) continue;
                        Object power = call(m, "getPower");
                        moves.add(new MoveInfo(String.valueOf(call(m, "getName")),
                                typeName(call(m, "getType")) == null ? "" : typeName(call(m, "getType")),
                                power instanceof Number pn ? pn.doubleValue() : 0));
                    }
                }
                out.add(new PartyMon(n == null ? "?" : String.valueOf(n), lvl instanceof Number ln ? ln.intValue() : 0,
                        typesOfPokemon(p), moves));
            }
        } catch (Throwable t) {
            CobblemonUtilityMod.LOGGER.warn("Could not read the party", t);
        }
        return out;
    }

    // ------------------------------------------------------------ battle
    /** Null when no battle is running; empty lists when a battle runs but could not be read. */
    public static BattleView battle(MinecraftClient mc) {
        Object battle = call(instance(CLIENT), "getBattle");
        if (battle == null) return null;
        List<String> names = new ArrayList<>();
        List<List<String>> types = new ArrayList<>();
        try {
            Object s1 = call(battle, "getSide1"), s2 = call(battle, "getSide2");
            Object mine = containsPlayer(s1, mc) ? s1 : (containsPlayer(s2, mc) ? s2 : null);
            Object opp = mine == s1 ? s2 : s1;
            if (mine == null) opp = s2;
            Object actors = call(opp, "getActors");
            if (actors instanceof Iterable<?> ai) {
                for (Object a : ai) {
                    Object actives = call(a, "getActivePokemon");
                    if (!(actives instanceof Iterable<?> pi)) continue;
                    for (Object ap : pi) {
                        Object bp = call(ap, "getBattlePokemon");
                        if (bp == null) continue;
                        String name = battleName(bp);
                        if (name == null) continue;
                        Species sp = speciesByName(name);
                        if (sp == null) continue;
                        names.add(sp.name());
                        types.add(sp.types());
                    }
                }
            }
        } catch (Throwable t) {
            CobblemonUtilityMod.LOGGER.warn("Battle read failed", t);
        }
        if (names.isEmpty() && !dumped) {
            dumped = true;
            dump(battle);
        }
        return new BattleView(names, types);
    }

    public static void resetDump() {
        dumped = false;
    }

    private static boolean containsPlayer(Object side, MinecraftClient mc) {
        Object actors = call(side, "getActors");
        if (!(actors instanceof Iterable<?> it) || mc.player == null) return false;
        for (Object a : it) {
            Object u = call(a, "getUuid");
            if (u != null && u.equals(mc.player.getUuid())) return true;
        }
        return false;
    }

    private static String battleName(Object bp) {
        Object sp = call(bp, "getSpecies");
        if (sp != null) {
            Object n = call(sp, "getName");
            if (n != null) return String.valueOf(n);
        }
        Object props = call(bp, "getProperties");
        Object ps = call(props, "getSpecies");
        if (ps != null) return String.valueOf(ps).replace("cobblemon:", "");
        Object dn = call(bp, "getDisplayName");
        if (dn instanceof Text t) return t.getString();
        return null;
    }

    private static void dump(Object battle) {
        try {
            StringBuilder sb = new StringBuilder("Battle advisor could not read the opponent. Cobblemon battle API:\n");
            describe(sb, "battle", battle);
            Object s1 = call(battle, "getSide1");
            describe(sb, "side", s1);
            Object actors = call(s1, "getActors");
            if (actors instanceof Iterable<?> it) for (Object a : it) {
                describe(sb, "actor", a);
                Object actives = call(a, "getActivePokemon");
                if (actives instanceof Iterable<?> pi) for (Object ap : pi) {
                    describe(sb, "active", ap);
                    describe(sb, "battlePokemon", call(ap, "getBattlePokemon"));
                    break;
                }
                break;
            }
            CobblemonUtilityMod.LOGGER.warn(sb.toString());
        } catch (Throwable t) {
            CobblemonUtilityMod.LOGGER.warn("dump failed", t);
        }
    }

    private static void describe(StringBuilder sb, String label, Object o) {
        sb.append(" [").append(label).append("] ");
        if (o == null) {
            sb.append("null\n");
            return;
        }
        sb.append(o.getClass().getName()).append(": ");
        for (Method m : o.getClass().getMethods()) {
            if (m.getParameterCount() == 0 && m.getDeclaringClass() != Object.class) sb.append(m.getName()).append(' ');
        }
        sb.append('\n');
    }
}
