package com.example.cobbleutility.battle;

import com.example.cobbleutility.config.ConfigScreenBuilder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Pick an opponent species: types, weaknesses, and which of your party members suits best. */
public class TypeAdvisorScreen extends Screen {
    private final Screen parent;
    private TextFieldWidget search;
    private final List<CobbleData.Species> filtered = new ArrayList<>();
    private int scroll = 0;
    private CobbleData.Species selected;
    private List<CobbleData.PartyMon> party = List.of();

    private static final int LIST_W = 150, ROW = 12, TOP = 56;

    public TypeAdvisorScreen(Screen parent) {
        super(Text.literal("Type Advisor"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        party = CobbleData.party();
        search = new TextFieldWidget(textRenderer, 10, 30, LIST_W, 20, Text.literal("Species"));
        search.setPlaceholder(Text.literal("opponent species"));
        search.setMaxLength(40);
        search.setChangedListener(s -> {
            scroll = 0;
            apply();
        });
        addDrawableChild(search);
        setInitialFocus(search);
        addDrawableChild(ButtonWidget.builder(Text.literal("Settings"),
                        b -> MinecraftClient.getInstance().setScreen(ConfigScreenBuilder.create(this)))
                .dimensions(width - 210, height - 26, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(width - 104, height - 26, 94, 20).build());
        apply();
    }

    private int rows() {
        return Math.max(3, (height - TOP - 10) / ROW);
    }

    private void apply() {
        String q = search == null ? "" : search.getText().toLowerCase(Locale.ROOT).trim();
        filtered.clear();
        for (CobbleData.Species s : CobbleData.species().values()) {
            if (q.isEmpty() || s.name().toLowerCase(Locale.ROOT).contains(q)) filtered.add(s);
        }
        scroll = Math.max(0, Math.min(scroll, Math.max(0, filtered.size() - rows())));
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        scroll -= (int) Math.signum(v) * 3;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, filtered.size() - rows())));
        return true;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (mx >= 10 && mx < 10 + LIST_W && my >= TOP) {
            int idx = scroll + (int) ((my - TOP) / ROW);
            if (idx >= 0 && idx < filtered.size() && (my - TOP) / ROW < rows()) {
                selected = filtered.get(idx);
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 10, 0xFFFFFFFF);
        if (filtered.isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, Text.literal(CobbleData.cobblemonPresent()
                    ? "No species found" : "Cobblemon data not readable"), 10, TOP, 0xFFFF5555);
        }
        for (int i = 0; i < rows() && scroll + i < filtered.size(); i++) {
            CobbleData.Species s = filtered.get(scroll + i);
            int y = TOP + i * ROW;
            boolean sel = s == selected;
            boolean hover = mouseX >= 10 && mouseX < 10 + LIST_W && mouseY >= y && mouseY < y + ROW;
            if (sel || hover) ctx.fill(10, y - 1, 10 + LIST_W, y + ROW - 1, sel ? 0x6655AAFF : 0x33FFFFFF);
            ctx.drawTextWithShadow(textRenderer, Text.literal(s.name()), 13, y + 1, 0xFFFFFFFF);
        }
        if (selected == null) {
            ctx.drawTextWithShadow(textRenderer, Text.literal("Click an opponent species on the left."), 180, TOP, 0xFF888888);
            return;
        }
        int x = 180, y = TOP;
        ctx.drawTextWithShadow(textRenderer, Text.literal("§e" + selected.name() + " §7("
                + String.join("/", selected.types().stream().map(TypeChart::cap).toList()) + ")"), x, y, 0xFFFFFFFF);
        y += 16;
        StringBuilder weak = new StringBuilder("§cHit it with: ");
        StringBuilder res = new StringBuilder("§aIt resists: ");
        for (Map.Entry<String, Double> e : TypeChart.matchups(selected.types()).entrySet()) {
            if (e.getValue() > 1) weak.append(TypeChart.cap(e.getKey())).append(" x").append(TypeChart.fmt(e.getValue())).append("  ");
            else res.append(TypeChart.cap(e.getKey())).append(e.getValue() == 0 ? "(0)  " : "  ");
        }
        ctx.drawTextWithShadow(textRenderer, Text.literal(weak.toString()), x, y, 0xFFFFFFFF);
        y += 12;
        ctx.drawTextWithShadow(textRenderer, Text.literal(res.toString()), x, y, 0xFFFFFFFF);
        y += 20;
        ctx.drawTextWithShadow(textRenderer, Text.literal("§bYour team, best first:"), x, y, 0xFFFFFFFF);
        y += 13;
        if (party.isEmpty()) {
            ctx.drawTextWithShadow(textRenderer, Text.literal("§7Party not readable (open it once in game, then retry)."), x, y, 0xFFFFFFFF);
            return;
        }
        List<Advisor.Ranked> ranked = Advisor.rank(party, selected.types());
        for (int i = 0; i < ranked.size(); i++) {
            ctx.drawTextWithShadow(textRenderer, Text.literal("§f" + (i + 1) + ". " + Advisor.describe(ranked.get(i))), x, y, 0xFFFFFFFF);
            y += 12;
        }
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }
}
