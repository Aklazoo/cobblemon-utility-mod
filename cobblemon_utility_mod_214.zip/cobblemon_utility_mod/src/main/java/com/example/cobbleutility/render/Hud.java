package com.example.cobbleutility.render;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

/** Shared look for every HUD element of the mod: dark glass panels, thin border, colored accent. */
public final class Hud {
    private Hud() {}

    public static int alpha(int argb, float a) {
        int al = Math.max(8, Math.min(255, Math.round(((argb >>> 24) & 0xFF) * a)));
        return (al << 24) | (argb & 0xFFFFFF);
    }

    /** Panel with a colored accent bar on the left. */
    public static void panel(DrawContext ctx, int x, int y, int w, int h, int accentRgb, float a) {
        ctx.fill(x, y, x + w, y + h, alpha(0xC0101419, a));
        ctx.fill(x, y, x + w, y + 1, alpha(0x40FFFFFF, a));
        ctx.fill(x, y + h - 1, x + w, y + h, alpha(0x40000000, a));
        ctx.fill(x, y, x + 2, y + h, alpha(0xFF000000 | accentRgb, a));
    }

    /** Small centered label ("pill") with a colored underline. */
    public static void tag(DrawContext ctx, TextRenderer tr, String text, int cx, int cy, int rgb, float a) {
        int w = tr.getWidth(text) + 8;
        int x = cx - w / 2, y = cy - 5;
        ctx.fill(x, y, x + w, y + 12, alpha(0xA0101419, a));
        ctx.fill(x, y + 11, x + w, y + 12, alpha(0xFF000000 | rgb, a));
        ctx.drawText(tr, Text.literal(text), x + 4, y + 2, alpha(0xFFFFFFFF, a), true);
    }

    /** Arrow glyph pointing from the screen center toward an edge position. */
    public static String arrow(float sx, float sy, int sw, int sh) {
        float dx = sx - sw / 2f, dy = sy - sh / 2f;
        if (Math.abs(dx) > Math.abs(dy)) return dx > 0 ? "▶" : "◀";
        return dy > 0 ? "▼" : "▲";
    }
}
