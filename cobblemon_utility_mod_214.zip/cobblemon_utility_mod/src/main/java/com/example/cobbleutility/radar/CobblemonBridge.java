package com.example.cobbleutility.radar;

import com.example.cobbleutility.CobblemonUtilityMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.registry.Registries;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/**
 * All Cobblemon access lives here and goes through reflection, so the mod compiles without
 * Cobblemon on the classpath and a Cobblemon API change only degrades features instead of crashing.
 *
 * Data availability: shiny / species / legendary are synced to the client. IVs and ability are NOT
 * synced for wild Pokémon on a remote server; in singleplayer we read the real server-side entity.
 */
public final class CobblemonBridge {
    private static final Identifier POKEMON_ID = Identifier.of("cobblemon", "pokemon");
    private static EntityType<?> pokemonType;
    private static boolean warned;

    public record Info(String name, String speciesId, int level, boolean shiny, boolean legendary,
                       boolean ultraBeast, boolean hiddenAbility, int perfectIvs, boolean ivKnown,
                       boolean owned) {}

    private CobblemonBridge() {}

    public static boolean isPokemon(Entity e) {
        if (pokemonType == null) {
            pokemonType = Registries.ENTITY_TYPE.getOrEmpty(POKEMON_ID).orElse(null);
            if (pokemonType == null) return false;
        }
        return e.getType() == pokemonType;
    }

    public static Info inspect(Entity clientEntity, MinecraftClient mc) {
        try {
            Object pokemon = null;
            boolean serverData = false;

            IntegratedServer srv = mc.getServer();
            if (srv != null && mc.world != null) {
                ServerWorld sw = srv.getWorld(mc.world.getRegistryKey());
                if (sw != null) {
                    Entity se = sw.getEntityById(clientEntity.getId());
                    if (se != null && isPokemon(se)) {
                        pokemon = call(se, "getPokemon");
                        serverData = pokemon != null;
                    }
                }
            }
            if (pokemon == null) pokemon = call(clientEntity, "getPokemon");
            if (pokemon == null) return null;

            Object species = call(pokemon, "getSpecies");
            String name = "Pokémon";
            Object translated = call(species, "getTranslatedName");
            if (translated instanceof Text t) name = t.getString();
            else {
                Object n = call(species, "getName");
                if (n != null) name = String.valueOf(n);
            }

            String speciesId = name;
            Object rawId = call(species, "getName");
            if (rawId != null) speciesId = String.valueOf(rawId);
            Object lvl = call(pokemon, "getLevel");
            int level = lvl instanceof Number ln ? ln.intValue() : 0;

            boolean shiny = Boolean.TRUE.equals(call(pokemon, "getShiny"));
            boolean legendary = Boolean.TRUE.equals(call(pokemon, "isLegendary"))
                    || Boolean.TRUE.equals(call(pokemon, "isMythical"))
                    || hasLabel(species, "legendary") || hasLabel(species, "mythical");
            boolean ultraBeast = Boolean.TRUE.equals(call(pokemon, "isUltraBeast"))
                    || hasLabel(species, "ultra_beast") || hasLabel(species, "paradox");
            boolean owned = call(pokemon, "getOwnerUUID") != null;

            int perfect = 0;
            boolean ivKnown = false;
            Object ivs = call(pokemon, "getIvs");
            if (serverData && ivs instanceof Iterable<?> it) {
                for (Object o : it) {
                    if (o instanceof Map.Entry<?, ?> en && en.getValue() instanceof Number num) {
                        ivKnown = true;
                        if (num.intValue() >= 31) perfect++;
                    }
                }
            }
            boolean hidden = serverData && hiddenAbility(pokemon);

            return new Info(name, speciesId, level, shiny, legendary, ultraBeast, hidden, perfect, ivKnown, owned);
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                CobblemonUtilityMod.LOGGER.warn("Cobblemon inspection failed (API change?)", t);
            }
            return null;
        }
    }

    public static Object reflect(Object target, String method) {
        return call(target, method);
    }

    private static boolean hasLabel(Object species, String label) {
        Object labels = call(species, "getLabels");
        if (labels instanceof Collection<?> c) {
            for (Object o : c) if (label.equalsIgnoreCase(String.valueOf(o))) return true;
        }
        return false;
    }

    /** Best effort: is the current ability one of the form's "hidden" potential abilities? */
    private static boolean hiddenAbility(Object pokemon) {
        try {
            Object template = call(call(pokemon, "getAbility"), "getTemplate");
            Object pool = call(call(pokemon, "getForm"), "getAbilities");
            if (template == null || !(pool instanceof Iterable<?> it)) return false;
            for (Object potential : it) {
                Object tpl = call(potential, "getTemplate");
                Object type = call(potential, "getType");
                if (tpl != null && tpl.equals(template) && type != null
                        && type.getClass().getSimpleName().toLowerCase().contains("hidden")) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    // ------------------------------------------------------------ reflection helper
    private static final Map<String, Optional<Method>> METHODS = new ConcurrentHashMap<>();

    private static Object call(Object target, String method) {
        if (target == null) return null;
        Class<?> cls = target.getClass();
        Optional<Method> m = METHODS.computeIfAbsent(cls.getName() + "#" + method, k -> find(cls, method));
        if (m.isEmpty()) return null;
        try {
            return m.get().invoke(target);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Optional<Method> find(Class<?> cls, String name) {
        for (Method m : cls.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == 0) {
                try {
                    m.setAccessible(true);
                } catch (Throwable ignored) {
                }
                return Optional.of(m);
            }
        }
        return Optional.empty();
    }
}
