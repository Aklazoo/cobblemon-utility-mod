package com.example.cobbleutility.battle;

import com.example.cobbleutility.config.ConfigManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** HUD shown during a Cobblemon battle: opponent types, weaknesses and which of your Pokémon to send. */
public final class BattleAdvisor {
    private static final List<String> lines = new ArrayList<>();
    private static boolean unreadable;
    private static boolean wasInBattle;
    private static int cooldown;

    private BattleAdvisor() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(BattleAdvisor::tick);
    }

    private static void tick(MinecraftClient mc) {
        if (mc.player == null || !ConfigManager.get().battleAdvisorEnabled) {
            lines.clear();
            return;
        }
        if (--cooldown > 0) return;
        cooldown = 10;
        try {
            CobbleData.BattleView bv = CobbleData.battle(mc);
            if (bv == null) {
                lines.clear();
                unreadable = false;
                if (wasInBattle) CobbleData.resetDump();
                wasInBattle = false;
                return;
            }
            wasInBattle = true;
            if (bv.names().isEmpty()) {
                lines.clear();
                unreadable = true;
                return;
            }
            unreadable = false;
            List<String> out = new ArrayList<>();
            List<CobbleData.PartyMon> party = CobbleData.party();
            for (int i = 0; i < bv.names().size(); i++) {
                List<String> types = bv.types().get(i);
                out.add("§e" + bv.names().get(i) + " §7(" + String.join("/", types.stream().map(TypeChart::cap).toList()) + ")");
                StringBuilder weak = new StringBuilder("§cWeak: ");
                StringBuilder res = new StringBuilder("§aResists: ");
                int w = 0, r = 0;
                for (Map.Entry<String, Double> e : TypeChart.matchups(types).entrySet()) {
                    if (e.getValue() > 1 && w < 6) {
                        weak.append(TypeChart.cap(e.getKey())).append(" x").append(TypeChart.fmt(e.getValue())).append("  ");
                        w++;
                    } else if (e.getValue() < 1 && r < 6) {
                        res.append(TypeChart.cap(e.getKey())).append(e.getValue() == 0 ? "(0) " : " ");
                        r++;
                    }
                }
                out.add(weak.toString());
                out.add(res.toString());
                if (i == 0 && !party.isEmpty()) {
                    List<Advisor.Ranked> ranked = Advisor.rank(party, types);
                    out.add("§bBest picks:");
                    for (int k = 0; k < Math.min(3, ranked.size()); k++) {
                        out.add("§f" + (k + 1) + ". " + Advisor.describe(ranked.get(k)));
                    }
                }
            }
            lines.clear();
            lines.addAll(out);
        } catch (Throwable t) {
            lines.clear();
        }
    }

    public static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        if (unreadable) {
            com.example.cobbleutility.render.Hud.tag(ctx, tr, "Battle advisor: can't read this battle (see latest.log)", ctx.getScaledWindowWidth() / 2, 18, 0xFF5555, 1f);
            return;
        }
        if (lines.isEmpty()) return;
        int w = 0;
        for (String s : lines) w = Math.max(w, tr.getWidth(s));
        w = Math.max(w, tr.getWidth("BATTLE ADVISOR"));
        int x = ctx.getScaledWindowWidth() - w - 14, y = 8;
        com.example.cobbleutility.render.Hud.panel(ctx, x - 8, y - 4, w + 16, lines.size() * 11 + 18, 0xE0A030, 1f);
        ctx.drawTextWithShadow(tr, Text.literal("§6BATTLE ADVISOR"), x, y, 0xFFFFFFFF);
        y += 12;
        for (String s : lines) {
            ctx.drawTextWithShadow(tr, Text.literal(s), x, y, 0xFFFFFFFF);
            y += 11;
        }
    }
}
