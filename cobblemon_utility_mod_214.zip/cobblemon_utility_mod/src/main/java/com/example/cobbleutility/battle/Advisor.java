package com.example.cobbleutility.battle;

import java.util.ArrayList;
import java.util.List;

/** Scores your party against an opponent's types. */
public final class Advisor {
    public record Ranked(String name, int level, double score, String bestMove, double bestMult, double takenMult,
                         boolean typeBased) {}

    private Advisor() {}

    public static List<Ranked> rank(List<CobbleData.PartyMon> party, List<String> oppTypes) {
        List<Ranked> out = new ArrayList<>();
        for (CobbleData.PartyMon m : party) {
            double best = 0, bestMult = 1;
            String bestMove = null;
            for (CobbleData.MoveInfo mv : m.moves()) {
                if (mv.power() <= 0 || mv.type().isEmpty()) continue;
                double mult = TypeChart.mult(mv.type(), oppTypes);
                double val = mv.power() * mult * (m.types().contains(mv.type()) ? 1.5 : 1.0);
                if (val > best) {
                    best = val;
                    bestMult = mult;
                    bestMove = mv.name();
                }
            }
            boolean typeBased = false;
            if (bestMove == null) {
                typeBased = true;
                for (String t : m.types()) {
                    double mult = TypeChart.mult(t, oppTypes);
                    double val = 80 * mult * 1.5;
                    if (val > best) {
                        best = val;
                        bestMult = mult;
                        bestMove = TypeChart.cap(t) + " attack";
                    }
                }
            }
            double taken = 0;
            for (String ot : oppTypes) taken = Math.max(taken, TypeChart.mult(ot, m.types()));
            double factor = taken == 0 ? 1.4 : taken < 1 ? 1.25 : taken >= 2 ? 0.6 : 1.0;
            out.add(new Ranked(m.name(), m.level(), best * factor, bestMove, bestMult, taken, typeBased));
        }
        out.sort((a, b) -> Double.compare(b.score(), a.score()));
        return out;
    }

    public static String describe(Ranked r) {
        StringBuilder sb = new StringBuilder(r.name());
        if (r.level() > 0) sb.append(" Lv").append(r.level());
        if (r.bestMove() != null) sb.append(" - ").append(r.bestMove()).append(" x").append(TypeChart.fmt(r.bestMult()));
        if (r.takenMult() >= 2) sb.append("  (takes x").append(TypeChart.fmt(r.takenMult())).append("!)");
        else if (r.takenMult() < 1) sb.append("  (resists)");
        return sb.toString();
    }
}
