package com.example.cobbleutility.input;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.util.KeyUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/**
 * "Click an action, then press the key" binding screen.
 * ESC cancels, BACKSPACE / DELETE unbinds. Warns about conflicts with other actions and with
 * Minecraft / Cobblemon keybinds.
 */
public class KeybindScreen extends Screen {
    private record Slot(String label, IntSupplier get, IntConsumer set, int def) {}

    private final Screen parent;
    private final Slot[] slots;
    private final ButtonWidget[] buttons;
    private final String[] conflicts;
    private int listening = -1;

    public KeybindScreen(Screen parent) {
        super(Text.literal("Keybinds"));
        this.parent = parent;
        ModConfig c = ConfigManager.get();
        ModConfig d = new ModConfig();
        this.slots = new Slot[]{
                new Slot("Open settings menu", () -> c.keyOpenSettings, v -> c.keyOpenSettings = v, d.keyOpenSettings),
                new Slot("Open structure finder", () -> c.keyStructureFinder, v -> c.keyStructureFinder = v, d.keyStructureFinder),
                new Slot("Toggle chest ESP", () -> c.keyToggleChestEsp, v -> c.keyToggleChestEsp = v, d.keyToggleChestEsp),
                new Slot("Toggle Cobblemon radar", () -> c.keyToggleRadar, v -> c.keyToggleRadar = v, d.keyToggleRadar),
                new Slot("Mark / unmark looked-at container", () -> c.keyMarkContainer, v -> c.keyMarkContainer = v, d.keyMarkContainer),
                new Slot("Open Pokémon menu", () -> c.keyOpenPokeMenu, v -> c.keyOpenPokeMenu = v, d.keyOpenPokeMenu),
                new Slot("Inspect block (Shift = add/ignore)", () -> c.keyInspectBlock, v -> c.keyInspectBlock = v, d.keyInspectBlock),
                new Slot("Open Pokémon finder (server)", () -> c.keyPokeFinder, v -> c.keyPokeFinder = v, d.keyPokeFinder),
                new Slot("Toggle Poké Ball aim", () -> c.keyBallAim, v -> c.keyBallAim = v, d.keyBallAim),
                new Slot("Open container filter (server)", () -> c.keyChestFilter, v -> c.keyChestFilter = v, d.keyChestFilter),
                new Slot("Open Type Advisor", () -> c.keyTypeAdvisor, v -> c.keyTypeAdvisor = v, d.keyTypeAdvisor),
                new Slot("Stream mode (hide everything)", () -> c.keyStreamMode, v -> c.keyStreamMode = v, d.keyStreamMode),
                new Slot("Shiny boost on/off (server)", () -> c.keyShinyBoost, v -> c.keyShinyBoost = v, d.keyShinyBoost)
        };
        this.buttons = new ButtonWidget[slots.length];
        this.conflicts = new String[slots.length];
    }

    @Override
    protected void init() {
        int top = 48;
        for (int i = 0; i < slots.length; i++) {
            final int idx = i;
            buttons[i] = addDrawableChild(ButtonWidget.builder(Text.empty(), b -> {
                listening = idx;
                refresh();
            }).dimensions(width / 2 + 20, top + i * 20, 140, 20).build());
        }
        int by = top + slots.length * 20 + 8;
        addDrawableChild(ButtonWidget.builder(Text.literal("Reset to defaults"), b -> {
            for (Slot s : slots) s.set().accept(s.def());
            ConfigManager.save();
            listening = -1;
            refresh();
        }).dimensions(width / 2 - 104, by, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(width / 2 + 4, by, 100, 20).build());
        refresh();
    }

    private void refresh() {
        MinecraftClient mc = MinecraftClient.getInstance();
        for (int i = 0; i < slots.length; i++) {
            int code = slots[i].get().getAsInt();
            if (listening == i) {
                buttons[i].setMessage(Text.literal("> Press a key <").formatted(net.minecraft.util.Formatting.YELLOW));
            } else {
                buttons[i].setMessage(Text.literal(KeyUtil.displayName(code)));
            }
            conflicts[i] = null;
            if (code < 0) continue;
            for (int j = 0; j < slots.length; j++) {
                if (j != i && slots[j].get().getAsInt() == code) {
                    conflicts[i] = "Also used by: " + slots[j].label();
                    break;
                }
            }
            if (conflicts[i] == null && mc.options != null) {
                for (KeyBinding kb : mc.options.allKeys) {
                    if (kb.matchesKey(code, -1)) {
                        conflicts[i] = "Also used by: " + Text.translatable(kb.getTranslationKey()).getString();
                        break;
                    }
                }
            }
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening >= 0) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                // cancel
            } else if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) {
                slots[listening].set().accept(GLFW.GLFW_KEY_UNKNOWN);
                ConfigManager.save();
            } else {
                slots[listening].set().accept(keyCode);
                ConfigManager.save();
            }
            listening = -1;
            refresh();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Click an action, then press a key. ESC = cancel, BACKSPACE = unbind"),
                width / 2, 28, 0xFFAAAAAA);
        for (int i = 0; i < slots.length; i++) {
            int y = 48 + i * 20;
            ctx.drawTextWithShadow(textRenderer, Text.literal(slots[i].label()), width / 2 - 160, y + 6, 0xFFFFFFFF);
            if (conflicts[i] != null) {
                ctx.drawTextWithShadow(textRenderer, Text.literal("⚠ " + conflicts[i]), width / 2 - 160, y + 11, 0xFFFF5555);
            }
        }
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }
}
