package com.example.cobbleutility.finder;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Grid of every item registered in the game (vanilla, Cobblemon and all other mods), drawn with its icon.
 * Same idea as the JEI item list, but built in, so no extra dependency is needed.
 * Mouse wheel scrolls, click picks the item.
 */
public class ItemPickerScreen extends Screen {
    private static List<ItemStack> ALL;

    private final Screen parent;
    private final Consumer<String> onPick;
    private final List<ItemStack> filtered = new ArrayList<>();
    private TextFieldWidget search;
    private int scrollRow = 0;
    private boolean moddedOnly = false;
    private ButtonWidget modBtn;

    private static final int CELL = 20, TOP = 58;

    public ItemPickerScreen(Screen parent, Consumer<String> onPick) {
        super(Text.literal("Pick an item"));
        this.parent = parent;
        this.onPick = onPick;
    }

    private static List<ItemStack> all() {
        if (ALL == null) {
            List<ItemStack> list = new ArrayList<>();
            for (Item item : Registries.ITEM) {
                if (item == net.minecraft.item.Items.AIR) continue;
                list.add(new ItemStack(item));
            }
            list.sort((a, b) -> idOf(a).compareTo(idOf(b)));
            ALL = list;
        }
        return ALL;
    }

    private static String idOf(ItemStack s) {
        return Registries.ITEM.getId(s.getItem()).toString();
    }

    private int cols() {
        return Math.max(4, (width - 40) / CELL);
    }

    private int rows() {
        return Math.max(2, (height - TOP - 36) / CELL);
    }

    @Override
    protected void init() {
        int cx = width / 2;
        search = new TextFieldWidget(textRenderer, cx - 160, 30, 220, 20, Text.literal("Search"));
        search.setPlaceholder(Text.literal("name or id (e.g. fossil, cobblemon:)"));
        search.setMaxLength(80);
        search.setChangedListener(s -> {
            scrollRow = 0;
            applyFilter();
        });
        addDrawableChild(search);
        setInitialFocus(search);
        modBtn = addDrawableChild(ButtonWidget.builder(Text.literal(moddedOnly ? "Modded only" : "All items"), b -> {
            moddedOnly = !moddedOnly;
            b.setMessage(Text.literal(moddedOnly ? "Modded only" : "All items"));
            scrollRow = 0;
            applyFilter();
        }).dimensions(cx + 64, 30, 96, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close())
                .dimensions(cx - 50, height - 26, 100, 20).build());
        applyFilter();
    }

    private void applyFilter() {
        String q = search == null ? "" : search.getText().toLowerCase(Locale.ROOT).trim();
        filtered.clear();
        for (ItemStack s : all()) {
            String id = idOf(s);
            if (moddedOnly && id.startsWith("minecraft:")) continue;
            if (q.isEmpty() || id.contains(q) || s.getName().getString().toLowerCase(Locale.ROOT).contains(q)) {
                filtered.add(s);
            }
        }
        clampScroll();
    }

    private void clampScroll() {
        int totalRows = (filtered.size() + cols() - 1) / cols();
        scrollRow = Math.max(0, Math.min(scrollRow, Math.max(0, totalRows - rows())));
    }

    private int originX() {
        return (width - cols() * CELL) / 2;
    }

    private int indexAt(double mx, double my) {
        if (my < TOP || mx < originX()) return -1;
        int c = (int) ((mx - originX()) / CELL);
        int r = (int) ((my - TOP) / CELL);
        if (c >= cols() || r >= rows()) return -1;
        int idx = (scrollRow + r) * cols() + c;
        return idx >= 0 && idx < filtered.size() ? idx : -1;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scrollRow -= (int) Math.signum(vertical) * 2;
        clampScroll();
        return true;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int idx = indexAt(mouseX, mouseY);
        if (idx >= 0 && button == 0) {
            String id = idOf(filtered.get(idx));
            Screen back = parent;
            MinecraftClient.getInstance().setScreen(back);
            onPick.accept(id);
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 10, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal(filtered.size() + " items - scroll for more, click to pick"), width / 2, 46, 0xFF888888);
        int cols = cols(), rows = rows(), ox = originX();
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                int idx = (scrollRow + r) * cols + c;
                if (idx >= filtered.size()) break;
                int x = ox + c * CELL, y = TOP + r * CELL;
                ctx.fill(x, y, x + CELL - 1, y + CELL - 1, 0x55000000);
                ctx.drawItem(filtered.get(idx), x + 2, y + 2);
            }
        }
        int hover = indexAt(mouseX, mouseY);
        if (hover >= 0) {
            ItemStack s = filtered.get(hover);
            ctx.drawTooltip(textRenderer, List.of(s.getName(), Text.literal(idOf(s)).formatted(net.minecraft.util.Formatting.GRAY)),
                    mouseX, mouseY);
        }
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }
}
