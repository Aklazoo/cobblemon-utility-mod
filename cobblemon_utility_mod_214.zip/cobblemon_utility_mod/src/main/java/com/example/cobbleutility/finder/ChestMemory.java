package com.example.cobbleutility.finder;

import com.example.cobbleutility.CobblemonUtilityMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.inventory.CraftingResultInventory;
import net.minecraft.inventory.RecipeInputInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Remembers what you saw inside every container you opened (per server and dimension), so the container
 * filter can find them again. This is the only way to "see" per-player loot chests (Lootr) and modded
 * storage whose contents the server mod cannot read.
 */
public final class ChestMemory {
    public static final class Item {
        public String id;
        public String name;
        public int count;
    }

    public static final class Entry {
        public String server;
        public String dim;
        public int x, y, z;
        public String block;
        public List<Item> items = new ArrayList<>();
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Map<String, Entry> MAP = new LinkedHashMap<>();
    private static final int MAX_ENTRIES = 6000;

    private static BlockPos lastTarget;
    private static int lastTargetTick;
    private static int tick;
    private static BlockPos openPos;
    private static boolean wasOpen;
    private static int openTicks;
    private static int lastHash;
    private static boolean dirty;

    private ChestMemory() {}

    public static void init() {
        load();
        ClientTickEvents.END_CLIENT_TICK.register(ChestMemory::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> {
            if (dirty) save();
        });
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("cobblemon_utility_chest_memory.json");
    }

    private static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            Entry[] arr = GSON.fromJson(Files.readString(f, StandardCharsets.UTF_8), Entry[].class);
            if (arr == null) return;
            for (Entry e : arr) if (e != null && e.server != null && e.dim != null) MAP.put(key(e.server, e.dim, new BlockPos(e.x, e.y, e.z)), e);
        } catch (Throwable t) {
            CobblemonUtilityMod.LOGGER.warn("Could not read the container memory", t);
        }
    }

    private static void save() {
        try {
            Files.writeString(file(), GSON.toJson(new ArrayList<>(MAP.values())), StandardCharsets.UTF_8);
            dirty = false;
        } catch (Throwable t) {
            CobblemonUtilityMod.LOGGER.warn("Could not save the container memory", t);
        }
    }

    private static String serverId(MinecraftClient mc) {
        return mc.getCurrentServerEntry() != null ? mc.getCurrentServerEntry().address : "singleplayer";
    }

    private static String key(String server, String dim, BlockPos p) {
        return server + "|" + dim + "|" + p.asLong();
    }

    /** True if I opened this container on this server and dimension (its content is recorded). */
    public static boolean isRemembered(BlockPos p) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return false;
        return MAP.containsKey(key(serverId(mc), mc.world.getRegistryKey().getValue().toString(), p));
    }

    public static int size() {
        return MAP.size();
    }

    public static void clearAll() {
        MAP.clear();
        save();
    }

    // ------------------------------------------------------------ recording
    private static void tick(MinecraftClient mc) {
        tick++;
        if (mc.player == null || mc.world == null) return;
        Screen s = mc.currentScreen;
        if (!(s instanceof HandledScreen<?> hs)) {
            if (wasOpen) {
                wasOpen = false;
                openPos = null;
                if (dirty) save();
            }
            HitResult h = mc.crosshairTarget;
            if (h instanceof BlockHitResult b && h.getType() == HitResult.Type.BLOCK) {
                lastTarget = b.getBlockPos();
                lastTargetTick = tick;
            }
            return;
        }
        if (!wasOpen) {
            wasOpen = true;
            openTicks = 0;
            lastHash = 0;
            openPos = lastTarget != null && tick - lastTargetTick <= 12 ? lastTarget : null;
        }
        openTicks++;
        if (openPos == null || openTicks < 3) return;
        try {
            record(mc, hs.getScreenHandler());
        } catch (Throwable t) {
            // never break the game for this
        }
    }

    private static void record(MinecraftClient mc, ScreenHandler handler) {
        Map<String, Item> agg = new HashMap<>();
        int slots = 0;
        for (Slot slot : handler.slots) {
            if (slot.inventory == mc.player.getInventory()) continue;
            if (slot.inventory instanceof RecipeInputInventory || slot.inventory instanceof CraftingResultInventory) continue;
            slots++;
            ItemStack st = slot.getStack();
            if (st.isEmpty()) continue;
            String id = Registries.ITEM.getId(st.getItem()).toString();
            Item it = agg.computeIfAbsent(id, k -> {
                Item n = new Item();
                n.id = k;
                n.name = st.getName().getString();
                return n;
            });
            it.count += st.getCount();
        }
        if (slots < 5) return; // not a storage container
        int hash = 17;
        for (Item i : agg.values()) hash = hash * 31 + i.id.hashCode() * 7 + i.count;
        hash = hash * 31 + slots;
        if (hash == lastHash) return;
        lastHash = hash;

        String dim = mc.world.getRegistryKey().getValue().toString();
        Entry e = new Entry();
        e.server = serverId(mc);
        e.dim = dim;
        e.x = openPos.getX();
        e.y = openPos.getY();
        e.z = openPos.getZ();
        e.block = mc.world.getBlockState(openPos).getBlock().getName().getString();
        e.items = new ArrayList<>(agg.values());
        MAP.put(key(e.server, dim, openPos), e);
        while (MAP.size() > MAX_ENTRIES) MAP.remove(MAP.keySet().iterator().next());
        dirty = true;
    }

    // ------------------------------------------------------------ searching
    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    /** Hits in the same format as the server mod replies. The query may hold several terms separated by commas. */
    public static List<JsonObject> search(String query) {
        List<JsonObject> out = new ArrayList<>();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || query == null) return out;
        List<String> qs = new ArrayList<>();
        List<String> exacts = new ArrayList<>();
        for (String part : query.split("[,;|]")) {
            String t = part.trim();
            if (norm(t).length() < 2 || qs.size() >= 200) continue;
            qs.add(norm(t));
            exacts.add(t.indexOf(':') > 0 ? t.toLowerCase(Locale.ROOT) : null);
        }
        if (qs.isEmpty()) return out;
        String server = serverId(mc);
        String dim = mc.world.getRegistryKey().getValue().toString();
        for (Entry e : MAP.values()) {
            if (!e.server.equals(server) || !e.dim.equals(dim)) continue;
            int[] counts = new int[qs.size()];
            String[] names = new String[qs.size()];
            for (Item it : e.items) {
                for (int k = 0; k < qs.size(); k++) {
                    String q = qs.get(k), exact = exacts.get(k);
                    boolean ok = exact != null ? (it.id.equals(exact) || norm(it.id).equals(q))
                            : (norm(it.id).contains(q) || norm(it.name).contains(q));
                    if (ok) {
                        counts[k] += it.count;
                        if (names[k] == null) names[k] = it.name;
                    }
                }
            }
            int count = 0;
            StringBuilder label = new StringBuilder();
            for (int k = 0; k < counts.length; k++) {
                if (counts[k] <= 0) continue;
                count += counts[k];
                if (label.length() > 0) label.append(", ");
                label.append(counts[k]).append("x ").append(names[k]);
            }
            if (count == 0) continue;
            JsonObject h = new JsonObject();
            h.addProperty("x", e.x);
            h.addProperty("y", e.y);
            h.addProperty("z", e.z);
            h.addProperty("dist", (int) Math.sqrt(mc.player.squaredDistanceTo(e.x + 0.5, e.y + 0.5, e.z + 0.5)));
            h.addProperty("block", e.block == null ? "Container" : e.block);
            h.addProperty("item", label.toString());
            h.addProperty("label", label.toString());
            h.addProperty("count", count);
            h.addProperty("mem", true);
            out.add(h);
        }
        out.sort(Comparator.comparingInt(a -> a.get("dist").getAsInt()));
        return out;
    }

    /** Adds remembered containers to a server reply (the server's own hits win on the same position). */
    public static void mergeInto(JsonObject reply, String query) {
        JsonArray arr = reply.has("hits") ? reply.getAsJsonArray("hits") : new JsonArray();
        Map<Long, Boolean> have = new HashMap<>();
        // A chest I already opened: my recorded content wins over the server's preview or estimate.
        JsonArray kept = new JsonArray();
        for (var el : arr) {
            JsonObject h = el.getAsJsonObject();
            if ((h.has("preview") || (h.has("chance") && h.has("count") && h.get("count").getAsInt() == 0))
                    && isRemembered(new BlockPos(h.get("x").getAsInt(), h.get("y").getAsInt(), h.get("z").getAsInt()))) continue;
            if (h.has("count") && h.get("count").getAsInt() <= 0) continue; // estimates ("possible") are not shown
            kept.add(h);
        }
        arr = kept;
        for (var el : arr) {
            JsonObject h = el.getAsJsonObject();
            have.put(new BlockPos(h.get("x").getAsInt(), h.get("y").getAsInt(), h.get("z").getAsInt()).asLong(), true);
        }
        int added = 0;
        for (JsonObject h : search(query)) {
            long k = new BlockPos(h.get("x").getAsInt(), h.get("y").getAsInt(), h.get("z").getAsInt()).asLong();
            if (have.put(k, true) == null) {
                arr.add(h);
                added++;
            }
        }
        List<JsonObject> sorted = new ArrayList<>();
        for (var el : arr) sorted.add(el.getAsJsonObject());
        sorted.sort((a, b) -> {
            boolean pa = a.has("chance"), pb = b.has("chance");
            if (pa != pb) return pa ? 1 : -1;
            if (pa && Math.abs(a.get("chance").getAsDouble() - b.get("chance").getAsDouble()) > 0.05)
                return Double.compare(b.get("chance").getAsDouble(), a.get("chance").getAsDouble());
            return Integer.compare(a.get("dist").getAsInt(), b.get("dist").getAsInt());
        });
        JsonArray outArr = new JsonArray();
        for (JsonObject h : sorted) outArr.add(h);
        reply.add("hits", outArr);
        int total = reply.has("total") ? reply.get("total").getAsInt() : 0;
        reply.addProperty("total", outArr.size());
        if (!reply.has("radius")) reply.addProperty("radius", 512);
    }
}
