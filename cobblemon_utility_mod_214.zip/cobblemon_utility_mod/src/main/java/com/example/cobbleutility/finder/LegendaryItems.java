package com.example.cobbleutility.finder;

import com.example.cobbleutility.CobblemonUtilityMod;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Every item that summons a legendary / mythical Pokémon in Cobblemon Academy, found in whatever mods are loaded.
 * The list below holds the English and French display names; an item matches when its id (without the mod prefix) or its
 * display name, with spaces and punctuation ignored, equals one of them. Items of the "minecraft" namespace are skipped.
 */
public final class LegendaryItems {
    /** "English name|French name" */
    private static final String[] NAMES = {
            "Time Core|Noyau Temporel", "Wishing Star|Étoile Souhait", "Meteorite|Météorite", "Rare Sea Egg|Œuf Marin Rare",
            "Nightmare Core|Noyau Cauchemar", "Gracidea|Gracidéa", "Jewel of Life|Joyau de la Vie", "Victory Star|Étoile Victoire",
            "Resolute Star|Étoile Résolue", "Relic Disc|Disque Relique", "Disc Drive|Module Choc", "Pink Diamond|Diamant Rose",
            "Ring|Anneau", "Steam Engine|Moteur à Vapeur", "Soul Heart|Cœur Âme", "Z Soul|Âme Z", "Meltan Nut|Écrou de Meltan",
            "Dada Scarf|Écharpe Dada", "Mythical Pecha Berry|Baie Pecha Mythique", "Glacial Orb|Orbe Glaciaire",
            "Static Orb|Orbe Statique", "Flare Orb|Orbe Ardente", "Cloning Cable|Câble de Clonage", "Sacred Lightning|Foudre Sacrée",
            "Sacred Flame|Flamme Sacrée", "Sacred Droplet|Goutte Sacrée", "Silver Wing|Aile Argentée", "Rainbow Wing|Aile Arc-en-Ciel",
            "Steel Alloy|Alliage d'Acier", "Never Melt Icicle|Glaçon Éternel", "Ancient Ingot|Lingot Ancien",
            "Infinite Source|Source Infinie", "Dragon Skull|Crâne de Dragon", "Titan Totem|Totem Titan",
            "Blue Eon Ticket|Ticket Éon Bleu", "Red Eon Ticket|Ticket Éon Rouge", "Blue Orb|Orbe Bleu", "Red Orb|Orbe Rouge",
            "Jade Orb|Orbe de Jade", "Ruby of Willpower|Rubis de la Volonté", "Ruby of Emotion|Rubis de l'Émotion",
            "Ruby of Knowledge|Rubis de la Connaissance", "Adamant Orb|Orbe Adamant", "Lustrous Orb|Orbe Plénitude",
            "Griseous Orb|Orbe Grise", "Magma Chunk|Bloc de Magma", "Lunar Feather|Plume Lunaire", "Cobalion Sword|Épée Cobaltium",
            "Virizion Sword|Épée Viridium", "Terrakion Sword|Épée Terrakium", "Thundurus Bottle|Bouteille Thundurus",
            "Tornadus Bottle|Bouteille Tornadus", "Landorus Bottle|Bouteille Landorus", "Enamorus Bottle|Bouteille Enamorus",
            "Light Stone|Pierre Lumière", "Dark Stone|Pierre Ténèbres", "Gray Stone|Pierre Grise", "Tree of Life|Arbre de Vie",
            "Cocoon of Destruction|Cocon de Destruction", "Zygarde Cube|Cube Zygarde", "Broken Memory|Mémoire Cassée",
            "Electric Totem|Totem Électrique", "Psychic Totem|Totem Psy", "Grass Totem|Totem Plante", "Water Totem|Totem Eau",
            "Solar Core|Noyau Solaire", "Lunar Core|Noyau Lunaire", "Eclipse Core|Noyau Éclipse", "Rusted Sword|Épée Rouillée",
            "Rusted Shield|Bouclier Rouillé", "Dynamax Core|Noyau Dynamax", "Scroll of Darkness|Parchemin des Ténèbres",
            "Scroll of Waters|Parchemin des Eaux", "Mystical Branch|Branche Mystique", "Frozen Hoof|Sabot Gelé",
            "Ghostly Hoof|Sabot Fantomatique", "Koraidon Key|Clé Koraidon", "Miraidon Key|Clé Miraidon",
            "Toxic Scarf|Écharpe Toxique", "Toxic Headband|Bandeau Toxique", "Toxic Ribbon|Ruban Toxique",
            "Teal Mask|Masque Sarcelle", "Stellar Tera Core|Noyau Téra Stellaire", "Psychic Orb|Orbe Psy", "Combat Orb|Orbe Combat",
            "Dark Orb|Orbe Ténébreuse", "Ruinous Sword|Épée Ruineuse", "Ruinous Beads|Perles Ruineuses",
            "Ruinous Tablet|Tablette Ruineuse", "Ruinous Vessel|Vase Ruineux", "Zeraora Tuft|Touffe Zeraora"
    };

    public record Result(List<String> ids, List<String> notFound) {}

    private LegendaryItems() {}

    private static String norm(String s) {
        if (s == null) return "";
        String t = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return t.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    public static Result resolve() {
        Set<String> wanted = new HashSet<>();
        for (String pair : NAMES) for (String n : pair.split("\\|")) wanted.add(norm(n));
        Set<String> foundNames = new HashSet<>();
        List<String> ids = new ArrayList<>();
        for (Item item : Registries.ITEM) {
            Identifier id = Registries.ITEM.getId(item);
            if (id.getNamespace().equals("minecraft")) continue;
            String byId = norm(id.getPath());
            String byName = norm(item.getName().getString());
            String hit = wanted.contains(byId) ? byId : (wanted.contains(byName) ? byName : null);
            if (hit != null) {
                ids.add(id.toString());
                foundNames.add(hit);
            }
        }
        List<String> missing = new ArrayList<>();
        for (String pair : NAMES) {
            String[] p = pair.split("\\|");
            if (!foundNames.contains(norm(p[0])) && !foundNames.contains(norm(p[1]))) missing.add(p[0]);
        }
        CobblemonUtilityMod.LOGGER.info("Legendary-summon items found ({}): {}", ids.size(), ids);
        CobblemonUtilityMod.LOGGER.info("Legendary-summon items NOT found in this game ({}): {}", missing.size(), missing);
        return new Result(ids, missing);
    }
}
