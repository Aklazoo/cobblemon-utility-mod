package com.example.cobbleutility.util;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

/**
 * Stream-safe switch. When active, everything the mod draws (overlays, HUD, highlights) and every chat /
 * action-bar message and sound it would produce is suppressed, so nothing shows in a Discord / OBS capture.
 * Runtime only: it always starts OFF. Screens opened on purpose (settings, finders) are still visible.
 */
public final class StreamMode {
    private static boolean active;

    private StreamMode() {}

    public static boolean active() {
        return active;
    }

    public static void toggle() {
        active = !active;
    }

    /** Drop-in replacement for player.sendMessage that stays silent in stream mode. */
    public static void say(PlayerEntity p, Text text, boolean overlay) {
        if (!active && p != null) p.sendMessage(text, overlay);
    }
}
