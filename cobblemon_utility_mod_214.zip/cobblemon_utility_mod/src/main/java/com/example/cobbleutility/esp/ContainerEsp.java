package com.example.cobbleutility.esp;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.render.RenderUtil;
import com.example.cobbleutility.util.ColorUtil;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.block.AbstractChestBlock;
import net.minecraft.block.BarrelBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.CrafterBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.LootableContainerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Scans loaded chunks once per second; per frame we only draw the cached list.
 * Detects vanilla containers, modded loot containers, user-listed block ids, and optional
 * "points of interest" (any block entity matching the POI list, e.g. cobblemon:*).
 */
public final class ContainerEsp {
    public enum Kind { CHEST, TRAPPED, BARREL, SHULKER, MODDED, POI }

    private record Entry(Box box, OpenedContainers.State state, Kind kind) {}

    /** Comma separated block-id patterns, parsed only when the raw string changes. */
    private static final class Patterns {
        private String raw = null;
        private List<String> list = List.of();

        void update(String value) {
            String v = value == null ? "" : value;
            if (v.equals(raw)) return;
            List<String> out = new ArrayList<>();
            for (String part : v.split("[,;\\n]")) {
                String p = part.trim().toLowerCase(Locale.ROOT);
                if (!p.isEmpty()) out.add(p);
            }
            list = out;
            raw = v;
        }

        boolean isEmpty() {
            return list.isEmpty();
        }

        boolean matches(Identifier id) {
            String full = id.toString();
            for (String p : list) {
                if (p.endsWith("*")) {
                    if (full.startsWith(p.substring(0, p.length() - 1))) return true;
                } else if (p.indexOf(':') >= 0) {
                    if (full.equals(p)) return true;
                } else if (id.getNamespace().equals(p)) {
                    return true; // bare "modid"
                }
            }
            return false;
        }
    }

    private static final Patterns EXTRA = new Patterns();
    private static final Patterns POI = new Patterns();
    private static final Patterns IGNORE = new Patterns();

    private static final String[] NAME_KEYS = {"chest", "barrel", "crate", "shulker", "locker", "strongbox",
            "coffer", "trunk", "storage", "cabinet", "treasure", "loot"};
    private static final String[] NAME_EXCLUDE = {"craft", "table", "workbench", "furnace", "smelter", "smoker",
            "blast", "oven", "kiln", "stove", "anvil", "brew", "enchant", "hopper", "dispenser", "dropper",
            "press", "grinder", "generator", "machine", "healer", "jukebox", "mailbox"};
    private static final int MAX_ENTRIES = 4000;

    private static volatile List<Entry> entries = List.of();
    private static int tick;

    private ContainerEsp() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(ContainerEsp::onTick);
    }

    public static void rescanSoon() {
        tick = 19; // next tick hits the % 20 boundary
    }

    public static boolean isContainer(Kind k) {
        return k != null && k != Kind.POI;
    }

    // ------------------------------------------------------------ classification
    public static Kind kindOf(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) return Kind.TRAPPED;
        if (be instanceof ChestBlockEntity) return Kind.CHEST;
        if (be instanceof BarrelBlockEntity) return Kind.BARREL;
        if (be instanceof ShulkerBoxBlockEntity) return Kind.SHULKER;

        ModConfig cfg = ConfigManager.get();
        Identifier id = null;

        if (cfg.poiEnabled) {
            POI.update(cfg.poiBlocks);
            if (!POI.isEmpty()) {
                id = Registries.BLOCK.getId(be.getCachedState().getBlock());
                if (POI.matches(id)) return Kind.POI;
            }
        }

        if (id == null) id = Registries.BLOCK.getId(be.getCachedState().getBlock());

        IGNORE.update(cfg.chestIgnoreBlocks);
        if (!IGNORE.isEmpty() && IGNORE.matches(id)) return null;

        EXTRA.update(cfg.chestExtraBlocks);
        if (!EXTRA.isEmpty() && EXTRA.matches(id)) return Kind.MODDED;

        if (cfg.chestSmartDetect) {
            Block block = be.getCachedState().getBlock();
            String path = id.getPath();
            boolean excluded = false;
            for (String x : NAME_EXCLUDE) if (path.contains(x)) { excluded = true; break; }
            if (!excluded) {
                if (block instanceof AbstractChestBlock<?> || block instanceof BarrelBlock
                        || block instanceof ShulkerBoxBlock) return Kind.MODDED;
                for (String key : NAME_KEYS) if (path.contains(key)) return Kind.MODDED;
            }
        }

        if (cfg.chestDetectAnyInventory) {
            boolean notAStorage = be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity
                    || be instanceof CrafterBlockEntity;
            if (!notAStorage && be instanceof LootableContainerBlockEntity) return Kind.MODDED;
        }
        return null;
    }

    private static boolean enabled(ModConfig c, Kind k) {
        return switch (k) {
            case CHEST -> c.chestEspChests;
            case TRAPPED -> c.chestEspTrappedChests;
            case BARREL -> c.chestEspBarrels;
            case SHULKER -> c.chestEspShulkers;
            case MODDED -> c.chestEspModded;
            case POI -> c.poiEnabled;
        };
    }

    private static int colorOf(ModConfig c, Entry e) {
        if (e.kind() == Kind.POI) return c.poiColor;
        switch (e.state()) {
            case EMPTY:
                return c.chestLootedColor;
            case PARTIAL:
                return c.chestColorPartial;
            default:
                break;
        }
        if (!c.chestUsePerTypeColors) return c.chestUnlootedColor;
        return switch (e.kind()) {
            case CHEST -> c.chestColorChest;
            case TRAPPED -> c.chestColorTrapped;
            case BARREL -> c.chestColorBarrel;
            case SHULKER -> c.chestColorShulker;
            default -> c.chestColorModded;
        };
    }

    private static OpenedContainers.State merge(OpenedContainers.State a, OpenedContainers.State b) {
        if (a == OpenedContainers.State.PARTIAL || b == OpenedContainers.State.PARTIAL) return OpenedContainers.State.PARTIAL;
        if (a == OpenedContainers.State.EMPTY || b == OpenedContainers.State.EMPTY) return OpenedContainers.State.EMPTY;
        return OpenedContainers.State.UNOPENED;
    }

    // ------------------------------------------------------------ scan
    private static void onTick(MinecraftClient mc) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.chestEspEnabled || mc.world == null || mc.player == null) {
            if (!entries.isEmpty()) entries = List.of();
            return;
        }
        if (++tick % 20 != 0) return;

        ClientWorld w = mc.world;
        Identifier dim = w.getRegistryKey().getValue();
        double r = cfg.chestMaxRadius;
        double rSq = r * r;
        double nearSq = (double) cfg.chestHideNearDistance * cfg.chestHideNearDistance;
        Vec3d pp = mc.player.getPos();
        int cr = (int) (r / 16) + 1;
        ChunkPos pc = mc.player.getChunkPos();
        List<Entry> out = new ArrayList<>();

        outer:
        for (int dx = -cr; dx <= cr; dx++) {
            for (int dz = -cr; dz <= cr; dz++) {
                // skip chunks entirely outside the radius (corner chunks of the square)
                double cx = (pc.x + dx) * 16 + 8 - pp.x, cz = (pc.z + dz) * 16 + 8 - pp.z;
                double reach = r + 12;
                if (cx * cx + cz * cz > reach * reach) continue;

                WorldChunk chunk = w.getChunkManager().getWorldChunk(pc.x + dx, pc.z + dz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    Kind k = kindOf(be);
                    if (k == null || !enabled(cfg, k)) continue;
                    BlockPos pos = be.getPos();
                    double d2 = pos.getSquaredDistance(pp);
                    if (d2 > rSq) continue;
                    if (cfg.chestHideNearDistance > 0 && d2 < nearSq) continue;

                    BlockState st = be.getCachedState();
                    OpenedContainers.State state = k == Kind.POI
                            ? OpenedContainers.State.UNOPENED
                            : OpenedContainers.stateOf(dim, pos.asLong());
                    Box box = shapeBox(w, pos, st);

                    if (k != Kind.POI && st.contains(ChestBlock.CHEST_TYPE)
                            && st.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
                        if (st.get(ChestBlock.CHEST_TYPE) == ChestType.RIGHT) continue; // drawn from the LEFT half
                        BlockPos other = pos.offset(ChestBlock.getFacing(st));
                        box = box.union(shapeBox(w, other, w.getBlockState(other)));
                        state = merge(state, OpenedContainers.stateOf(dim, other.asLong()));
                    }
                    if (state == OpenedContainers.State.EMPTY && cfg.chestHideLooted) continue;
                    out.add(new Entry(box.expand(0.002), state, k));
                    if (out.size() >= MAX_ENTRIES) break outer;
                }
            }
        }
        entries = out;
    }

    private static Box shapeBox(ClientWorld w, BlockPos pos, BlockState st) {
        try {
            VoxelShape shape = st.getOutlineShape(w, pos);
            if (!shape.isEmpty()) return shape.getBoundingBox().offset(pos);
        } catch (Throwable ignored) {
        }
        return new Box(pos);
    }

    // ------------------------------------------------------------ inspector
    /** Key action: tells what the looked-at block is. With shift, adds / removes it from the lists. */
    public static void inspect(MinecraftClient mc, boolean shift) {
        if (mc.world == null || mc.player == null) return;
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal("§cLook at a block first."), true);
            return;
        }
        BlockPos pos = hit.getBlockPos();
        BlockState st = mc.world.getBlockState(pos);
        Identifier id = Registries.BLOCK.getId(st.getBlock());
        BlockEntity be = mc.world.getBlockEntity(pos);
        ModConfig cfg = ConfigManager.get();
        String idStr = id.toString();

        if (be == null) {
            com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal("§e[Inspect] §f" + idStr
                    + " §7- no block entity, it can never be highlighted."), false);
            return;
        }
        Kind k = kindOf(be);
        String state = k == null ? "§cNOT detected" : "§adetected as " + k;
        com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal("§e[Inspect] §f" + idStr + " §7| " + be.getClass().getSimpleName()
                + " | " + state), false);
        if (!shift) {
            com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal("§7Shift + this key: " + (k == null
                    ? "add it to the extra containers list" : "add it to the ignore list")), true);
            return;
        }
        IGNORE.update(cfg.chestIgnoreBlocks);
        if (!IGNORE.isEmpty() && IGNORE.matches(id)) {
            cfg.chestIgnoreBlocks = removeEntry(cfg.chestIgnoreBlocks, idStr);
            cfg.chestExtraBlocks = addEntry(cfg.chestExtraBlocks, idStr);
            com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal("§aRemoved from ignore list, added to containers: " + idStr), false);
        } else if (k != null && k != Kind.POI) {
            cfg.chestIgnoreBlocks = addEntry(cfg.chestIgnoreBlocks, idStr);
            cfg.chestExtraBlocks = removeEntry(cfg.chestExtraBlocks, idStr);
            com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal("§cNow ignored: " + idStr), false);
        } else {
            cfg.chestExtraBlocks = addEntry(cfg.chestExtraBlocks, idStr);
            com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal("§aNow highlighted: " + idStr), false);
        }
        ConfigManager.save();
        rescanSoon();
    }

    private static String addEntry(String list, String entry) {
        for (String p : list.split("[,;\\n]")) if (p.trim().equalsIgnoreCase(entry)) return list;
        return list.isBlank() ? entry : list.trim() + ", " + entry;
    }

    private static String removeEntry(String list, String entry) {
        List<String> keep = new ArrayList<>();
        for (String p : list.split("[,;\\n]")) {
            String t = p.trim();
            if (!t.isEmpty() && !t.equalsIgnoreCase(entry)) keep.add(t);
        }
        return String.join(", ", keep);
    }

    // ------------------------------------------------------------ render
    public static void render(MatrixStack ms, Vec3d cam, Camera camera) {
        ModConfig cfg = ConfigManager.get();
        List<Entry> list = entries;
        if (!cfg.chestEspEnabled || list.isEmpty()) return;
        if (cfg.chestFilterHideOthers && com.example.cobbleutility.finder.ChestFilter.active()) {
            List<Entry> only = new ArrayList<>();
            for (Entry e : list) if (com.example.cobbleutility.finder.ChestFilter.matches(e.box())) only.add(e);
            list = only;
            if (list.isEmpty()) return;
        }
        boolean through = cfg.chestThroughWalls;

        int alpha = Math.round(cfg.chestBoxOpacity * 255f);
        if (alpha > 2) {
            Matrix4f m = ms.peek().getPositionMatrix();
            BufferBuilder f = RenderUtil.beginFill(through);
            for (Entry e : list) {
                RenderUtil.boxFill(f, m, e.box(), cam.x, cam.y, cam.z, ColorUtil.argb(colorOf(cfg, e), alpha));
            }
            RenderUtil.end(f);
        }

        MatrixStack.Entry entry = ms.peek();
        Vec3d look = Vec3d.fromPolar(camera.getPitch(), camera.getYaw()).multiply(0.4);
        BufferBuilder l = RenderUtil.beginLines(cfg.chestLineThickness, through);
        for (Entry e : list) {
            int argb = ColorUtil.opaque(colorOf(cfg, e));
            RenderUtil.boxOutline(l, entry, e.box(), cam.x, cam.y, cam.z, argb);
            if (cfg.chestTracers) {
                Box b = e.box();
                RenderUtil.line(l, entry, look.x, look.y, look.z,
                        (b.minX + b.maxX) / 2 - cam.x, (b.minY + b.maxY) / 2 - cam.y, (b.minZ + b.maxZ) / 2 - cam.z, argb);
            }
        }
        RenderUtil.end(l);
    }
}
