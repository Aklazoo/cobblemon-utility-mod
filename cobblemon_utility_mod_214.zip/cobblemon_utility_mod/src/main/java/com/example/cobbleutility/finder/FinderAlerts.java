package com.example.cobbleutility.finder;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.net.ServerLink;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.HashSet;
import java.util.Set;

/**
 * Asks the server mod every so often for the best Pokémon around you and tells you in chat when a new
 * shiny / legendary / hidden ability / high-IV Pokémon shows up. No click needed.
 */
public final class FinderAlerts {
    private static int ticks;
    private static boolean pending;
    private static Set<String> known = new HashSet<>();

    private FinderAlerts() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(FinderAlerts::tick);
    }

    public static void reset() {
        known = new HashSet<>();
        pending = false;
    }

    private static void tick(MinecraftClient mc) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.finderAlertsEnabled || mc.player == null || mc.world == null) return;
        if (++ticks < Math.max(30, cfg.finderAlertIntervalSeconds) * 20) return;
        if (mc.currentScreen != null || ServerLink.waitingFind() || !ServerLink.available()) return;
        ticks = 0;
        pending = ServerLink.requestFind("all", true);
    }

    public static void onResult(JsonObject o) {
        if (!pending) return;
        pending = false;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !o.has("hits")) return;
        Set<String> now = new HashSet<>();
        boolean sound = false;
        for (JsonElement el : o.getAsJsonArray("hits")) {
            JsonObject h = el.getAsJsonObject();
            String iv = h.has("iv") ? h.get("iv").getAsString() : (h.has("perfect") ? h.get("perfect").getAsString() : "");
            String sig = h.get("name").getAsString() + "|" + h.get("level").getAsInt() + "|" + iv + "|" + h.get("shiny").getAsBoolean();
            ModConfig wc = ConfigManager.get();
            int perfect = h.has("perfect") ? h.get("perfect").getAsInt() : 0;
            boolean wanted = (h.get("shiny").getAsBoolean() && wc.finderAlertShiny)
                    || (h.get("legendary").getAsBoolean() && wc.finderAlertLegendary)
                    || (h.get("ha").getAsBoolean() && wc.finderAlertHiddenAbility)
                    || perfect >= wc.finderAlertMinPerfectIvs;
            if (!wanted) continue;
            now.add(sig);
            if (known.contains(sig)) continue;
            StringBuilder sb = new StringBuilder("§6[Finder] §f");
            if (h.get("shiny").getAsBoolean()) sb.append("§e★ Shiny ");
            sb.append("§f").append(h.get("name").getAsString()).append(" Lv").append(h.get("level").getAsInt());
            if (h.get("legendary").getAsBoolean()) sb.append(" §c[Legendary]");
            if (h.get("ha").getAsBoolean()) sb.append(" §d[HA]");
            if (h.has("iv")) sb.append(" §b").append(h.get("iv").getAsString());
            else if (h.has("perfect")) sb.append(" §b").append(h.get("perfect").getAsInt()).append("x31");
            sb.append(" §7").append(h.get("dist").getAsInt()).append("m ").append(h.has("dir") ? h.get("dir").getAsString() : "");
            if (h.has("x")) {
                sb.append(" §f").append(h.get("x").getAsInt()).append(", ");
                if (h.has("y")) sb.append(h.get("y").getAsInt()).append(", ");
                sb.append(h.get("z").getAsInt());
            }
            ModConfig c2 = ConfigManager.get();
            if (c2.hudToasts) {
                String title = (h.get("shiny").getAsBoolean() ? "★ Shiny " : "") + h.get("name").getAsString()
                        + " Lv" + h.get("level").getAsInt();
                StringBuilder body = new StringBuilder();
                if (h.get("legendary").getAsBoolean()) body.append("Legendary  ");
                if (h.get("ha").getAsBoolean()) body.append("Hidden ability  ");
                if (h.has("iv")) body.append(h.get("iv").getAsString()).append("  ");
                else if (h.has("perfect")) body.append(h.get("perfect").getAsInt()).append("x31  ");
                body.append(h.get("dist").getAsInt()).append("m ").append(h.has("dir") ? h.get("dir").getAsString() : "");
                if (h.has("x")) body.append("  ").append(h.get("x").getAsInt()).append(", ").append(h.get("z").getAsInt());
                int rgb = h.get("shiny").getAsBoolean() ? c2.radarShinyColor : h.get("legendary").getAsBoolean()
                        ? c2.radarLegendaryColor : h.get("ha").getAsBoolean() ? c2.radarHiddenAbilityColor : c2.radarHighIvColor;
                com.example.cobbleutility.render.Toasts.push(title, body.toString(), rgb & 0xFFFFFF);
            } else {
                com.example.cobbleutility.util.StreamMode.say(mc.player, Text.literal(sb.toString()), false);
            }
            sound = true;
        }
        known = now; // anything that disappears and comes back is announced again
        if (sound && ConfigManager.get().finderAlertSound && !com.example.cobbleutility.util.StreamMode.active()) {
            mc.player.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 0.6f, 1.4f);
        }
    }
}
