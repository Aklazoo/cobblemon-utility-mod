package com.example.shinycontrol;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * The only entry point for the "find" features: packets from the Cobblemon Utility client mod.
 * No chat command exists, so typing something in chat does nothing.
 */
public final class ServerNet {
    private static final Map<UUID, Long> LAST_FIND = new HashMap<>();
    private static final Map<UUID, Long> LAST_STRUCT = new HashMap<>();
    private static final Map<UUID, Long> LAST_CHEST = new HashMap<>();

    private ServerNet() {}

    public static void init() {
        // Both this mod and the client mod register the same payload types; when they share a JVM
        // (singleplayer) the second registration throws, which is harmless.
        try {
            PayloadTypeRegistry.playC2S().register(RequestPayload.ID, RequestPayload.CODEC);
        } catch (Throwable ignored) {
        }
        try {
            PayloadTypeRegistry.playS2C().register(ReplyPayload.ID, ReplyPayload.CODEC);
        } catch (Throwable ignored) {
        }
        ServerPlayNetworking.registerGlobalReceiver(RequestPayload.ID, (payload, context) -> {
            try {
                handle(context.player(), payload.json());
            } catch (Throwable t) {
                ShinyControlMod.LOGGER.warn("Failed to handle a client request", t);
            }
        });
    }

    static void reply(ServerPlayerEntity player, JsonObject o) {
        ServerPlayNetworking.send(player, new ReplyPayload(o.toString()));
    }

    static void error(ServerPlayerEntity player, String msg) {
        JsonObject o = new JsonObject();
        o.addProperty("t", "error");
        o.addProperty("msg", msg);
        reply(player, o);
    }

    private static boolean allowed(ServerPlayerEntity player) {
        java.util.List<String> list = ControlConfig.get().allowedPlayers;
        if (list == null || list.isEmpty()) return true;
        String name = player.getName().getString().toLowerCase(Locale.ROOT);
        for (String s : list) if (s != null && s.trim().toLowerCase(Locale.ROOT).equals(name)) return true;
        return false;
    }

    private static boolean isOp(ServerPlayerEntity player) {
        return player.getCommandSource().hasPermissionLevel(2);
    }

    /** Returns the seconds left, or 0 if the player may proceed (and records the use). */
    private static long cooldown(Map<UUID, Long> map, ServerPlayerEntity player, int seconds) {
        if (seconds <= 0 || isOp(player)) return 0;
        long now = System.currentTimeMillis();
        Long last = map.get(player.getUuid());
        if (last != null && now - last < seconds * 1000L) {
            return (seconds * 1000L - (now - last) + 999) / 1000;
        }
        map.put(player.getUuid(), now);
        return 0;
    }

    private static void handle(ServerPlayerEntity player, String raw) {
        JsonObject o = JsonParser.parseString(raw).getAsJsonObject();
        String t = o.has("t") ? o.get("t").getAsString() : "";
        ControlConfig cfg = ControlConfig.get();

        if (!allowed(player)) {
            error(player, "You are not allowed to use this feature on this server.");
            return;
        }

        switch (t) {
            case "structures" -> {
                if (!cfg.structuresEnabled) {
                    error(player, "The structure finder is disabled on this server.");
                    return;
                }
                reply(player, StructureService.list(player));
            }
            case "locate" -> {
                if (!cfg.structuresEnabled) {
                    error(player, "The structure finder is disabled on this server.");
                    return;
                }
                long left = cooldown(LAST_STRUCT, player, cfg.structureCooldownSeconds);
                if (left > 0) {
                    error(player, "Wait " + left + "s before searching for another structure.");
                    return;
                }
                String q = o.has("q") ? o.get("q").getAsString() : "";
                reply(player, StructureService.locate(player, q));
            }
            case "chests" -> {
                if (!cfg.chestsEnabled) {
                    error(player, "The container finder is disabled on this server.");
                    return;
                }
                long left = cooldown(LAST_CHEST, player, cfg.chestCooldownSeconds);
                if (left > 0) {
                    error(player, "Wait " + left + "s before searching again.");
                    return;
                }
                String q = o.has("q") ? o.get("q").getAsString() : "";
                reply(player, ChestService.find(player, q));
            }
            case "find" -> {
                if (!cfg.findEnabled) {
                    error(player, "The Pokémon finder is disabled on this server.");
                    return;
                }
                long left = cooldown(LAST_FIND, player, cfg.findCooldownSeconds);
                if (left > 0) {
                    error(player, "Wait " + left + "s before searching again.");
                    return;
                }
                String filter = o.has("filter") ? o.get("filter").getAsString() : "all";
                reply(player, FindService.find(player, filter));
            }
            default -> error(player, "Unknown request.");
        }
    }
}
