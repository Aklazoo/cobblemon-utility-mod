# Cobblemon Utility Mod (Fabric 1.21.1) — itemless, client-side

Features (all configurable in-game, JSON at `config/cobblemon_utility_mod.json`):
- Cobblemon radar: shiny / legendary-mythical / hidden ability / perfect IVs, tracers, 3D boxes, HUD waypoints
- Chest ESP: chests, trapped chests, barrels, shulkers; unopened vs opened colors; radius, thickness, opacity
- Structure finder: pick a structure, get a path line + beam + HUD icon, or a simple compass

Keys (default): O settings, K structure finder, C toggle chest ESP, R toggle radar (all rebindable in the settings GUI).
Note: Cobblemon also uses R by default -> rebind one of them.

## Required mods in your mods/ folder
Fabric Loader >= 0.16, Fabric API (1.21.1), YetAnotherConfigLib 3.6.x (1.21 / Fabric), Cobblemon 1.6.x (1.21.1).
Optional: Mod Menu.

## Build the .jar
Option A - locally: install JDK 21 + Gradle 8.10, then in this folder run:  gradle build
           The jar is in build/libs/cobblemon_utility_mod-1.0.0.jar
Option B - no install: push this folder to a GitHub repo; the "build" workflow in
           .github/workflows builds it; download the jar from Actions -> Artifacts.

## Limits (by design of Minecraft/Cobblemon, not the mod)
- IVs / hidden ability of wild Pokémon are only known to the client in singleplayer (reads the integrated server).
  On a remote server only shiny and legendary/mythical detection works.
- The client cannot see loot tables: "looted" = containers you opened yourself (saved per world/server).
- Structure finder: singleplayer works without cheats; on a server it sends /locate (needs permission).
- ESP/radar are unfair advantages on most multiplayer servers: use them only where allowed.
