package com.example.cobbleutility.radar;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.config.RenderStyle;
import com.example.cobbleutility.render.RenderUtil;
import com.example.cobbleutility.util.ColorUtil;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Scans every 10 ticks (cheap), renders every frame from the cached list. */
public final class RadarManager {
    public record Target(Entity entity, int rgb, String label) {}

    private static volatile List<Target> targets = List.of();
    private static final Set<UUID> alerted = new HashSet<>();
    private static int tick;

    private RadarManager() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(RadarManager::onTick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            targets = List.of();
            alerted.clear();
        });
    }

    // ------------------------------------------------------------ scanning
    private static void onTick(MinecraftClient mc) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.radarEnabled || mc.world == null || mc.player == null) {
            if (!targets.isEmpty()) targets = List.of();
            return;
        }
        if (++tick % 10 != 0) return;

        double maxSq = (double) cfg.radarMaxDistance * cfg.radarMaxDistance;
        List<Target> out = new ArrayList<>();

        for (Entity e : mc.world.getEntities()) {
            if (e.isRemoved() || !CobblemonBridge.isPokemon(e)) continue;
            if (e.squaredDistanceTo(mc.player) > maxSq) continue;

            CobblemonBridge.Info info = CobblemonBridge.inspect(e, mc);
            if (info == null) continue;
            if (cfg.radarIgnoreOwned && info.owned()) continue;

            int rgb;
            String tag;
            if (cfg.radarShiny && info.shiny()) {
                rgb = cfg.radarShinyColor;
                tag = "★ Shiny " + info.name();
            } else if (cfg.radarLegendary && info.legendary()) {
                rgb = cfg.radarLegendaryColor;
                tag = "♛ " + info.name();
            } else if (cfg.radarHiddenAbility && info.hiddenAbility()) {
                rgb = cfg.radarHiddenAbilityColor;
                tag = "✦ HA " + info.name();
            } else if (cfg.radarHighIv && info.ivKnown() && info.perfectIvs() >= cfg.radarMinPerfectIvStats) {
                rgb = cfg.radarHighIvColor;
                tag = "◆ " + info.name() + " (" + info.perfectIvs() + "×31)";
            } else {
                continue;
            }

            out.add(new Target(e, rgb, tag));
            if (alerted.add(e.getUuid())) alert(mc, cfg, tag, mc.player.distanceTo(e));
        }
        if (alerted.size() > 1024) alerted.clear();
        targets = out;
    }

    private static void alert(MinecraftClient mc, ModConfig cfg, String label, float dist) {
        if (cfg.radarChatAlert && mc.player != null) {
            mc.player.sendMessage(Text.literal("§e[Radar] §f" + label + " §7(" + (int) dist + "m)"), true);
        }
        if (cfg.radarSoundAlert && mc.player != null) {
            mc.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.4f);
        }
    }

    // ------------------------------------------------------------ 3D rendering (tracers + boxes)
    public static void renderWorld(MatrixStack ms, Vec3d cam, float td, Camera camera) {
        ModConfig cfg = ConfigManager.get();
        List<Target> list = targets;
        if (!cfg.radarEnabled || list.isEmpty()) return;
        RenderStyle style = cfg.radarRenderStyle;
        boolean tracers = style == RenderStyle.TRACERS || style == RenderStyle.ALL;
        boolean boxes = style == RenderStyle.BOXES || style == RenderStyle.ALL;
        if (!tracers && !boxes) return;

        Vec3d look = Vec3d.fromPolar(camera.getPitch(), camera.getYaw()).multiply(0.4);
        MatrixStack.Entry entry = ms.peek();
        BufferBuilder b = RenderUtil.beginLines(cfg.radarLineThickness);

        for (Target t : list) {
            Entity e = t.entity();
            if (e.isRemoved()) continue;
            int argb = ColorUtil.opaque(t.rgb());
            Vec3d p = e.getLerpedPos(td);
            Box box = e.getBoundingBox()
                    .offset(p.x - e.getX(), p.y - e.getY(), p.z - e.getZ())
                    .offset(-cam.x, -cam.y, -cam.z);
            if (boxes) RenderUtil.boxOutline(b, entry, box, argb);
            if (tracers) {
                Vec3d c = box.getCenter();
                RenderUtil.line(b, entry, look.x, look.y, look.z, c.x, c.y, c.z, argb);
            }
        }
        RenderUtil.end(b);
    }

    // ------------------------------------------------------------ 2D HUD waypoints
    public static void renderHud(DrawContext ctx, float td) {
        ModConfig cfg = ConfigManager.get();
        List<Target> list = targets;
        if (!cfg.radarEnabled || list.isEmpty()) return;
        if (cfg.radarRenderStyle != RenderStyle.HUD_WAYPOINTS && cfg.radarRenderStyle != RenderStyle.ALL) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        Camera cam = mc.gameRenderer.getCamera();
        TextRenderer tr = mc.textRenderer;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double fov = mc.options.getFov().getValue();

        for (Target t : list) {
            Entity e = t.entity();
            if (e.isRemoved()) continue;
            Vec3d p = e.getLerpedPos(td).add(0, e.getHeight() + 0.3, 0);
            float[] s = RenderUtil.project(p, cam, sw, sh, fov, 60, 20);
            String text = t.label() + " " + (int) mc.player.distanceTo(e) + "m";
            ctx.drawCenteredTextWithShadow(tr, Text.literal(text), (int) s[0], (int) s[1], ColorUtil.opaque(t.rgb()));
        }
    }
}
