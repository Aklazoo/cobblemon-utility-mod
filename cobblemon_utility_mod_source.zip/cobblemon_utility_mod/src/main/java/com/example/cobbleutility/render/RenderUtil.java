package com.example.cobbleutility.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/** Small immediate-mode helpers: through-walls lines/boxes and world->screen projection. */
public final class RenderUtil {
    private RenderUtil() {}

    // ------------------------------------------------------------ buffers
    public static BufferBuilder beginLines(float width) {
        RenderSystem.setShader(GameRenderer::getRenderTypeLinesProgram);
        RenderSystem.lineWidth(width);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        return Tessellator.getInstance().begin(VertexFormat.DrawMode.LINES, VertexFormats.LINES);
    }

    public static BufferBuilder beginFill() {
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        return Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
    }

    public static void end(BufferBuilder builder) {
        BuiltBuffer built = builder.endNullable();
        if (built != null) BufferRenderer.drawWithGlobalProgram(built);
        RenderSystem.lineWidth(1.0f);
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    // ------------------------------------------------------------ primitives (camera-relative coords)
    public static void line(VertexConsumer vc, MatrixStack.Entry e,
                            double x1, double y1, double z1, double x2, double y2, double z2, int argb) {
        float dx = (float) (x2 - x1), dy = (float) (y2 - y1), dz = (float) (z2 - z1);
        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 1e-6f) return;
        dx /= len; dy /= len; dz /= len;
        vc.vertex(e, (float) x1, (float) y1, (float) z1).color(argb).normal(e, dx, dy, dz);
        vc.vertex(e, (float) x2, (float) y2, (float) z2).color(argb).normal(e, dx, dy, dz);
    }

    public static void boxOutline(VertexConsumer vc, MatrixStack.Entry e, Box b, int argb) {
        double x1 = b.minX, y1 = b.minY, z1 = b.minZ, x2 = b.maxX, y2 = b.maxY, z2 = b.maxZ;
        // bottom
        line(vc, e, x1, y1, z1, x2, y1, z1, argb);
        line(vc, e, x2, y1, z1, x2, y1, z2, argb);
        line(vc, e, x2, y1, z2, x1, y1, z2, argb);
        line(vc, e, x1, y1, z2, x1, y1, z1, argb);
        // top
        line(vc, e, x1, y2, z1, x2, y2, z1, argb);
        line(vc, e, x2, y2, z1, x2, y2, z2, argb);
        line(vc, e, x2, y2, z2, x1, y2, z2, argb);
        line(vc, e, x1, y2, z2, x1, y2, z1, argb);
        // pillars
        line(vc, e, x1, y1, z1, x1, y2, z1, argb);
        line(vc, e, x2, y1, z1, x2, y2, z1, argb);
        line(vc, e, x2, y1, z2, x2, y2, z2, argb);
        line(vc, e, x1, y1, z2, x1, y2, z2, argb);
    }

    public static void diamond(VertexConsumer vc, MatrixStack.Entry e,
                               double cx, double cy, double cz, double s, int argb) {
        double[][] p = {
                {cx + s, cy, cz}, {cx - s, cy, cz}, {cx, cy + s, cz},
                {cx, cy - s, cz}, {cx, cy, cz + s}, {cx, cy, cz - s}};
        int[][] edges = {{0, 2}, {0, 3}, {0, 4}, {0, 5}, {1, 2}, {1, 3}, {1, 4}, {1, 5},
                {2, 4}, {2, 5}, {3, 4}, {3, 5}};
        for (int[] ed : edges) {
            line(vc, e, p[ed[0]][0], p[ed[0]][1], p[ed[0]][2], p[ed[1]][0], p[ed[1]][1], p[ed[1]][2], argb);
        }
    }

    public static void boxFill(VertexConsumer vc, Matrix4f m, Box b, int argb) {
        float x1 = (float) b.minX, y1 = (float) b.minY, z1 = (float) b.minZ;
        float x2 = (float) b.maxX, y2 = (float) b.maxY, z2 = (float) b.maxZ;
        quad(vc, m, argb, x1, y1, z1, x2, y1, z1, x2, y1, z2, x1, y1, z2); // bottom
        quad(vc, m, argb, x1, y2, z1, x1, y2, z2, x2, y2, z2, x2, y2, z1); // top
        quad(vc, m, argb, x1, y1, z1, x1, y2, z1, x2, y2, z1, x2, y1, z1); // north
        quad(vc, m, argb, x1, y1, z2, x2, y1, z2, x2, y2, z2, x1, y2, z2); // south
        quad(vc, m, argb, x1, y1, z1, x1, y1, z2, x1, y2, z2, x1, y2, z1); // west
        quad(vc, m, argb, x2, y1, z1, x2, y2, z1, x2, y2, z2, x2, y1, z2); // east
    }

    private static void quad(VertexConsumer vc, Matrix4f m, int argb,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz) {
        vc.vertex(m, ax, ay, az).color(argb);
        vc.vertex(m, bx, by, bz).color(argb);
        vc.vertex(m, cx, cy, cz).color(argb);
        vc.vertex(m, dx, dy, dz).color(argb);
    }

    // ------------------------------------------------------------ projection
    /**
     * Projects a world position to GUI-scaled screen coordinates.
     * Returns {x, y, onScreen(1/0)}; off-screen / behind-camera points are clamped to the screen edge.
     */
    public static float[] project(Vec3d world, Camera cam, int sw, int sh, double fovDeg,
                                  int marginX, int marginY) {
        Vec3d rel = world.subtract(cam.getPos());
        Vector3f v = new Vector3f((float) rel.x, (float) rel.y, (float) rel.z);
        new Quaternionf(cam.getRotation()).conjugate().transform(v); // world -> camera space (forward = -Z)

        float cx = sw / 2f, cy = sh / 2f;
        float scale = (float) ((sh / 2.0) / Math.tan(Math.toRadians(fovDeg) / 2.0));
        boolean front = v.z < -0.01f;

        float dx, dy;
        if (front) {
            dx = v.x / -v.z * scale;
            dy = -v.y / -v.z * scale;
            if (Math.abs(dx) <= cx - marginX && Math.abs(dy) <= cy - marginY) {
                return new float[]{cx + dx, cy + dy, 1f};
            }
        } else {
            dx = v.x;
            dy = -v.y;
            if (Math.abs(dx) < 1e-3f && Math.abs(dy) < 1e-3f) dy = 1f;
        }
        float tx = Math.abs(dx) < 1e-4f ? Float.MAX_VALUE : (cx - marginX) / Math.abs(dx);
        float ty = Math.abs(dy) < 1e-4f ? Float.MAX_VALUE : (cy - marginY) / Math.abs(dy);
        float t = Math.min(tx, ty);
        return new float[]{cx + dx * t, cy + dy * t, 0f};
    }
}
