package com.example.cobbleutility.config;

import org.lwjgl.glfw.GLFW;

/** Plain data class serialized to JSON by Gson. Colors are stored as 0xRRGGBB ints. */
public class ModConfig {

    // ---------------- Keybinds (GLFW key codes) ----------------
    public int keyOpenSettings = GLFW.GLFW_KEY_O;
    public int keyStructureFinder = GLFW.GLFW_KEY_K;
    public int keyToggleChestEsp = GLFW.GLFW_KEY_C;
    public int keyToggleRadar = GLFW.GLFW_KEY_R;

    // ---------------- Cobblemon radar ----------------
    public boolean radarEnabled = true;
    public boolean radarShiny = true;
    public boolean radarLegendary = true;
    public boolean radarHiddenAbility = true;
    public boolean radarHighIv = true;
    /** Minimum number of stats at 31 IV for the "perfect IVs" filter (1..6). */
    public int radarMinPerfectIvStats = 3;
    public boolean radarIgnoreOwned = true;
    public boolean radarChatAlert = true;
    public boolean radarSoundAlert = true;

    public int radarShinyColor = 0xFFD700;
    public int radarLegendaryColor = 0xFF4500;
    public int radarHiddenAbilityColor = 0x9400D3;
    public int radarHighIvColor = 0x00BFFF;

    public int radarMaxDistance = 128;
    public RenderStyle radarRenderStyle = RenderStyle.ALL;
    public float radarLineThickness = 2.0f;

    // ---------------- Chest / container ESP ----------------
    public boolean chestEspEnabled = true;
    public boolean chestEspChests = true;
    public boolean chestEspTrappedChests = true;
    public boolean chestEspBarrels = true;
    public boolean chestEspShulkers = true;

    public int chestUnlootedColor = 0x00FF00;
    public int chestLootedColor = 0x808080;
    public boolean chestHideLooted = false;

    public int chestMaxRadius = 64;
    public float chestLineThickness = 2.0f;
    public float chestBoxOpacity = 0.25f;

    // ---------------- Structure finder ----------------
    public int structureColor = 0x00FFFF;
    /** true = world path line + beam + HUD icon, false = simple screen compass only. */
    public boolean structureAutoPathLine = true;
}
