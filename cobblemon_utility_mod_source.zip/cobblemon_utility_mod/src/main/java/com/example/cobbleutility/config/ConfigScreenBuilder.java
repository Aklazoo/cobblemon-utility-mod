package com.example.cobbleutility.config;

import com.example.cobbleutility.util.KeyUtil;
import dev.isxander.yacl3.api.*;
import dev.isxander.yacl3.api.controller.*;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.awt.Color;
import java.util.OptionalInt;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Builds the in-game settings screen with YetAnotherConfigLib 3.x. */
public final class ConfigScreenBuilder {
    private ConfigScreenBuilder() {}

    public static Screen create(Screen parent) {
        ModConfig cfg = ConfigManager.get();
        ModConfig def = new ModConfig();

        return YetAnotherConfigLib.createBuilder()
                .title(Text.literal("Cobblemon Utility Mod"))
                .category(controls(cfg, def))
                .category(radar(cfg, def))
                .category(chest(cfg, def))
                .category(structure(cfg, def))
                .save(ConfigManager::save)
                .build()
                .generateScreen(parent);
    }

    // ------------------------------------------------------------------ Controls
    private static ConfigCategory controls(ModConfig c, ModConfig d) {
        String hint = " Type a key name: O, K, C, R, F7, GRAVE, RIGHT_SHIFT, KP_0...";
        return ConfigCategory.createBuilder()
                .name(Text.literal("Controls"))
                .tooltip(Text.literal("Keybinds used by the mod"))
                .option(key("Open settings menu", "Opens this screen." + hint, d.keyOpenSettings,
                        () -> c.keyOpenSettings, v -> c.keyOpenSettings = v))
                .option(key("Open structure finder", "Opens the structure finder menu." + hint, d.keyStructureFinder,
                        () -> c.keyStructureFinder, v -> c.keyStructureFinder = v))
                .option(key("Toggle chest ESP", "Quickly turns the container ESP on/off." + hint, d.keyToggleChestEsp,
                        () -> c.keyToggleChestEsp, v -> c.keyToggleChestEsp = v))
                .option(key("Toggle Cobblemon radar", "Quickly turns the radar on/off." + hint, d.keyToggleRadar,
                        () -> c.keyToggleRadar, v -> c.keyToggleRadar = v))
                .build();
    }

    // ------------------------------------------------------------------ Radar
    private static ConfigCategory radar(ModConfig c, ModConfig d) {
        return ConfigCategory.createBuilder()
                .name(Text.literal("Cobblemon Radar"))
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("General"))
                        .option(toggle("Enable radar", "Master switch.", d.radarEnabled,
                                () -> c.radarEnabled, v -> c.radarEnabled = v))
                        .option(toggle("Ignore owned Pokémon", "Skip Pokémon that belong to a trainer.",
                                d.radarIgnoreOwned, () -> c.radarIgnoreOwned, v -> c.radarIgnoreOwned = v))
                        .option(toggle("Chat alert", "Action-bar message the first time a match is seen.",
                                d.radarChatAlert, () -> c.radarChatAlert, v -> c.radarChatAlert = v))
                        .option(toggle("Sound alert", "Play a sound the first time a match is seen.",
                                d.radarSoundAlert, () -> c.radarSoundAlert, v -> c.radarSoundAlert = v))
                        .option(intSlider("Max scan distance", "Blocks. The client only knows entities the server sends it.",
                                d.radarMaxDistance, 32, 256, 8, () -> c.radarMaxDistance, v -> c.radarMaxDistance = v))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Filters"))
                        .option(toggle("Shiny", "Highlight shiny Pokémon.", d.radarShiny,
                                () -> c.radarShiny, v -> c.radarShiny = v))
                        .option(toggle("Legendary / Mythical", "Highlight legendary and mythical Pokémon.",
                                d.radarLegendary, () -> c.radarLegendary, v -> c.radarLegendary = v))
                        .option(toggle("Hidden Ability", "Highlight Pokémon with a hidden ability (needs server data: singleplayer).",
                                d.radarHiddenAbility, () -> c.radarHiddenAbility, v -> c.radarHiddenAbility = v))
                        .option(toggle("Perfect IVs", "Highlight Pokémon with enough 31 IV stats (needs server data: singleplayer).",
                                d.radarHighIv, () -> c.radarHighIv, v -> c.radarHighIv = v))
                        .option(intSlider("Min. perfect stats (31 IV)", "Number of stats that must be 31.",
                                d.radarMinPerfectIvStats, 1, 6, 1,
                                () -> c.radarMinPerfectIvStats, v -> c.radarMinPerfectIvStats = v))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Colors"))
                        .option(color("Shiny color", d.radarShinyColor, () -> c.radarShinyColor, v -> c.radarShinyColor = v))
                        .option(color("Legendary color", d.radarLegendaryColor, () -> c.radarLegendaryColor, v -> c.radarLegendaryColor = v))
                        .option(color("Hidden Ability color", d.radarHiddenAbilityColor, () -> c.radarHiddenAbilityColor, v -> c.radarHiddenAbilityColor = v))
                        .option(color("High IV color", d.radarHighIvColor, () -> c.radarHighIvColor, v -> c.radarHighIvColor = v))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Rendering"))
                        .option(Option.<RenderStyle>createBuilder()
                                .name(Text.literal("Render style"))
                                .description(OptionDescription.of(Text.literal("Tracers, HUD waypoints, 3D boxes or all of them.")))
                                .binding(d.radarRenderStyle, () -> c.radarRenderStyle, v -> c.radarRenderStyle = v)
                                .controller(o -> EnumControllerBuilder.create(o).enumClass(RenderStyle.class))
                                .build())
                        .option(floatSlider("Line thickness", "Tracer / box line width.", d.radarLineThickness,
                                0.5f, 6f, 0.5f, () -> c.radarLineThickness, v -> c.radarLineThickness = v, false))
                        .build())
                .build();
    }

    // ------------------------------------------------------------------ Chest ESP
    private static ConfigCategory chest(ModConfig c, ModConfig d) {
        return ConfigCategory.createBuilder()
                .name(Text.literal("Chest ESP"))
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("General"))
                        .option(toggle("Enable chest ESP", "Master switch.", d.chestEspEnabled,
                                () -> c.chestEspEnabled, v -> c.chestEspEnabled = v))
                        .option(intSlider("Max render radius", "Blocks.", d.chestMaxRadius, 16, 128, 4,
                                () -> c.chestMaxRadius, v -> c.chestMaxRadius = v))
                        .option(floatSlider("Line thickness", "Outline width.", d.chestLineThickness,
                                0.5f, 6f, 0.5f, () -> c.chestLineThickness, v -> c.chestLineThickness = v, false))
                        .option(floatSlider("Box opacity", "Fill opacity (0 = outline only).", d.chestBoxOpacity,
                                0f, 1f, 0.05f, () -> c.chestBoxOpacity, v -> c.chestBoxOpacity = v, true))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Container types"))
                        .option(toggle("Chests", "", d.chestEspChests, () -> c.chestEspChests, v -> c.chestEspChests = v))
                        .option(toggle("Trapped chests", "", d.chestEspTrappedChests, () -> c.chestEspTrappedChests, v -> c.chestEspTrappedChests = v))
                        .option(toggle("Barrels", "", d.chestEspBarrels, () -> c.chestEspBarrels, v -> c.chestEspBarrels = v))
                        .option(toggle("Shulker boxes", "", d.chestEspShulkers, () -> c.chestEspShulkers, v -> c.chestEspShulkers = v))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Unlooted vs. looted"))
                        .option(color("Unopened color", d.chestUnlootedColor, () -> c.chestUnlootedColor, v -> c.chestUnlootedColor = v))
                        .option(color("Opened / looted color", d.chestLootedColor, () -> c.chestLootedColor, v -> c.chestLootedColor = v))
                        .option(toggle("Hide opened containers", "Ignore containers you already opened (instead of drawing them in gray).",
                                d.chestHideLooted, () -> c.chestHideLooted, v -> c.chestHideLooted = v))
                        .build())
                .build();
    }

    // ------------------------------------------------------------------ Structure finder
    private static ConfigCategory structure(ModConfig c, ModConfig d) {
        return ConfigCategory.createBuilder()
                .name(Text.literal("Structure Finder"))
                .option(color("Waypoint color", d.structureColor, () -> c.structureColor, v -> c.structureColor = v))
                .option(toggle("Automatic path line",
                        "ON: line + beam in the world and HUD icon. OFF: simple directional compass on screen.",
                        d.structureAutoPathLine, () -> c.structureAutoPathLine, v -> c.structureAutoPathLine = v))
                .build();
    }

    // ------------------------------------------------------------------ Helpers
    private static Option<Boolean> toggle(String name, String desc, boolean def,
                                          Supplier<Boolean> getter, Consumer<Boolean> setter) {
        return Option.<Boolean>createBuilder()
                .name(Text.literal(name))
                .description(OptionDescription.of(Text.literal(desc)))
                .binding(def, getter, setter)
                .controller(TickBoxControllerBuilder::create)
                .build();
    }

    private static Option<Integer> intSlider(String name, String desc, int def, int min, int max, int step,
                                             Supplier<Integer> getter, Consumer<Integer> setter) {
        return Option.<Integer>createBuilder()
                .name(Text.literal(name))
                .description(OptionDescription.of(Text.literal(desc)))
                .binding(def, getter, setter)
                .controller(o -> IntegerSliderControllerBuilder.create(o).range(min, max).step(step))
                .build();
    }

    private static Option<Float> floatSlider(String name, String desc, float def, float min, float max, float step,
                                             Supplier<Float> getter, Consumer<Float> setter, boolean percent) {
        return Option.<Float>createBuilder()
                .name(Text.literal(name))
                .description(OptionDescription.of(Text.literal(desc)))
                .binding(def, getter, setter)
                .controller(o -> FloatSliderControllerBuilder.create(o).range(min, max).step(step)
                        .formatValue(v -> percent
                                ? Text.literal(Math.round(v * 100) + "%")
                                : Text.literal(String.format("%.1f", v))))
                .build();
    }

    private static Option<Color> color(String name, int def, IntSupplier getter, IntConsumer setter) {
        return Option.<Color>createBuilder()
                .name(Text.literal(name))
                .description(OptionDescription.of(Text.literal("Click the swatch or type a hex value (#RRGGBB).")))
                .binding(new Color(def), () -> new Color(getter.getAsInt()), v -> setter.accept(v.getRGB() & 0xFFFFFF))
                .controller(o -> ColorControllerBuilder.create(o).allowAlpha(false))
                .build();
    }

    private static Option<String> key(String name, String desc, int defCode,
                                      IntSupplier getter, IntConsumer setter) {
        return Option.<String>createBuilder()
                .name(Text.literal(name))
                .description(OptionDescription.of(Text.literal(desc)))
                .binding(KeyUtil.nameOf(defCode), () -> KeyUtil.nameOf(getter.getAsInt()), v -> {
                    OptionalInt code = KeyUtil.codeOf(v);
                    if (code.isPresent()) setter.accept(code.getAsInt()); // invalid names are ignored
                })
                .controller(StringControllerBuilder::create)
                .build();
    }
}
