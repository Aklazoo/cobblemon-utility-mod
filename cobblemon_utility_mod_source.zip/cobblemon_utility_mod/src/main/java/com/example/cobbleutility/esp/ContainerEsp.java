package com.example.cobbleutility.esp;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.render.RenderUtil;
import com.example.cobbleutility.util.ColorUtil;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/** Scans loaded chunks once per second; per frame we only draw the cached list. */
public final class ContainerEsp {
    public enum Kind { CHEST, TRAPPED, BARREL, SHULKER }

    private record Entry(Box box, boolean looted) {}

    private static volatile List<Entry> entries = List.of();
    private static int tick;

    private ContainerEsp() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(ContainerEsp::onTick);
    }

    public static void rescanSoon() {
        tick = 19; // next tick hits the % 20 boundary
    }

    public static Kind kindOf(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) return Kind.TRAPPED;
        if (be instanceof ChestBlockEntity) return Kind.CHEST;
        if (be instanceof BarrelBlockEntity) return Kind.BARREL;
        if (be instanceof ShulkerBoxBlockEntity) return Kind.SHULKER;
        return null;
    }

    private static boolean enabled(ModConfig c, Kind k) {
        return switch (k) {
            case CHEST -> c.chestEspChests;
            case TRAPPED -> c.chestEspTrappedChests;
            case BARREL -> c.chestEspBarrels;
            case SHULKER -> c.chestEspShulkers;
        };
    }

    // ------------------------------------------------------------ scan
    private static void onTick(MinecraftClient mc) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.chestEspEnabled || mc.world == null || mc.player == null) {
            if (!entries.isEmpty()) entries = List.of();
            return;
        }
        if (++tick % 20 != 0) return;

        ClientWorld w = mc.world;
        Identifier dim = w.getRegistryKey().getValue();
        double r = cfg.chestMaxRadius;
        double rSq = r * r;
        Vec3d pp = mc.player.getPos();
        int cr = (int) (r / 16) + 1;
        ChunkPos pc = mc.player.getChunkPos();
        List<Entry> out = new ArrayList<>();

        for (int dx = -cr; dx <= cr; dx++) {
            for (int dz = -cr; dz <= cr; dz++) {
                WorldChunk chunk = w.getChunkManager().getWorldChunk(pc.x + dx, pc.z + dz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    Kind k = kindOf(be);
                    if (k == null || !enabled(cfg, k)) continue;
                    BlockPos pos = be.getPos();
                    if (pos.getSquaredDistance(pp) > rSq) continue;

                    BlockState st = be.getCachedState();
                    boolean looted = OpenedContainers.isOpened(dim, pos.asLong());
                    Box box = new Box(pos);

                    if ((k == Kind.CHEST || k == Kind.TRAPPED)
                            && st.contains(ChestBlock.CHEST_TYPE)
                            && st.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
                        if (st.get(ChestBlock.CHEST_TYPE) == ChestType.RIGHT) continue; // drawn from the LEFT half
                        BlockPos other = pos.offset(ChestBlock.getFacing(st));
                        box = box.union(new Box(other));
                        looted = looted || OpenedContainers.isOpened(dim, other.asLong());
                    }
                    if (k == Kind.CHEST || k == Kind.TRAPPED) {
                        box = new Box(box.minX + 0.0625, box.minY, box.minZ + 0.0625,
                                box.maxX - 0.0625, box.maxY - 0.125, box.maxZ - 0.0625);
                    }
                    if (looted && cfg.chestHideLooted) continue;
                    out.add(new Entry(box.expand(0.002), looted));
                }
            }
        }
        entries = out;
    }

    // ------------------------------------------------------------ render
    public static void render(MatrixStack ms, Vec3d cam) {
        ModConfig cfg = ConfigManager.get();
        List<Entry> list = entries;
        if (!cfg.chestEspEnabled || list.isEmpty()) return;

        int alpha = Math.round(cfg.chestBoxOpacity * 255f);
        if (alpha > 2) {
            Matrix4f m = ms.peek().getPositionMatrix();
            BufferBuilder f = RenderUtil.beginFill();
            for (Entry e : list) {
                int rgb = e.looted() ? cfg.chestLootedColor : cfg.chestUnlootedColor;
                RenderUtil.boxFill(f, m, e.box().offset(-cam.x, -cam.y, -cam.z), ColorUtil.argb(rgb, alpha));
            }
            RenderUtil.end(f);
        }

        MatrixStack.Entry entry = ms.peek();
        BufferBuilder l = RenderUtil.beginLines(cfg.chestLineThickness);
        for (Entry e : list) {
            int rgb = e.looted() ? cfg.chestLootedColor : cfg.chestUnlootedColor;
            RenderUtil.boxOutline(l, entry, e.box().offset(-cam.x, -cam.y, -cam.z), ColorUtil.opaque(rgb));
        }
        RenderUtil.end(l);
    }
}
