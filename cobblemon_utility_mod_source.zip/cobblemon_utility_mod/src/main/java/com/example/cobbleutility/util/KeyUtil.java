package com.example.cobbleutility.util;

import net.minecraft.client.util.InputUtil;

import java.util.Locale;
import java.util.OptionalInt;

/** Converts between GLFW key codes and human-typable names (O, K, GRAVE_ACCENT, F7, RIGHT_SHIFT...). */
public final class KeyUtil {
    private KeyUtil() {}

    public static String nameOf(int code) {
        String tk = InputUtil.fromKeyCode(code, -1).getTranslationKey();
        if (tk.startsWith("key.keyboard.")) tk = tk.substring("key.keyboard.".length());
        return tk.toUpperCase(Locale.ROOT).replace('.', '_');
    }

    public static OptionalInt codeOf(String name) {
        if (name == null) return OptionalInt.empty();
        String n = name.trim().toLowerCase(Locale.ROOT).replace(' ', '.').replace('_', '.');
        if (n.equals("grave") || n.equals("tilde") || n.equals("backtick")) n = "grave.accent";
        try {
            return OptionalInt.of(InputUtil.fromTranslationKey("key.keyboard." + n).getCode());
        } catch (IllegalArgumentException e) {
            return OptionalInt.empty();
        }
    }
}
