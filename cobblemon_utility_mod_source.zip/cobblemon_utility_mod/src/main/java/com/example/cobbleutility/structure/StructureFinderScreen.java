package com.example.cobbleutility.structure;

import com.example.cobbleutility.config.ConfigScreenBuilder;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

public class StructureFinderScreen extends Screen {
    private final Screen parent;

    public StructureFinderScreen(Screen parent) {
        super(Text.literal("Structure Finder"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        MinecraftClient mc = MinecraftClient.getInstance();
        Identifier dim = mc.world != null ? mc.world.getRegistryKey().getValue() : null;
        List<StructureFinder.Entry> list = StructureFinder.ENTRIES.stream()
                .filter(e -> e.dim().equals(dim)).toList();

        int cols = 3, w = 110, h = 20, gap = 4;
        int total = cols * w + (cols - 1) * gap;
        int x0 = (width - total) / 2, y0 = 42;
        for (int i = 0; i < list.size(); i++) {
            StructureFinder.Entry entry = list.get(i);
            int x = x0 + (i % cols) * (w + gap);
            int y = y0 + (i / cols) * (h + gap);
            addDrawableChild(ButtonWidget.builder(Text.literal(entry.name()), b -> {
                StructureFinder.locate(entry);
                close();
            }).dimensions(x, y, w, h).build());
        }

        int by = height - 28;
        addDrawableChild(ButtonWidget.builder(Text.literal("Clear waypoint"), b -> StructureFinder.clear())
                .dimensions(width / 2 - 166, by, 108, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Settings"),
                        b -> MinecraftClient.getInstance().setScreen(ConfigScreenBuilder.create(this)))
                .dimensions(width / 2 - 54, by, 108, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(width / 2 + 58, by, 108, 20).build());
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFFFF);
        StructureFinder.Waypoint wp = StructureFinder.getWaypoint();
        String sub = wp == null ? "Pick a structure to track" : "Tracking: " + wp.name();
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(sub), width / 2, 27, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(parent);
    }
}
