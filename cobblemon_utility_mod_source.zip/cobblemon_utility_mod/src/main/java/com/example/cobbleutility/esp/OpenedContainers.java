package com.example.cobbleutility.esp;

import com.example.cobbleutility.CobblemonUtilityMod;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * The client cannot see loot tables, so "looted" = containers YOU opened (right-click).
 * Remembered per world/server and saved to config/cobblemon_utility_mod_opened.json.
 */
public final class OpenedContainers {
    private static final Gson GSON = new Gson();
    private static final Type TYPE = new TypeToken<Map<String, Map<String, Set<Long>>>>() {}.getType();
    private static final Path FILE =
            FabricLoader.getInstance().getConfigDir().resolve("cobblemon_utility_mod_opened.json");

    private static Map<String, Map<String, Set<Long>>> all = new HashMap<>();
    private static String worldKey = "unknown";
    private static boolean dirty;
    private static int tick;

    private OpenedContainers() {}

    public static void init() {
        load();
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            worldKey = computeKey(client);
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> save());
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (++tick % 1200 == 0) save();
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.isClient) return ActionResult.PASS;
            if (player.isSneaking() && !player.getMainHandStack().isEmpty()) return ActionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            BlockEntity be = world.getBlockEntity(pos);
            if (be == null || ContainerEsp.kindOf(be) == null) return ActionResult.PASS;

            Identifier dim = world.getRegistryKey().getValue();
            mark(dim, pos);
            BlockState st = be.getCachedState();
            if (st.contains(ChestBlock.CHEST_TYPE) && st.get(ChestBlock.CHEST_TYPE) != ChestType.SINGLE) {
                mark(dim, pos.offset(ChestBlock.getFacing(st)));
            }
            ContainerEsp.rescanSoon();
            return ActionResult.PASS;
        });
    }

    public static boolean isOpened(Identifier dim, long posKey) {
        Map<String, Set<Long>> perDim = all.get(worldKey);
        if (perDim == null) return false;
        Set<Long> set = perDim.get(dim.toString());
        return set != null && set.contains(posKey);
    }

    private static void mark(Identifier dim, BlockPos pos) {
        all.computeIfAbsent(worldKey, k -> new HashMap<>())
                .computeIfAbsent(dim.toString(), k -> new HashSet<>())
                .add(pos.asLong());
        dirty = true;
    }

    private static String computeKey(MinecraftClient mc) {
        try {
            if (mc.getServer() != null) {
                return "sp:" + mc.getServer().getSaveProperties().getLevelName();
            }
            if (mc.getCurrentServerEntry() != null) {
                return "mp:" + mc.getCurrentServerEntry().address;
            }
        } catch (Throwable ignored) {
        }
        return "unknown";
    }

    private static void load() {
        try {
            if (Files.exists(FILE)) {
                Map<String, Map<String, Set<Long>>> read =
                        GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), TYPE);
                if (read != null) all = read;
            }
        } catch (Exception e) {
            CobblemonUtilityMod.LOGGER.warn("Could not read opened-containers file", e);
        }
    }

    private static void save() {
        if (!dirty) return;
        try {
            Files.writeString(FILE, GSON.toJson(all, TYPE), StandardCharsets.UTF_8);
            dirty = false;
        } catch (Exception e) {
            CobblemonUtilityMod.LOGGER.warn("Could not save opened-containers file", e);
        }
    }
}
