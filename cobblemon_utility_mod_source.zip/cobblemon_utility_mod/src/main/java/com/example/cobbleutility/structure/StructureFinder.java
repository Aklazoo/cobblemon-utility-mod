package com.example.cobbleutility.structure;

import com.example.cobbleutility.CobblemonUtilityMod;
import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.render.RenderUtil;
import com.example.cobbleutility.util.ColorUtil;
import com.mojang.datafixers.util.Pair;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.gen.structure.Structure;

import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Singleplayer: asks the integrated server directly (same engine as /locate, no cheats needed).
 * Multiplayer: sends "/locate structure ..." (needs permission) and parses the coordinates from the reply.
 */
public final class StructureFinder {
    public record Entry(String query, String name, Identifier dim) {}
    public record Waypoint(BlockPos pos, String name, Identifier dim) {}

    private static final Identifier OVERWORLD = Identifier.of("minecraft", "overworld");
    private static final Identifier NETHER = Identifier.of("minecraft", "the_nether");
    private static final Identifier END = Identifier.of("minecraft", "the_end");

    public static final List<Entry> ENTRIES = List.of(
            new Entry("#minecraft:village", "Village", OVERWORLD),
            new Entry("minecraft:pillager_outpost", "Pillager Outpost", OVERWORLD),
            new Entry("minecraft:mansion", "Woodland Mansion", OVERWORLD),
            new Entry("minecraft:monument", "Ocean Monument", OVERWORLD),
            new Entry("minecraft:stronghold", "Stronghold", OVERWORLD),
            new Entry("minecraft:ancient_city", "Ancient City", OVERWORLD),
            new Entry("minecraft:trial_chambers", "Trial Chambers", OVERWORLD),
            new Entry("minecraft:desert_pyramid", "Desert Temple", OVERWORLD),
            new Entry("minecraft:jungle_pyramid", "Jungle Temple", OVERWORLD),
            new Entry("minecraft:swamp_hut", "Swamp Hut", OVERWORLD),
            new Entry("minecraft:igloo", "Igloo", OVERWORLD),
            new Entry("#minecraft:shipwreck", "Shipwreck", OVERWORLD),
            new Entry("#minecraft:ocean_ruin", "Ocean Ruins", OVERWORLD),
            new Entry("#minecraft:mineshaft", "Mineshaft", OVERWORLD),
            new Entry("#minecraft:ruined_portal", "Ruined Portal", OVERWORLD),
            new Entry("minecraft:trail_ruins", "Trail Ruins", OVERWORLD),
            new Entry("minecraft:fortress", "Nether Fortress", NETHER),
            new Entry("minecraft:bastion_remnant", "Bastion Remnant", NETHER),
            new Entry("minecraft:nether_fossil", "Nether Fossil", NETHER),
            new Entry("#minecraft:ruined_portal", "Ruined Portal", NETHER),
            new Entry("minecraft:end_city", "End City", END));

    private static final Pattern COORDS = Pattern.compile("\\[(-?\\d+), (?:~|-?\\d+), (-?\\d+)\\]");

    private static Waypoint waypoint;
    private static String pendingName;
    private static Identifier pendingDim;
    private static int pendingTicks;

    private StructureFinder() {}

    public static Waypoint getWaypoint() {
        return waypoint;
    }

    public static void clear() {
        waypoint = null;
    }

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (pendingName != null && --pendingTicks <= 0) {
                if (mc.player != null) {
                    mc.player.sendMessage(Text.literal("§cNo result for " + pendingName
                            + " (no permission for /locate, or not found)."), true);
                }
                pendingName = null;
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> {
            waypoint = null;
            pendingName = null;
        });
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (pendingName == null || overlay) return;
            Matcher m = COORDS.matcher(message.getString());
            if (m.find()) {
                BlockPos pos = new BlockPos(Integer.parseInt(m.group(1)), 64, Integer.parseInt(m.group(2)));
                setResult(pendingName, pendingDim, pos);
                pendingName = null;
            }
        });
    }

    // ------------------------------------------------------------ locating
    public static void locate(Entry entry) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        mc.player.sendMessage(Text.literal("§7Searching for " + entry.name() + "..."), true);

        Identifier dim = mc.world.getRegistryKey().getValue();
        IntegratedServer srv = mc.getServer();
        if (srv != null) {
            RegistryKey<net.minecraft.world.World> worldKey = mc.world.getRegistryKey();
            BlockPos origin = mc.player.getBlockPos();
            srv.execute(() -> {
                BlockPos found = null;
                try {
                    ServerWorld sw = srv.getWorld(worldKey);
                    if (sw != null) found = search(sw, entry.query(), origin);
                } catch (Throwable t) {
                    CobblemonUtilityMod.LOGGER.warn("Structure search failed", t);
                }
                BlockPos result = found;
                mc.execute(() -> setResult(entry.name(), dim, result));
            });
        } else {
            pendingName = entry.name();
            pendingDim = dim;
            pendingTicks = 400;
            mc.player.networkHandler.sendChatCommand("locate structure " + entry.query());
        }
    }

    private static BlockPos search(ServerWorld sw, String query, BlockPos origin) {
        Registry<Structure> reg = sw.getRegistryManager().get(RegistryKeys.STRUCTURE);
        RegistryEntryList<Structure> list = null;
        if (query.startsWith("#")) {
            TagKey<Structure> tag = TagKey.of(RegistryKeys.STRUCTURE, Identifier.of(query.substring(1)));
            Optional<RegistryEntryList.Named<Structure>> named = reg.getEntryList(tag);
            if (named.isPresent()) list = named.get();
        } else {
            Optional<RegistryEntry.Reference<Structure>> ref =
                    reg.getEntry(RegistryKey.of(RegistryKeys.STRUCTURE, Identifier.of(query)));
            if (ref.isPresent()) list = RegistryEntryList.of(List.of(ref.get()));
        }
        if (list == null) return null;
        Pair<BlockPos, RegistryEntry<Structure>> pair =
                sw.getChunkManager().getChunkGenerator().locateStructure(sw, list, origin, 100, false);
        return pair == null ? null : pair.getFirst();
    }

    private static void setResult(String name, Identifier dim, BlockPos pos) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (pos == null) {
            mc.player.sendMessage(Text.literal("§c" + name + " not found nearby."), true);
            return;
        }
        waypoint = new Waypoint(pos, name, dim);
        mc.player.sendMessage(Text.literal("§b" + name + " §7at §f" + pos.getX() + ", " + pos.getZ()), true);
    }

    // ------------------------------------------------------------ world rendering
    public static void renderWorld(MatrixStack ms, Vec3d cam, Camera camera) {
        ModConfig cfg = ConfigManager.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        Waypoint wp = waypoint;
        if (wp == null || !cfg.structureAutoPathLine || mc.world == null) return;
        if (!mc.world.getRegistryKey().getValue().equals(wp.dim())) return;

        double dx = wp.pos().getX() + 0.5 - cam.x;
        double dz = wp.pos().getZ() + 0.5 - cam.z;
        double dist = Math.sqrt(dx * dx + dz * dz);
        if (dist < 1.5) return;

        int argb = ColorUtil.opaque(cfg.structureColor);
        double scale = Math.min(1.0, 64.0 / dist);
        double ex = dx * scale, ez = dz * scale, ey = -1.0;
        Vec3d look = Vec3d.fromPolar(camera.getPitch(), camera.getYaw()).multiply(0.4);

        MatrixStack.Entry entry = ms.peek();
        BufferBuilder b = RenderUtil.beginLines(2.5f);
        RenderUtil.line(b, entry, look.x, look.y - 0.2, look.z, ex, ey, ez, argb);
        double size = 0.5 + Math.sqrt(ex * ex + ez * ez) * 0.02;
        RenderUtil.diamond(b, entry, ex, ey, ez, size, argb);
        if (dist <= 256) { // vertical beam at the real location
            RenderUtil.line(b, entry, dx, -64 - cam.y, dz, dx, 320 - cam.y, dz, argb);
        }
        RenderUtil.end(b);
    }

    // ------------------------------------------------------------ HUD
    public static void renderHud(DrawContext ctx, float td) {
        ModConfig cfg = ConfigManager.get();
        MinecraftClient mc = MinecraftClient.getInstance();
        Waypoint wp = waypoint;
        if (wp == null || mc.player == null || mc.world == null) return;
        if (!mc.world.getRegistryKey().getValue().equals(wp.dim())) return;

        TextRenderer tr = mc.textRenderer;
        int color = ColorUtil.opaque(cfg.structureColor);
        double dx = wp.pos().getX() + 0.5 - mc.player.getX();
        double dz = wp.pos().getZ() + 0.5 - mc.player.getZ();
        int dist = (int) Math.sqrt(dx * dx + dz * dz);
        String label = wp.name() + " - " + dist + "m";
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();

        if (cfg.structureAutoPathLine) {
            Camera cam = mc.gameRenderer.getCamera();
            Vec3d target = new Vec3d(wp.pos().getX() + 0.5, mc.player.getEyeY(), wp.pos().getZ() + 0.5);
            float[] s = RenderUtil.project(target, cam, sw, sh, mc.options.getFov().getValue(), 60, 24);
            ctx.drawCenteredTextWithShadow(tr, Text.literal("◆ " + label), (int) s[0], (int) s[1], color);
        } else {
            // simple directional compass bar
            float targetYaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            float rel = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
            int half = 90, cx = sw / 2, y = 30;
            ctx.fill(cx - half, y, cx + half, y + 1, 0x90FFFFFF);
            ctx.fill(cx - 1, y - 3, cx + 1, y + 4, 0xC0FFFFFF);
            int ax = cx + Math.round(MathHelper.clamp(rel / 90f, -1f, 1f) * half);
            ctx.drawCenteredTextWithShadow(tr, Text.literal("▼"), ax, y - 11, color);
            ctx.drawCenteredTextWithShadow(tr, Text.literal(label), cx, y + 8, color);
        }
    }
}
