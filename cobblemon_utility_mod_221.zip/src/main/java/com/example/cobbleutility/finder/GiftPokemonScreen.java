package com.example.cobbleutility.finder;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.net.ServerLink;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * Gift Pokémon: choose any item of the game (same picker as the container filter) and a weak Pokémon holding it
 * appears near you on a server with Cobblemon Shiny Control. Catch it, then take the item from its hand.
 */
public class GiftPokemonScreen extends Screen {
    /** Last answer of the server, shown under the buttons. */
    public static String lastResult = "";

    private final Screen parent;
    private TextFieldWidget itemField;
    private TextFieldWidget speciesField;
    private TextFieldWidget levelField;

    public GiftPokemonScreen(Screen parent) {
        super(Text.literal("Gift Pokémon"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        ModConfig cfg = ConfigManager.get();
        int cx = width / 2;
        itemField = new TextFieldWidget(textRenderer, cx - 160, 46, 320, 20, Text.literal("Item"));
        itemField.setPlaceholder(Text.literal("item id, e.g. cobblemon:master_ball"));
        itemField.setMaxLength(120);
        itemField.setText(cfg.giftItem == null ? "" : cfg.giftItem);
        addDrawableChild(itemField);

        addDrawableChild(ButtonWidget.builder(Text.literal("Pick item (icons, all mods)"),
                        b -> MinecraftClient.getInstance().setScreen(new ItemPickerScreen(this, id -> {
                            itemField.setText(id);
                            save();
                        }))).dimensions(cx - 160, 70, 320, 20).build());

        speciesField = new TextFieldWidget(textRenderer, cx - 160, 112, 200, 20, Text.literal("Species"));
        speciesField.setPlaceholder(Text.literal("Pokémon holding the item"));
        speciesField.setMaxLength(40);
        speciesField.setText(cfg.giftSpecies == null || cfg.giftSpecies.isEmpty() ? "magikarp" : cfg.giftSpecies);
        addDrawableChild(speciesField);

        levelField = new TextFieldWidget(textRenderer, cx + 50, 112, 110, 20, Text.literal("Level"));
        levelField.setMaxLength(3);
        levelField.setText(String.valueOf(Math.max(1, Math.min(100, cfg.giftLevel))));
        addDrawableChild(levelField);

        addDrawableChild(ButtonWidget.builder(Text.literal("Spawn the Pokémon with this item"), b -> send())
                .dimensions(cx - 160, 144, 320, 22).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(cx - 50, height - 28, 100, 20).build());
        setInitialFocus(itemField);
    }

    private void save() {
        ModConfig cfg = ConfigManager.get();
        cfg.giftItem = itemField.getText().trim();
        cfg.giftSpecies = speciesField.getText().trim();
        try {
            cfg.giftLevel = Math.max(1, Math.min(100, Integer.parseInt(levelField.getText().trim())));
        } catch (NumberFormatException ignored) {
        }
        ConfigManager.save();
    }

    private void send() {
        save();
        ModConfig cfg = ConfigManager.get();
        String item = cfg.giftItem;
        if (item.isEmpty()) {
            lastResult = "§cChoose an item first.";
            return;
        }
        if (!item.contains(":")) item = "minecraft:" + item;
        if (!ServerLink.available()) {
            lastResult = "§cThis server does not have the Cobblemon Shiny Control mod (1.11.0 or newer).";
            return;
        }
        lastResult = "§7Asking the server...";
        ServerLink.requestGift(item, cfg.giftSpecies, cfg.giftLevel);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        int cx = width / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Gift Pokémon"), cx, 12, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("A Pokémon holding the item appears near you. Catch it, then take the item."),
                cx, 28, 0xB0BEC5);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Species / level"), cx - 160, 100, 0xB0BEC5);
        // icon of the chosen item
        try {
            String t = itemField.getText().trim();
            Identifier id = Identifier.tryParse(t.contains(":") ? t : "minecraft:" + t);
            if (id != null && Registries.ITEM.containsId(id)) {
                ctx.drawItem(new ItemStack(Registries.ITEM.get(id)), cx + 166, 48);
            }
        } catch (Throwable ignored) {
        }
        if (!lastResult.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(lastResult), cx, 176, 0xFFFFFF);
        }
        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        save();
        MinecraftClient.getInstance().setScreen(parent);
    }
}
