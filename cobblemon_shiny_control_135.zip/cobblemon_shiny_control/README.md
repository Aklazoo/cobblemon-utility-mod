# Cobblemon Shiny Control (Fabric 1.21.1) - server-side

Put the jar in the server's mods/ folder (Exaroton: Files -> mods). No client install needed.
Needs Fabric API and Cobblemon on the server. Commands require op level 2 (console always works).

/shinyrate                       status
/shinyrate multiplier <x>        permanent multiplier (saved in config/cobblemon_shiny_control.json)
/shinyrate set <N>               shiny odds 1/N
/shinyrate boost <x> <seconds>   temporary boost, announced to all players
/shinyrate boost stop
/shinyrate reset

It changes Cobblemon's in-memory shinyRate only; Cobblemon's own config file is not modified.

## Finder (only through the Cobblemon Utility client mod, no chat command, no op needed)
The client mod (1.6.0+) sends a request packet; this mod answers. Typing anything in chat does nothing.
Pokémon finder: shiny / legendary / hidden ability / N perfect IVs / species, nearest first.
Structure finder: lists every registered structure (modded included) and returns coordinates.

Config (config/cobblemon_shiny_control.json, restart after editing):
findEnabled, structuresEnabled, allowedPlayers (empty = everyone with the client mod),
findCooldownSeconds, findMaxRadius, findMaxResults, findDefaultMinPerfectIvs,
findCoords ("exact" | "approx" | "direction"), findIvDisplay ("full" | "count" | "none"), findIncludeOwned,
structureCooldownSeconds, structureSearchRadius,
chestsEnabled, chestCooldownSeconds, chestMaxRadius, chestMaxResults (container finder; loaded chunks only, never-opened
loot chests are revealed because their loot is generated from the chest's own seed when read). Operators ignore cooldowns.
It only sees Pokémon in chunks the server has loaded.

Lootr probe: if the Lootr mod is installed, config/cobblemon_shiny_control_lootr_dump.txt is written once (diagnostic only).


## Lootr / per-player chests (1.5.0)
Lootr rolls a fresh inventory for each player at the moment a chest is opened, so the real content cannot be read
beforehand. The container finder now also lists such chests as "possible": the mod finds the chest's loot table by itself,
walks it and estimates the chance (percent) that one opening gives the searched item. Config keys: chestPossibleEnabled,
chestMinChancePercent. Conditions such as luck are ignored, so the figure is an estimate. The first Lootr container data
is written to latest.log ("First Lootr container data seen") and the Lootr API to
config/cobblemon_shiny_control_lootr_dump.txt, to help adjust the detection if needed.
