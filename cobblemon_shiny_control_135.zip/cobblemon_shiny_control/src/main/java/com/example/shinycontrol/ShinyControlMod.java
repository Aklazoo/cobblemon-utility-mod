package com.example.shinycontrol;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Works on a dedicated server (Exaroton...) and in singleplayer. No client needed. */
public class ShinyControlMod implements ModInitializer {
    public static final String MOD_ID = "cobblemon_shiny_control";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ControlConfig.load();
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                ShinyCommand.register(dispatcher));
        ServerNet.init();
        ServerLifecycleEvents.SERVER_STARTED.register(ShinyRate::onServerStarted);
        ServerLifecycleEvents.SERVER_STARTED.register(server -> { LootChance.clearCache(); LootrProbe.run(); });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> ShinyRate.restore());
        ServerTickEvents.END_SERVER_TICK.register(ShinyRate::onTick);
    }
}
