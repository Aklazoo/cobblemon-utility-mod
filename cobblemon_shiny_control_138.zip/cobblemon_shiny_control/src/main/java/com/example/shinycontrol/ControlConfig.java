package com.example.shinycontrol;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Persistent part of the settings: config/cobblemon_shiny_control.json */
public final class ControlConfig {
    /** Permanent multiplier of the shiny odds (1 = Cobblemon's own rate). */
    public double multiplier = 1.0;

    // ---- features used by the Cobblemon Utility client mod (no chat command exists) ----
    public boolean findEnabled = true;
    public boolean structuresEnabled = true;
    /** Container finder: lists loaded chests / barrels / modded containers holding a given item. */
    public boolean chestsEnabled = true;
    /** Also list chests whose loot is rolled only when opened (Lootr...) with the chance that they can give the item. */
    public boolean chestPossibleEnabled = true;
    /** Hide "possible" chests below this chance (percent). */
    public double chestMinChancePercent = 1.0;
    /** Lootr chests: roll the exact content for the asking player (needs the seed hook, active by default). */
    public boolean chestExactEnabled = true;
    /** At most this many Lootr chests are previewed per search (keeps the server light). */
    public int chestExactMax = 300;
    public int chestCooldownSeconds = 5;
    public int chestMaxRadius = 128;
    public int chestMaxResults = 20;
    /** Player names allowed to use these features. Empty list = every player who has the client mod. */
    public java.util.List<String> allowedPlayers = new java.util.ArrayList<>();
    /** Seconds between two Pokémon searches per player (operators are not limited). 0 = no limit. */
    public int findCooldownSeconds = 30;
    /** Only Pokémon within this many blocks of the player are listed. */
    public int findMaxRadius = 256;
    public int findMaxResults = 10;
    /** Without a filter: list Pokémon with at least this many perfect (31) IVs. */
    public int findDefaultMinPerfectIvs = 5;
    /** "exact" = x y z, "approx" = rounded to 50 blocks, "direction" = distance + compass only. */
    public String findCoords = "exact";
    /** "full" = 31/12/..., "count" = number of perfect IVs only, "none" = hidden. */
    public String findIvDisplay = "full";
    public boolean findIncludeOwned = false;
    /** Seconds between two structure searches per player (operators are not limited). */
    public int structureCooldownSeconds = 15;
    /** Search radius in chunks (vanilla /locate uses 100). Bigger = slower, can lag the server. */
    public int structureSearchRadius = 100;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("cobblemon_shiny_control.json");
    private static ControlConfig instance = new ControlConfig();

    public static ControlConfig get() {
        return instance;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                ControlConfig read = GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), ControlConfig.class);
                if (read != null) instance = read;
            }
        } catch (Exception e) {
            ShinyControlMod.LOGGER.warn("Could not read config, using defaults", e);
        }
        instance.multiplier = Math.max(1.0, Math.min(1000.0, instance.multiplier));
        if (instance.allowedPlayers == null) instance.allowedPlayers = new java.util.ArrayList<>();
        instance.structureCooldownSeconds = Math.max(0, Math.min(3600, instance.structureCooldownSeconds));
        instance.structureSearchRadius = Math.max(10, Math.min(500, instance.structureSearchRadius));
        instance.chestCooldownSeconds = Math.max(0, Math.min(3600, instance.chestCooldownSeconds));
        instance.chestMinChancePercent = Math.max(0.0, Math.min(100.0, instance.chestMinChancePercent));
        instance.chestExactMax = Math.max(0, Math.min(2000, instance.chestExactMax));
        instance.chestMaxRadius = Math.max(16, Math.min(512, instance.chestMaxRadius));
        instance.chestMaxResults = Math.max(1, Math.min(50, instance.chestMaxResults));
        instance.findCooldownSeconds = Math.max(0, Math.min(3600, instance.findCooldownSeconds));
        instance.findMaxRadius = Math.max(16, Math.min(4096, instance.findMaxRadius));
        instance.findMaxResults = Math.max(1, Math.min(50, instance.findMaxResults));
        instance.findDefaultMinPerfectIvs = Math.max(1, Math.min(6, instance.findDefaultMinPerfectIvs));
        if (instance.findCoords == null || !java.util.List.of("exact", "approx", "direction").contains(instance.findCoords)) instance.findCoords = "exact";
        if (instance.findIvDisplay == null || !java.util.List.of("full", "count", "none").contains(instance.findIvDisplay)) instance.findIvDisplay = "full";
        save();
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(instance), StandardCharsets.UTF_8);
        } catch (Exception e) {
            ShinyControlMod.LOGGER.warn("Could not save config", e);
        }
    }
}
