package com.example.cobbleutility.config;

import org.lwjgl.glfw.GLFW;

/** Plain data class serialized to JSON by Gson. Colors are stored as 0xRRGGBB ints. */
public class ModConfig {

    // ---------------- Keybinds (GLFW key codes, -1 = not bound) ----------------
    public int keyOpenSettings = GLFW.GLFW_KEY_O;
    public int keyStructureFinder = GLFW.GLFW_KEY_K;
    public int keyToggleChestEsp = GLFW.GLFW_KEY_C;
    public int keyToggleRadar = GLFW.GLFW_KEY_R;
    /** Marks / unmarks the container you are looking at as "opened". Unbound by default. */
    public int keyMarkContainer = GLFW.GLFW_KEY_UNKNOWN;
    /** Opens the Pokémon menu (give / spawn Pokémon, custom command buttons). */
    public int keyOpenPokeMenu = GLFW.GLFW_KEY_H;
    /** Look at a block: shows its id and whether it is detected. Shift+key adds / removes it from the lists. */
    public int keyInspectBlock = GLFW.GLFW_KEY_V;

    /** Opens the server Pokémon finder (shiny / IV / legendary across the server). */
    public int keyPokeFinder = GLFW.GLFW_KEY_J;
    /** Toggles the Poké Ball aim assist. */
    public int keyBallAim = GLFW.GLFW_KEY_G;

    /** Opens the container filter (find chests holding a given item). */
    public int keyChestFilter = GLFW.GLFW_KEY_N;

    /** Opens the Type Advisor (opponent types / weaknesses / best team member). */
    public int keyTypeAdvisor = GLFW.GLFW_KEY_B;

    /** Stream-safe switch: hides every overlay, HUD, message and sound of this mod. Always starts OFF. */
    public int keyStreamMode = GLFW.GLFW_KEY_F8;
    /** Switches the server-side shiny boost around you on / off. */
    public int keyShinyBoost = GLFW.GLFW_KEY_F7;

    // ---------------- Pokémon menu (sends commands; needs operator rights or cheats) ----------------
    public int pokeDefaultLevel = 50;
    public boolean pokeDefaultShiny = false;
    /** Extra Cobblemon properties added to every command, e.g. "ability=synchronize". */
    public String pokeExtraProps = "";
    /** Custom buttons: "Label=command" entries separated by ";;" (no leading slash). */
    public String pokeCustomCommands = "";

    // ---------------- Local shiny boost (singleplayer / LAN host only) ----------------
    public boolean shinyBoostEnabled = false;
    /** Odds multiplier: 10 = ten times more likely (e.g. 1/8192 -> 1/819). */
    public int shinyMultiplier = 10;
    public boolean shinyBoostNotify = true;
    /** Multiplier asked from the server (needs the Cobblemon Shiny Control server mod; allowed players only). */
    public int shinyServerMultiplier = 1000;

    // ---------------- Cobblemon radar (overlay) ----------------
    public boolean radarEnabled = true;
    public boolean radarShiny = true;
    public boolean radarLegendary = true;
    public boolean radarHiddenAbility = true;
    public boolean radarHighIv = true;
    /** Draw the species of the watchlist (set in Spawn Alerts) on the overlay too. */
    public boolean radarWatchlist = true;
    public boolean radarUltraBeast = true;
    /** Minimum number of stats at 31 IV for the "perfect IVs" filter (1..6). */
    public int radarMinPerfectIvStats = 3;
    public boolean radarIgnoreOwned = true;

    public int radarShinyColor = 0xFFD700;
    public int radarLegendaryColor = 0xFF4500;
    public int radarHiddenAbilityColor = 0x9400D3;
    public int radarHighIvColor = 0x00BFFF;

    public int radarMaxDistance = 128;
    public RenderStyle radarRenderStyle = RenderStyle.ALL;
    public float radarLineThickness = 2.0f;
    public boolean radarThroughWalls = true;

    // ---------------- Spawn alerts (chat) ----------------
    public boolean alertsEnabled = true;
    public boolean alertIgnoreOwned = true;
    public int alertMaxDistance = 128;

    public boolean alertShiny = true;
    public boolean alertLegendary = true;
    public boolean alertUltraBeast = false;
    public boolean alertHiddenAbility = false;
    public boolean alertPerfectIvs = true;
    public int alertMinPerfectIvs = 6;
    public boolean alertWatchlistEnabled = true;
    /** Comma separated species names, e.g. "dratini, larvitar, eevee". */
    public String alertWatchlist = "";
    public int alertWatchlistColor = 0x55FFFF;

    public boolean alertInChat = true;
    public boolean alertActionBar = false;
    public boolean alertSound = true;
    public boolean alertShowCoords = true;

    // ---------------- Chest / container ESP ----------------
    public boolean chestEspEnabled = true;
    public boolean chestThroughWalls = true;
    public boolean chestTracers = false;

    public boolean chestEspChests = true;
    public boolean chestEspTrappedChests = true;
    public boolean chestEspBarrels = true;
    public boolean chestEspShulkers = true;
    /** Any container from another mod (loot containers, modded chests / barrels...). */
    public boolean chestEspModded = true;
    /** Extra block ids to treat as containers: "modid:block", "modid:*" or just "modid". Comma separated. */
    public String chestExtraBlocks = "";
    /** Smart detection of modded chests (by block class and name). Recommended. */
    public boolean chestSmartDetect = true;
    /** Old broad mode: ANY modded block holding an inventory (also crafting tables, machines...). */
    public boolean chestDetectAnyInventory = false;
    /** Block ids to never highlight (same format as the extra list). */
    public String chestIgnoreBlocks = "";

    public int chestUnlootedColor = 0x00FF00;
    public int chestLootedColor = 0x808080;
    public boolean chestUsePerTypeColors = false;
    public int chestColorChest = 0x00FF00;
    public int chestColorTrapped = 0xFF3030;
    public int chestColorBarrel = 0xC08040;
    public int chestColorShulker = 0xD070FF;
    public int chestColorModded = 0x40E0FF;

    public boolean chestHideLooted = false;
    /** Hide overlays of containers closer than this many blocks (0 = off). */
    public int chestHideNearDistance = 0;
    public boolean chestAutoMarkOpened = true;
    /** Remember whether an opened container still holds loot (shown in the "partial" color). */
    public boolean chestTrackLeftovers = true;
    public int chestColorPartial = 0xFFA500;

    public int chestMaxRadius = 64;
    public float chestLineThickness = 2.0f;
    public float chestBoxOpacity = 0.25f;

    // ---------------- Points of interest (block-entity blocks, e.g. Cobblemon machines) ----------------
    public boolean poiEnabled = false;
    /** Block ids: "modid:block", "modid:*" or "modid". Comma separated. Only block entities are detected. */
    public String poiBlocks = "";
    public int poiColor = 0xFF55FF;

    // ---------------- Structure finder ----------------
    public int structureColor = 0x00FFFF;
    /** true = world path line + beam + HUD icon, false = simple screen compass only. */
    public boolean structureAutoPathLine = true;
    /** Search radius in chunks used by the locate algorithm (singleplayer). */
    public int structureSearchRadius = 100;
    /** Save every structure you locate to the saved-waypoints list (per world / server). */
    public boolean structureAutoSave = true;

    // ---------------- Pokémon finder (needs the Cobblemon Shiny Control server mod) ----------------
    /** Wanted number of lines kept on screen is limited by the server; this one only sets the default filter. */
    public String finderDefaultFilter = "all";

    // ---------------- Poké Ball aim assist ----------------
    public boolean ballAimEnabled = false;
    /** Only aims when you throw while a Pokémon is under / near the crosshair (within this angle, degrees). */
    public float ballAimFov = 8.0f;
    public int ballAimMaxDistance = 80;
    /** Throw velocity of a Poké Ball in blocks / tick (Cobblemon default is about 1.25). Auto-calibrated if possible. */
    public float ballAimSpeed = 1.25f;
    public float ballAimGravity = 0.03f;
    public float ballAimDrag = 0.99f;
    public boolean ballAimLeadTarget = true;
    public boolean ballAimShowArc = true;
    /** Ignore Pokémon that belong to a player. */
    public boolean ballAimWildOnly = true;
    public int ballAimColor = 0xFF55FF;

    // ---------------- Container filter ----------------
    public int chestFilterColor = 0xFFD700;
    public boolean chestFilterThroughWalls = true;
    /** While a filter result is shown, the normal chest overlay only draws the matching containers. */
    public boolean chestFilterHideOthers = false;
    /** Keep scanning automatically while a filter is set (as you walk). */
    public boolean chestFilterAuto = true;
    public int chestFilterIntervalSeconds = 6;

    // ---------------- Battle & advice ----------------
    public boolean battleAdvisorEnabled = true;
    public boolean ballAdviceEnabled = true;
    public boolean finderAlertsEnabled = true;
    /** Seconds between automatic Pokémon scans (the server limits non-operators to one search per 30 s by default). */
    public int finderAlertIntervalSeconds = 35;
    public boolean finderAlertSound = true;
    /** Which Pokémon trigger an automatic alert. */
    public boolean finderAlertShiny = true;
    public boolean finderAlertLegendary = true;
    public boolean finderAlertHiddenAbility = false;
    /** Alert for Pokémon with at least this many perfect (31) IVs; 7 = never. */
    public int finderAlertMinPerfectIvs = 5;

    // ---------------- Look ----------------
    /** Notifications (alerts, found chests) as on-screen toasts instead of chat lines. */
    public boolean hudToasts = true;
    /** Floating labels above the containers found by the filter. */
    public boolean hudFloatingLabels = true;
}
