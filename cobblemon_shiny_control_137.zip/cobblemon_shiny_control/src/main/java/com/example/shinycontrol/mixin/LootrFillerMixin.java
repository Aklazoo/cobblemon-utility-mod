package com.example.shinycontrol.mixin;

import com.example.shinycontrol.LootrContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Tells us which player Lootr is filling a chest for. Applied only if Lootr's method really has this shape. */
@Pseudo
@Mixin(targets = "noobanidus.mods.lootr.common.api.data.DefaultLootFiller", remap = false)
public abstract class LootrFillerMixin {
    @Inject(method = "unpackLootTable", at = @At("HEAD"), remap = false, require = 0)
    private void shinycontrol$ctx(@Coerce Object provider, PlayerEntity player, Inventory container, CallbackInfo ci) {
        if (player != null) LootrContext.set(player.getUuid());
    }
}
