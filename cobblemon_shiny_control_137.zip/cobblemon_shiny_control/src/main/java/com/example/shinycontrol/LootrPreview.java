package com.example.shinycontrol;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.context.LootContextParameterSet;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Method;
import java.util.function.Predicate;

/**
 * Exact content of a never-opened Lootr chest, for one player. Lootr asks LootrAPI.getLootSeed(chestSeed) when it
 * opens the chest; our mixin makes that value depend only on (chest seed, player), so the same call made here,
 * with the same player set in {@link LootrContext}, gives the seed Lootr will use. We then roll the chest's loot
 * table with that seed into a scratch inventory and count the wanted items.
 */
final class LootrPreview {
    private static Method getLootSeed;
    private static boolean unavailable;

    private LootrPreview() {}

    /** Number of matching items the player would get, or null if it cannot be known exactly. */
    static Integer count(ServerWorld world, ServerPlayerEntity player, BlockEntity be, Predicate<String> idMatches) {
        if (unavailable) return null;
        try {
            NbtCompound nbt = be.createNbt(world.getRegistryManager());
            if (!nbt.contains("LootTable", NbtElement.STRING_TYPE)) return null;
            Identifier table = Identifier.tryParse(nbt.getString("LootTable"));
            if (table == null) return null;
            long chestSeed = nbt.getLong("LootTableSeed");

            Long seed = lootrSeed(chestSeed, player);
            if (seed == null) return null;

            LootTable lt = world.getServer().getReloadableRegistries()
                    .getLootTable(RegistryKey.of(RegistryKeys.LOOT_TABLE, table));
            if (lt == LootTable.EMPTY) return null;
            LootContextParameterSet params = new LootContextParameterSet.Builder(world)
                    .add(LootContextParameters.ORIGIN, Vec3d.ofCenter(be.getPos()))
                    .luck(player.getLuck())
                    .add(LootContextParameters.THIS_ENTITY, player)
                    .build(LootContextTypes.CHEST);
            SimpleInventory inv = new SimpleInventory(27);
            lt.supplyInventory(inv, params, seed);
            int n = 0;
            for (int i = 0; i < inv.size(); i++) {
                ItemStack st = inv.getStack(i);
                if (!st.isEmpty() && idMatches.test(Registries.ITEM.getId(st.getItem()).toString())) n += st.getCount();
            }
            return n;
        } catch (Throwable t) {
            return null;
        }
    }

    /** The seed Lootr will use for this player, or null when it is random (our hook is not active). */
    private static Long lootrSeed(long chestSeed, ServerPlayerEntity player) {
        try {
            if (getLootSeed == null) {
                Class<?> api = Class.forName("noobanidus.mods.lootr.common.api.LootrAPI");
                getLootSeed = api.getMethod("getLootSeed", long.class);
            }
            LootrContext.set(player.getUuid());
            try {
                long a = (Long) getLootSeed.invoke(null, chestSeed);
                long b = (Long) getLootSeed.invoke(null, chestSeed);
                return a == b ? a : null;
            } finally {
                LootrContext.clear();
            }
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            unavailable = true;
            return null;
        } catch (Throwable t) {
            return null;
        }
    }
}
