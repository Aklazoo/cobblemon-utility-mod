# Cobblemon Shiny Control (Fabric 1.21.1) - server-side

Put the jar in the server's mods/ folder (Exaroton: Files -> mods). No client install needed.
Needs Fabric API and Cobblemon on the server. Commands require op level 2 (console always works).

/shinyrate                       status
/shinyrate multiplier <x>        permanent multiplier (saved in config/cobblemon_shiny_control.json)
/shinyrate set <N>               shiny odds 1/N
/shinyrate boost <x> <seconds>   temporary boost, announced to all players
/shinyrate boost stop
/shinyrate reset

It changes Cobblemon's in-memory shinyRate only; Cobblemon's own config file is not modified.

## Finder (only through the Cobblemon Utility client mod, no chat command, no op needed)
The client mod (1.6.0+) sends a request packet; this mod answers. Typing anything in chat does nothing.
Pokémon finder: shiny / legendary / hidden ability / N perfect IVs / species, nearest first.
Structure finder: lists every registered structure (modded included) and returns coordinates.

Config (config/cobblemon_shiny_control.json, restart after editing):
findEnabled, structuresEnabled, allowedPlayers (empty = everyone with the client mod),
findCooldownSeconds, findMaxRadius, findMaxResults, findDefaultMinPerfectIvs,
findCoords ("exact" | "approx" | "direction"), findIvDisplay ("full" | "count" | "none"), findIncludeOwned,
structureCooldownSeconds, structureSearchRadius,
chestsEnabled, chestCooldownSeconds, chestMaxRadius, chestMaxResults (container finder; loaded chunks only, never-opened
loot chests are revealed because their loot is generated from the chest's own seed when read). Operators ignore cooldowns.
It only sees Pokémon in chunks the server has loaded.
