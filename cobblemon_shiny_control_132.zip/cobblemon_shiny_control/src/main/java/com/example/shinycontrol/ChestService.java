package com.example.shinycontrol;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Finds loaded containers that hold an item matching a text (id or display name).
 * Reading a slot of a loot container (Inventory#getStack) makes vanilla generate its loot first, with the
 * chest's own fixed loot seed, so a never-opened structure chest reveals what it would give when opened
 * (the only difference: no player Luck bonus). Only chunks that are loaded on the server can be read.
 */
public final class ChestService {
    private record Hit(BlockPos pos, double dist, String block, String item, int count) {}

    private ChestService() {}

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    public static JsonObject find(ServerPlayerEntity player, String query) {
        ControlConfig cfg = ControlConfig.get();
        ServerWorld world = (ServerWorld) player.getWorld();
        String q = norm(query);
        String exact = query != null && query.indexOf(':') > 0 ? query.trim().toLowerCase(Locale.ROOT) : null;
        JsonObject out = new JsonObject();
        out.addProperty("t", "chests");
        out.addProperty("q", query);
        out.addProperty("radius", cfg.chestMaxRadius);
        JsonArray arr = new JsonArray();
        out.add("hits", arr);
        if (q.length() < 2) {
            out.addProperty("total", 0);
            return out;
        }

        BlockPos origin = player.getBlockPos();
        int r = cfg.chestMaxRadius;
        double maxSq = (double) r * r;
        int cx0 = (origin.getX() - r) >> 4, cx1 = (origin.getX() + r) >> 4;
        int cz0 = (origin.getZ() - r) >> 4, cz1 = (origin.getZ() + r) >> 4;

        List<Hit> hits = new ArrayList<>();
        for (int cx = cx0; cx <= cx1; cx++) {
            for (int cz = cz0; cz <= cz1; cz++) {
                WorldChunk chunk = world.getChunkManager().getWorldChunk(cx, cz); // loaded only
                if (chunk == null) continue;
                for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                    if (!(be instanceof Inventory inv)) continue;
                    BlockPos p = be.getPos();
                    double d2 = p.getSquaredDistance(origin);
                    if (d2 > maxSq) continue;
                    int count = 0;
                    String itemName = null;
                    for (int i = 0; i < inv.size(); i++) {
                        ItemStack st = inv.getStack(i);
                        if (st.isEmpty()) continue;
                        String id = Registries.ITEM.getId(st.getItem()).toString();
                        String name = st.getName().getString();
                        boolean ok = exact != null ? id.equals(exact) : (norm(id).contains(q) || norm(name).contains(q));
                        if (ok) {
                            count += st.getCount();
                            if (itemName == null) itemName = name;
                        }
                    }
                    if (count > 0) {
                        hits.add(new Hit(p, Math.sqrt(d2), be.getCachedState().getBlock().getName().getString(),
                                itemName, count));
                    }
                }
            }
        }
        hits.sort((a, b) -> Double.compare(a.dist(), b.dist()));
        out.addProperty("total", hits.size());
        for (int i = 0; i < Math.min(hits.size(), cfg.chestMaxResults); i++) {
            Hit h = hits.get(i);
            JsonObject o = new JsonObject();
            o.addProperty("x", h.pos().getX());
            o.addProperty("y", h.pos().getY());
            o.addProperty("z", h.pos().getZ());
            o.addProperty("dist", (int) h.dist());
            o.addProperty("block", h.block());
            o.addProperty("item", h.item());
            o.addProperty("count", h.count());
            arr.add(o);
        }
        return out;
    }
}
