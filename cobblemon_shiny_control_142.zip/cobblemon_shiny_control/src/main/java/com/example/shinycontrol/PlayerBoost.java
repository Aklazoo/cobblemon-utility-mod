package com.example.shinycontrol;

import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Per-player shiny boost, switched by the Cobblemon Utility client (no chat command).
 * When a wild Pokémon appears (is added to the world) and the nearest player has the boost on, it gets an extra
 * shiny roll so that its total shiny chance is (multiplier x Cobblemon's chance), capped at 100%.
 * Other players are never affected: only Pokémon whose nearest player is boosted are touched.
 */
public final class PlayerBoost {
    private static final String TAG = "scb_seen";
    private static final String POKEMON_ENTITY = "com.cobblemon.mod.common.entity.pokemon.PokemonEntity";
    /** Player -> total shiny chance (0..1) wanted for wild Pokémon around them. */
    private static final Map<UUID, Double> ACTIVE = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST = new ConcurrentHashMap<>();
    private static Class<?> pokemonEntityClass;
    private static boolean classLookedUp;
    private static boolean loggedFirst;

    private PlayerBoost() {}

    public static void init() {
        ServerEntityEvents.ENTITY_LOAD.register(PlayerBoost::onLoad);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> ACTIVE.remove(handler.getPlayer().getUuid()));
    }

    // ------------------------------------------------------------------ requests from the client
    static void handle(ServerPlayerEntity player, JsonObject req) {
        ControlConfig cfg = ControlConfig.get();
        boolean on = req.has("on") && req.get("on").getAsBoolean();
        Float rate0 = ShinyRate.currentRate();
        double base0 = 1.0 / (rate0 != null && rate0 > 0 ? rate0 : 8192.0);
        // The client asks for a chance in percent ("chance"); an older client asks for a multiplier ("mult").
        double wanted;
        if (req.has("chance")) wanted = req.get("chance").getAsDouble() / 100.0;
        else wanted = (req.has("mult") ? req.get("mult").getAsInt() : 1000) * base0;
        double maxP = Math.min(1.0, Math.max(0.0, cfg.boostMaxChancePercent / 100.0));
        double target = Math.max(base0, Math.min(maxP, wanted));

        JsonObject out = new JsonObject();
        out.addProperty("t", "boost");
        if (!cfg.boostEnabled) {
            ACTIVE.remove(player.getUuid());
            out.addProperty("on", false);
            out.addProperty("msg", "The shiny boost is disabled on this server.");
            ServerNet.reply(player, out);
            return;
        }
        if (!mayBoost(player)) {
            ACTIVE.remove(player.getUuid());
            out.addProperty("on", false);
            out.addProperty("msg", "You are not allowed to use the shiny boost on this server.");
            ServerNet.reply(player, out);
            return;
        }
        long now = System.currentTimeMillis();
        Long last = LAST.get(player.getUuid());
        if (last != null && now - last < 500) return; // ignore double clicks
        LAST.put(player.getUuid(), now);

        if (on) {
            ACTIVE.put(player.getUuid(), target);
            double pct = Math.round(target * 1000.0) / 10.0;
            out.addProperty("msg", "Shiny boost ON: " + pct + "% of the wild Pokémon around you will be shiny.");
            ShinyControlMod.LOGGER.info("{} turned the shiny boost ON ({}% per wild Pokémon)", player.getName().getString(), pct);
        } else {
            ACTIVE.remove(player.getUuid());
            out.addProperty("msg", "Shiny boost OFF.");
            ShinyControlMod.LOGGER.info("{} turned the shiny boost OFF", player.getName().getString());
        }
        out.addProperty("on", on);
        out.addProperty("chance", Math.round(target * 1000.0) / 10.0);
        ServerNet.reply(player, out);
    }

    private static boolean mayBoost(ServerPlayerEntity player) {
        ControlConfig cfg = ControlConfig.get();
        java.util.List<String> list = cfg.boostAllowedPlayers;
        String name = player.getName().getString().toLowerCase(Locale.ROOT);
        if (list != null && !list.isEmpty()) { // a list restricts the boost to these players
            for (String s : list) if (s != null && s.trim().toLowerCase(Locale.ROOT).equals(name)) return true;
            return false;
        }
        if (cfg.boostRequireOp) {
            return player.getServer() != null && player.getServer().getPlayerManager().isOperator(player.getGameProfile());
        }
        return true; // empty list and no op requirement: every player who has the client mod
    }

    // ------------------------------------------------------------------ the extra roll
    private static void onLoad(Entity entity, ServerWorld world) {
        try {
            if (!isPokemonEntity(entity)) return;
            if (entity.getCommandTags().contains(TAG)) return; // already handled (saved with the entity)
            entity.addCommandTag(TAG);                          // so a reload of the chunk never rolls it again
            if (ACTIVE.isEmpty()) return;
            if (entity instanceof TameableEntity t && t.getOwnerUuid() != null) return; // someone's own Pokémon

            ControlConfig cfg = ControlConfig.get();
            PlayerEntity nearest = world.getClosestPlayer(entity.getX(), entity.getY(), entity.getZ(), cfg.boostRadius, false);
            if (nearest == null) return;
            Double wantedChance = ACTIVE.get(nearest.getUuid());
            if (wantedChance == null) return; // the nearest player has no boost: leave it alone

            Object pokemon = entity.getClass().getMethod("getPokemon").invoke(entity);
            if (pokemon == null) return;
            Method getShiny = pokemon.getClass().getMethod("getShiny");
            if ((Boolean) getShiny.invoke(pokemon)) return;

            Float rate = ShinyRate.currentRate();
            double base = 1.0 / (rate != null && rate > 0 ? rate : 8192.0);
            double target = Math.min(1.0, wantedChance);
            double extra = target > base ? (target - base) / (1.0 - base) : 0.0; // chance of the additional roll
            if (world.getRandom().nextDouble() < extra) {
                pokemon.getClass().getMethod("setShiny", boolean.class).invoke(pokemon, true);
                if (!loggedFirst) {
                    loggedFirst = true;
                    ShinyControlMod.LOGGER.info("Shiny boost: made a {} shiny near {} (wanted chance {})",
                            entity.getName().getString(), nearest.getName().getString(), wantedChance);
                }
            }
        } catch (Throwable t) {
            ShinyControlMod.LOGGER.warn("Shiny boost roll failed: {}", t.toString());
        }
    }

    private static boolean isPokemonEntity(Entity e) {
        if (!classLookedUp) {
            classLookedUp = true;
            try {
                pokemonEntityClass = Class.forName(POKEMON_ENTITY, false, PlayerBoost.class.getClassLoader());
            } catch (Throwable t) {
                pokemonEntityClass = null;
            }
        }
        return pokemonEntityClass != null && pokemonEntityClass.isInstance(e);
    }
}
