package com.example.cobbleutility.config;

import com.example.cobbleutility.CobblemonUtilityMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH =
            FabricLoader.getInstance().getConfigDir().resolve("cobblemon_utility_mod.json");

    private static ModConfig config = new ModConfig();

    private ConfigManager() {}

    public static ModConfig get() {
        return config;
    }

    public static void load() {
        if (Files.exists(PATH)) {
            try {
                String json = Files.readString(PATH, StandardCharsets.UTF_8);
                ModConfig loaded = GSON.fromJson(json, ModConfig.class);
                if (loaded != null) config = loaded;
            } catch (Exception e) {
                CobblemonUtilityMod.LOGGER.error("Could not read config, using defaults", e);
                config = new ModConfig();
            }
        }
        sanitize(config);
        save(); // writes defaults / newly added fields
    }

    public static void save() {
        sanitize(config);
        try {
            Files.createDirectories(PATH.getParent());
            Files.writeString(PATH, GSON.toJson(config), StandardCharsets.UTF_8);
        } catch (IOException e) {
            CobblemonUtilityMod.LOGGER.error("Could not save config", e);
        }
    }

    private static void sanitize(ModConfig c) {
        if (c.chestIgnoreBlocks == null) c.chestIgnoreBlocks = "";
        c.pokeDefaultLevel = clamp(c.pokeDefaultLevel, 1, 100);
        if (c.pokeExtraProps == null) c.pokeExtraProps = "";
        if (c.pokeCustomCommands == null) c.pokeCustomCommands = "";
        c.shinyMultiplier = clamp(c.shinyMultiplier, 1, 1000);
        c.radarMaxDistance = clamp(c.radarMaxDistance, 32, 256);
        c.radarMinPerfectIvStats = clamp(c.radarMinPerfectIvStats, 1, 6);
        c.radarLineThickness = clamp(c.radarLineThickness, 0.5f, 8f);
        c.chestMaxRadius = clamp(c.chestMaxRadius, 16, 256);
        c.chestHideNearDistance = clamp(c.chestHideNearDistance, 0, 64);
        c.alertMaxDistance = clamp(c.alertMaxDistance, 32, 256);
        c.alertMinPerfectIvs = clamp(c.alertMinPerfectIvs, 1, 6);
        if (c.alertWatchlist == null) c.alertWatchlist = "";
        c.alertWatchlistColor &= 0xFFFFFF;
        c.chestColorChest &= 0xFFFFFF;
        c.chestColorTrapped &= 0xFFFFFF;
        c.chestColorBarrel &= 0xFFFFFF;
        c.chestColorShulker &= 0xFFFFFF;
        c.chestLineThickness = clamp(c.chestLineThickness, 0.5f, 8f);
        c.chestBoxOpacity = clamp(c.chestBoxOpacity, 0f, 1f);
        if (c.radarRenderStyle == null) c.radarRenderStyle = RenderStyle.ALL;
        c.radarShinyColor &= 0xFFFFFF;
        c.radarLegendaryColor &= 0xFFFFFF;
        c.radarHiddenAbilityColor &= 0xFFFFFF;
        c.radarHighIvColor &= 0xFFFFFF;
        c.chestUnlootedColor &= 0xFFFFFF;
        c.chestLootedColor &= 0xFFFFFF;
        c.structureColor &= 0xFFFFFF;
        c.structureSearchRadius = clamp(c.structureSearchRadius, 20, 400);
        c.chestColorModded &= 0xFFFFFF;
        c.chestColorPartial &= 0xFFFFFF;
        c.poiColor &= 0xFFFFFF;
        if (c.poiBlocks == null) c.poiBlocks = "";
        if (c.chestExtraBlocks == null) c.chestExtraBlocks = "";
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private static float clamp(float v, float min, float max) {
        return Math.max(min, Math.min(max, v));
    }
}
