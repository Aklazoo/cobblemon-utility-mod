package com.example.cobbleutility.config;

import com.example.cobbleutility.esp.OpenedContainers;
import com.example.cobbleutility.input.KeybindScreen;
import com.example.cobbleutility.structure.WaypointsScreen;
import dev.isxander.yacl3.api.*;
import dev.isxander.yacl3.api.controller.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.awt.Color;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Builds the in-game settings screen with YetAnotherConfigLib 3.x. */
public final class ConfigScreenBuilder {
    private ConfigScreenBuilder() {}

    public static Screen create(Screen parent) {
        ModConfig cfg = ConfigManager.get();
        ModConfig def = new ModConfig();

        return YetAnotherConfigLib.createBuilder()
                .title(Text.literal("Cobblemon Utility Mod"))
                .category(controls())
                .category(pokeMenu(cfg, def))
                .category(shiny(cfg, def))
                .category(radar(cfg, def))
                .category(alerts(cfg, def))
                .category(chest(cfg, def))
                .category(structure(cfg, def))
                .save(ConfigManager::save)
                .build()
                .generateScreen(parent);
    }

    // ------------------------------------------------------------------ Controls
    private static ConfigCategory controls() {
        return ConfigCategory.createBuilder()
                .name(Text.literal("Controls"))
                .tooltip(Text.literal("Choose which key triggers which action"))
                .option(ButtonOption.createBuilder()
                        .name(Text.literal("Edit keybinds"))
                        .description(OptionDescription.of(Text.literal(
                                "Click an action, then press the key you want. ESC cancels, BACKSPACE unbinds. "
                                        + "Conflicts with other keys (Minecraft / Cobblemon) are shown in red.")))
                        .text(Text.literal("Open"))
                        .action((screen, opt) -> MinecraftClient.getInstance().setScreen(new KeybindScreen(screen)))
                        .build())
                .build();
    }

    // ------------------------------------------------------------------ Pokémon menu
    private static ConfigCategory pokeMenu(ModConfig c, ModConfig d) {
        return ConfigCategory.createBuilder()
                .name(Text.literal("Pokémon Menu"))
                .tooltip(Text.literal("Give / spawn Pokémon and run your own command buttons"))
                .option(intSlider("Default level", "Level used by the menu.", d.pokeDefaultLevel, 1, 100, 1,
                        () -> c.pokeDefaultLevel, v -> c.pokeDefaultLevel = v))
                .option(toggle("Shiny by default", "Menu starts with 'shiny' ticked.", d.pokeDefaultShiny,
                        () -> c.pokeDefaultShiny, v -> c.pokeDefaultShiny = v))
                .option(Option.<String>createBuilder()
                        .name(Text.literal("Extra properties"))
                        .description(OptionDescription.of(Text.literal(
                                "Cobblemon properties added to every command, separated by spaces. Example: ability=synchronize")))
                        .binding(d.pokeExtraProps, () -> c.pokeExtraProps, v -> c.pokeExtraProps = v)
                        .controller(StringControllerBuilder::create)
                        .build())
                .option(Option.<String>createBuilder()
                        .name(Text.literal("Custom command buttons"))
                        .description(OptionDescription.of(Text.literal(
                                "Format: Label=command, entries separated by ;; (no leading slash). "
                                        + "Example: Heal=pokeheal ;; Spawn=spawnpokemon eevee shiny")))
                        .binding(d.pokeCustomCommands, () -> c.pokeCustomCommands, v -> c.pokeCustomCommands = v)
                        .controller(StringControllerBuilder::create)
                        .build())
                .build();
    }

    // ------------------------------------------------------------------ Shiny boost (local)
    private static ConfigCategory shiny(ModConfig c, ModConfig d) {
        return ConfigCategory.createBuilder()
                .name(Text.literal("Shiny Boost"))
                .tooltip(Text.literal("Local shiny odds multiplier (singleplayer / LAN host only)"))
                .option(toggle("Enable shiny boost",
                        "Multiplies Cobblemon's shiny odds. Works only when YOU host the world (singleplayer or LAN): "
                                + "on a remote server the server decides and nothing changes. "
                                + "The original value is restored when you leave the world or close the game.",
                        d.shinyBoostEnabled, () -> c.shinyBoostEnabled, v -> c.shinyBoostEnabled = v))
                .option(intSlider("Odds multiplier", "10 = ten times more likely (e.g. 1/8192 becomes about 1/819).",
                        d.shinyMultiplier, 1, 1000, 1, () -> c.shinyMultiplier, v -> c.shinyMultiplier = v))
                .option(toggle("Show a chat message", "Tell me the new odds when the boost is applied / removed.",
                        d.shinyBoostNotify, () -> c.shinyBoostNotify, v -> c.shinyBoostNotify = v))
                .build();
    }

    // ------------------------------------------------------------------ Radar (overlay)
    private static ConfigCategory radar(ModConfig c, ModConfig d) {
        return ConfigCategory.createBuilder()
                .name(Text.literal("Cobblemon Radar"))
                .tooltip(Text.literal("On-screen overlay for nearby Pokémon"))
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("General"))
                        .option(toggle("Enable radar", "Master switch for the overlay.", d.radarEnabled,
                                () -> c.radarEnabled, v -> c.radarEnabled = v))
                        .option(toggle("Ignore owned Pokémon", "Skip Pokémon that belong to a trainer.",
                                d.radarIgnoreOwned, () -> c.radarIgnoreOwned, v -> c.radarIgnoreOwned = v))
                        .option(intSlider("Max scan distance", "Blocks. The client only knows entities the server sends it.",
                                d.radarMaxDistance, 32, 256, 8, () -> c.radarMaxDistance, v -> c.radarMaxDistance = v))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Filters"))
                        .option(toggle("Shiny", "Highlight shiny Pokémon.", d.radarShiny,
                                () -> c.radarShiny, v -> c.radarShiny = v))
                        .option(toggle("Legendary / Mythical", "Highlight legendary and mythical Pokémon.",
                                d.radarLegendary, () -> c.radarLegendary, v -> c.radarLegendary = v))
                        .option(toggle("Hidden Ability", "Needs server data (singleplayer).",
                                d.radarHiddenAbility, () -> c.radarHiddenAbility, v -> c.radarHiddenAbility = v))
                        .option(toggle("Perfect IVs", "Needs server data (singleplayer).",
                                d.radarHighIv, () -> c.radarHighIv, v -> c.radarHighIv = v))
                        .option(intSlider("Min. perfect stats (31 IV)", "Number of stats that must be 31.",
                                d.radarMinPerfectIvStats, 1, 6, 1,
                                () -> c.radarMinPerfectIvStats, v -> c.radarMinPerfectIvStats = v))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Colors"))
                        .option(color("Shiny color", d.radarShinyColor, () -> c.radarShinyColor, v -> c.radarShinyColor = v))
                        .option(color("Legendary color", d.radarLegendaryColor, () -> c.radarLegendaryColor, v -> c.radarLegendaryColor = v))
                        .option(color("Hidden Ability color", d.radarHiddenAbilityColor, () -> c.radarHiddenAbilityColor, v -> c.radarHiddenAbilityColor = v))
                        .option(color("High IV color", d.radarHighIvColor, () -> c.radarHighIvColor, v -> c.radarHighIvColor = v))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Rendering"))
                        .option(Option.<RenderStyle>createBuilder()
                                .name(Text.literal("Render style"))
                                .description(OptionDescription.of(Text.literal("Tracers, HUD waypoints, 3D boxes or all of them.")))
                                .binding(d.radarRenderStyle, () -> c.radarRenderStyle, v -> c.radarRenderStyle = v)
                                .controller(o -> EnumControllerBuilder.create(o).enumClass(RenderStyle.class))
                                .build())
                        .option(toggle("See through walls", "Draw boxes and tracers even behind blocks.",
                                d.radarThroughWalls, () -> c.radarThroughWalls, v -> c.radarThroughWalls = v))
                        .option(floatSlider("Line thickness", "Tracer / box line width.", d.radarLineThickness,
                                0.5f, 6f, 0.5f, () -> c.radarLineThickness, v -> c.radarLineThickness = v, false))
                        .build())
                .build();
    }

    // ------------------------------------------------------------------ Spawn alerts (chat)
    private static ConfigCategory alerts(ModConfig c, ModConfig d) {
        return ConfigCategory.createBuilder()
                .name(Text.literal("Spawn Alerts"))
                .tooltip(Text.literal("Chat message when a Pokémon you care about appears"))
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("General"))
                        .option(toggle("Enable alerts", "Works even if the radar overlay is off.", d.alertsEnabled,
                                () -> c.alertsEnabled, v -> c.alertsEnabled = v))
                        .option(toggle("Ignore owned Pokémon", "Skip Pokémon that belong to a trainer.",
                                d.alertIgnoreOwned, () -> c.alertIgnoreOwned, v -> c.alertIgnoreOwned = v))
                        .option(intSlider("Alert distance", "Blocks. Pokémon further than what the server sends you cannot be detected.",
                                d.alertMaxDistance, 32, 256, 8, () -> c.alertMaxDistance, v -> c.alertMaxDistance = v))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("What triggers an alert"))
                        .option(toggle("Shiny", "", d.alertShiny, () -> c.alertShiny, v -> c.alertShiny = v))
                        .option(toggle("Legendary / Mythical", "", d.alertLegendary, () -> c.alertLegendary, v -> c.alertLegendary = v))
                        .option(toggle("Ultra Beast / Paradox", "", d.alertUltraBeast, () -> c.alertUltraBeast, v -> c.alertUltraBeast = v))
                        .option(toggle("Hidden Ability", "Needs server data (singleplayer).", d.alertHiddenAbility,
                                () -> c.alertHiddenAbility, v -> c.alertHiddenAbility = v))
                        .option(toggle("Perfect IVs", "Needs server data (singleplayer).", d.alertPerfectIvs,
                                () -> c.alertPerfectIvs, v -> c.alertPerfectIvs = v))
                        .option(intSlider("Min. perfect stats (31 IV)", "6 = all stats perfect.",
                                d.alertMinPerfectIvs, 1, 6, 1, () -> c.alertMinPerfectIvs, v -> c.alertMinPerfectIvs = v))
                        .option(toggle("Species watchlist", "Alert for the species listed below.", d.alertWatchlistEnabled,
                                () -> c.alertWatchlistEnabled, v -> c.alertWatchlistEnabled = v))
                        .option(Option.<String>createBuilder()
                                .name(Text.literal("Watchlist"))
                                .description(OptionDescription.of(Text.literal(
                                        "Species names separated by commas, e.g.: dratini, larvitar, eevee, mr. mime")))
                                .binding(d.alertWatchlist, () -> c.alertWatchlist, v -> c.alertWatchlist = v)
                                .controller(StringControllerBuilder::create)
                                .build())
                        .option(color("Watchlist color", d.alertWatchlistColor, () -> c.alertWatchlistColor, v -> c.alertWatchlistColor = v))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("How you are notified"))
                        .option(toggle("Message in chat", "", d.alertInChat, () -> c.alertInChat, v -> c.alertInChat = v))
                        .option(toggle("Message on action bar", "Also show it above the hotbar.", d.alertActionBar,
                                () -> c.alertActionBar, v -> c.alertActionBar = v))
                        .option(toggle("Sound", "", d.alertSound, () -> c.alertSound, v -> c.alertSound = v))
                        .option(toggle("Show coordinates", "", d.alertShowCoords, () -> c.alertShowCoords, v -> c.alertShowCoords = v))
                        .build())
                .build();
    }

    // ------------------------------------------------------------------ Chest ESP
    private static ConfigCategory chest(ModConfig c, ModConfig d) {
        return ConfigCategory.createBuilder()
                .name(Text.literal("Chest ESP"))
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("General"))
                        .option(toggle("Enable chest ESP", "Master switch.", d.chestEspEnabled,
                                () -> c.chestEspEnabled, v -> c.chestEspEnabled = v))
                        .option(toggle("See through walls", "Draw the overlay even behind blocks, however far the chest is.",
                                d.chestThroughWalls, () -> c.chestThroughWalls, v -> c.chestThroughWalls = v))
                        .option(toggle("Tracer lines", "Draw a line from your crosshair to every container (easy to spot far ones).",
                                d.chestTracers, () -> c.chestTracers, v -> c.chestTracers = v))
                        .option(intSlider("Max render radius", "Blocks. Limited by the chunks the server sends you.",
                                d.chestMaxRadius, 16, 256, 4, () -> c.chestMaxRadius, v -> c.chestMaxRadius = v))
                        .option(floatSlider("Line thickness", "Outline width.", d.chestLineThickness,
                                0.5f, 6f, 0.5f, () -> c.chestLineThickness, v -> c.chestLineThickness = v, false))
                        .option(floatSlider("Box opacity", "Fill opacity (0 = outline only).", d.chestBoxOpacity,
                                0f, 1f, 0.05f, () -> c.chestBoxOpacity, v -> c.chestBoxOpacity = v, true))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Container types"))
                        .option(toggle("Chests", "", d.chestEspChests, () -> c.chestEspChests, v -> c.chestEspChests = v))
                        .option(toggle("Trapped chests", "", d.chestEspTrappedChests, () -> c.chestEspTrappedChests, v -> c.chestEspTrappedChests = v))
                        .option(toggle("Barrels", "", d.chestEspBarrels, () -> c.chestEspBarrels, v -> c.chestEspBarrels = v))
                        .option(toggle("Shulker boxes", "", d.chestEspShulkers, () -> c.chestEspShulkers, v -> c.chestEspShulkers = v))
                        .option(toggle("Modded containers", "Any loot container added by another mod (modpack chests, barrels...).",
                                d.chestEspModded, () -> c.chestEspModded, v -> c.chestEspModded = v))
                        .option(toggle("Smart detection of modded chests", "Recognizes modded chests / barrels / crates by their class and name, "
                                        + "and skips crafting tables, furnaces and machines. Recommended.",
                                d.chestSmartDetect, () -> c.chestSmartDetect, v -> c.chestSmartDetect = v))
                        .option(toggle("Broad mode (any inventory block)", "Also highlights ANY modded block with an inventory "
                                        + "(crafting tables, machines...). Usually too noisy.",
                                d.chestDetectAnyInventory, () -> c.chestDetectAnyInventory, v -> c.chestDetectAnyInventory = v))
                        .option(Option.<String>createBuilder()
                                .name(Text.literal("Ignored blocks"))
                                .description(OptionDescription.of(Text.literal(
                                        "Block ids never highlighted (same format as the extra list). "
                                                + "Tip: look at a block and press Shift + the Inspect key to fill this automatically.")))
                                .binding(d.chestIgnoreBlocks, () -> c.chestIgnoreBlocks, v -> c.chestIgnoreBlocks = v)
                                .controller(StringControllerBuilder::create)
                                .build())
                        .option(Option.<String>createBuilder()
                                .name(Text.literal("Extra container blocks"))
                                .description(OptionDescription.of(Text.literal(
                                        "Block ids to always treat as containers, comma separated. "
                                                + "Formats: modid:block_id, modid:*, or just modid. Example: yungsextras:*, trek")))
                                .binding(d.chestExtraBlocks, () -> c.chestExtraBlocks, v -> c.chestExtraBlocks = v)
                                .controller(StringControllerBuilder::create)
                                .build())
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Colors"))
                        .option(color("Unopened color", d.chestUnlootedColor, () -> c.chestUnlootedColor, v -> c.chestUnlootedColor = v))
                        .option(color("Opened color", d.chestLootedColor, () -> c.chestLootedColor, v -> c.chestLootedColor = v))
                        .option(toggle("Different color per type", "Use the 4 colors below for unopened containers.",
                                d.chestUsePerTypeColors, () -> c.chestUsePerTypeColors, v -> c.chestUsePerTypeColors = v))
                        .option(color("Chest color", d.chestColorChest, () -> c.chestColorChest, v -> c.chestColorChest = v))
                        .option(color("Trapped chest color", d.chestColorTrapped, () -> c.chestColorTrapped, v -> c.chestColorTrapped = v))
                        .option(color("Barrel color", d.chestColorBarrel, () -> c.chestColorBarrel, v -> c.chestColorBarrel = v))
                        .option(color("Shulker color", d.chestColorShulker, () -> c.chestColorShulker, v -> c.chestColorShulker = v))
                        .option(color("Modded container color", d.chestColorModded, () -> c.chestColorModded, v -> c.chestColorModded = v))
                        .option(color("Opened but loot left", d.chestColorPartial, () -> c.chestColorPartial, v -> c.chestColorPartial = v))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Points of interest"))
                        .option(toggle("Highlight points of interest", "Highlight block-entity blocks you list below "
                                        + "(machines, PCs, special blocks of any mod).",
                                d.poiEnabled, () -> c.poiEnabled, v -> c.poiEnabled = v))
                        .option(Option.<String>createBuilder()
                                .name(Text.literal("POI block ids"))
                                .description(OptionDescription.of(Text.literal(
                                        "Comma separated: modid:block_id, modid:*, or just modid. "
                                                + "Example: cobblemon:* (every Cobblemon block with a block entity).")))
                                .binding(d.poiBlocks, () -> c.poiBlocks, v -> c.poiBlocks = v)
                                .controller(StringControllerBuilder::create)
                                .build())
                        .option(color("POI color", d.poiColor, () -> c.poiColor, v -> c.poiColor = v))
                        .build())
                .group(OptionGroup.createBuilder()
                        .name(Text.literal("Hiding rules"))
                        .option(toggle("Hide opened containers", "Don't draw containers you already opened (instead of gray).",
                                d.chestHideLooted, () -> c.chestHideLooted, v -> c.chestHideLooted = v))
                        .option(intSlider("Hide containers closer than", "Blocks (0 = never hide). Reduces clutter around you.",
                                d.chestHideNearDistance, 0, 64, 1, () -> c.chestHideNearDistance, v -> c.chestHideNearDistance = v))
                        .option(toggle("Auto-mark opened", "Mark a container as opened when you right-click it. "
                                        + "Turn off to mark them yourself with the 'Mark container' key.",
                                d.chestAutoMarkOpened, () -> c.chestAutoMarkOpened, v -> c.chestAutoMarkOpened = v))
                        .option(toggle("Remember leftover loot", "When you close a container that still holds items, it is drawn "
                                        + "in the 'Opened but loot left' color so you can come back for it.",
                                d.chestTrackLeftovers, () -> c.chestTrackLeftovers, v -> c.chestTrackLeftovers = v))
                        .option(ButtonOption.createBuilder()
                                .name(Text.literal("Forget opened containers"))
                                .description(OptionDescription.of(Text.literal(
                                        "Resets the opened list of the current world / server.")))
                                .text(Text.literal("Reset"))
                                .action((screen, opt) -> OpenedContainers.clearCurrentWorld())
                                .build())
                        .build())
                .build();
    }

    // ------------------------------------------------------------------ Structure finder
    private static ConfigCategory structure(ModConfig c, ModConfig d) {
        return ConfigCategory.createBuilder()
                .name(Text.literal("Structure Finder"))
                .option(color("Waypoint color", d.structureColor, () -> c.structureColor, v -> c.structureColor = v))
                .option(toggle("Save located structures", "Every structure you locate is added to the saved waypoints "
                                + "(per world / server), so you never have to search twice.",
                        d.structureAutoSave, () -> c.structureAutoSave, v -> c.structureAutoSave = v))
                .option(ButtonOption.createBuilder()
                        .name(Text.literal("Saved waypoints"))
                        .description(OptionDescription.of(Text.literal("Open the list of saved waypoints.")))
                        .text(Text.literal("Open"))
                        .action((screen, opt) -> MinecraftClient.getInstance().setScreen(new WaypointsScreen(screen)))
                        .build())
                .option(intSlider("Search radius", "Chunks searched around you (singleplayer). Bigger = finds farther structures but takes longer.",
                        d.structureSearchRadius, 20, 400, 10, () -> c.structureSearchRadius, v -> c.structureSearchRadius = v))
                .option(toggle("Automatic path line",
                        "ON: line + beam in the world and HUD icon. OFF: simple directional compass on screen.",
                        d.structureAutoPathLine, () -> c.structureAutoPathLine, v -> c.structureAutoPathLine = v))
                .build();
    }

    // ------------------------------------------------------------------ Helpers
    private static Option<Boolean> toggle(String name, String desc, boolean def,
                                          Supplier<Boolean> getter, Consumer<Boolean> setter) {
        return Option.<Boolean>createBuilder()
                .name(Text.literal(name))
                .description(OptionDescription.of(Text.literal(desc)))
                .binding(def, getter, setter)
                .controller(TickBoxControllerBuilder::create)
                .build();
    }

    private static Option<Integer> intSlider(String name, String desc, int def, int min, int max, int step,
                                             Supplier<Integer> getter, Consumer<Integer> setter) {
        return Option.<Integer>createBuilder()
                .name(Text.literal(name))
                .description(OptionDescription.of(Text.literal(desc)))
                .binding(def, getter, setter)
                .controller(o -> IntegerSliderControllerBuilder.create(o).range(min, max).step(step))
                .build();
    }

    private static Option<Float> floatSlider(String name, String desc, float def, float min, float max, float step,
                                             Supplier<Float> getter, Consumer<Float> setter, boolean percent) {
        return Option.<Float>createBuilder()
                .name(Text.literal(name))
                .description(OptionDescription.of(Text.literal(desc)))
                .binding(def, getter, setter)
                .controller(o -> FloatSliderControllerBuilder.create(o).range(min, max).step(step)
                        .formatValue(v -> percent
                                ? Text.literal(Math.round(v * 100) + "%")
                                : Text.literal(String.format("%.1f", v))))
                .build();
    }

    private static Option<Color> color(String name, int def, IntSupplier getter, IntConsumer setter) {
        return Option.<Color>createBuilder()
                .name(Text.literal(name))
                .description(OptionDescription.of(Text.literal("Click the swatch or type a hex value (#RRGGBB).")))
                .binding(new Color(def), () -> new Color(getter.getAsInt()), v -> setter.accept(v.getRGB() & 0xFFFFFF))
                .controller(o -> ColorControllerBuilder.create(o).allowAlpha(false))
                .build();
    }
}
