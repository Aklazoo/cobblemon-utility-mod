# Cobblemon Utility Mod 1.5.1 (Fabric 1.21.1) - itemless, client-side

Tested target: Minecraft 1.21.1 + Fabric, e.g. the "Cobblemon Academy (Legacy)" modpack.

## Features (all configurable in-game, JSON at config/cobblemon_utility_mod.json)
- Keybinds: click an action in the settings, press the key you want (conflicts are shown).
  Defaults: O settings, K structure finder, C chest ESP, R radar, mark-container unbound.
- Cobblemon radar overlay: shiny / legendary-mythical / hidden ability / perfect IVs,
  tracers, 3D boxes, HUD waypoints, colors, optional see-through-walls.
- Spawn alerts (chat): shiny, legendary/mythical, ultra beast/paradox, hidden ability, N x 31 IV,
  and a species watchlist ("rare" Pokémon you choose). Coordinates + direction + distance, sound.
- Chest ESP: chests, trapped chests, barrels, shulkers AND modded containers (any loot container of
  any mod + extra block ids you list). See-through-walls, tracers, per-type colors, opacity,
  hide opened, hide nearby, auto/manual "opened" marking.
- Pokémon menu (key H): give / spawn any Pokémon (level, shiny, legendaries list, extra properties) and custom command buttons.
  Sends /givepokemon and /spawnpokemon as you: needs operator rights or cheats.
- Shiny Boost: local multiplier on Cobblemon's shiny odds (singleplayer / LAN host only, restored on exit).
- Leftover-loot memory: a container you closed with items still inside is drawn in its own color
  (orange by default), emptied ones in gray, untouched ones in green.
- Points of interest: highlight any block-entity block you list (e.g. cobblemon:*).
- Saved waypoints: every located structure is saved per world/server; track / delete from a list.
- Structure finder: search box + list of EVERY registered structure (modpack structures included,
  singleplayer). On a remote server type any id and press "Locate typed id".

## Required mods in mods/
Fabric Loader >= 0.16, Fabric API, YetAnotherConfigLib 3.6.x (Fabric, 1.21), Cobblemon 1.6.x.
(The Cobblemon Academy modpack already contains Fabric API and Cobblemon; add YACL if missing.)

## Build
GitHub Actions workflow in .github/workflows (or locally: JDK 21 + Gradle 8.10 -> `gradle build`).
Jar: build/libs/cobblemon_utility_mod-1.5.1.jar

## Limits (Minecraft / Cobblemon, not the mod)
- IVs / hidden ability of wild Pokémon are only known in singleplayer (integrated server).
  Cobblemon spawn rarity buckets are not known to the client -> use the watchlist.
- The client cannot see loot tables: "opened" = containers you opened or marked yourself.
- Structure registry is not sent to remote clients; /locate on a server needs permission.
- Entities / chunks only exist client-side within the server's view / tracking distance.
- ESP/radar are unfair advantages on most multiplayer servers: use only where allowed.
