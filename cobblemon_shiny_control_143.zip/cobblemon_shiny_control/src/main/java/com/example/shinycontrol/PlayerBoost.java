package com.example.shinycontrol;

import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Per-player shiny boost, switched by the Cobblemon Utility client (no chat command).
 * When a wild Pokémon appears (is added to the world) and the nearest player has the boost on, it gets an extra
 * shiny roll so that its total shiny chance is (multiplier x Cobblemon's chance), capped at 100%.
 * Other players are never affected: only Pokémon whose nearest player is boosted are touched.
 */
public final class PlayerBoost {
    private static final String TAG = "scb_seen";
    private static final String POKEMON_ENTITY = "com.cobblemon.mod.common.entity.pokemon.PokemonEntity";
    /** Player -> total shiny chance (0..1) wanted for wild Pokémon around them. */
    private record Boost(double chance, Filter filter) {}

    private static final Map<UUID, Boost> ACTIVE = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST = new ConcurrentHashMap<>();
    private static Class<?> pokemonEntityClass;
    private static boolean classLookedUp;
    private static boolean loggedFirst;

    private PlayerBoost() {}

    public static void init() {
        ServerEntityEvents.ENTITY_LOAD.register(PlayerBoost::onLoad);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> ACTIVE.remove(handler.getPlayer().getUuid()));
    }

    // ------------------------------------------------------------------ requests from the client
    static void handle(ServerPlayerEntity player, JsonObject req) {
        ControlConfig cfg = ControlConfig.get();
        boolean on = req.has("on") && req.get("on").getAsBoolean();
        Float rate0 = ShinyRate.currentRate();
        double base0 = 1.0 / (rate0 != null && rate0 > 0 ? rate0 : 8192.0);
        // The client asks for a chance in percent ("chance"); an older client asks for a multiplier ("mult").
        double wanted;
        if (req.has("chance")) wanted = req.get("chance").getAsDouble() / 100.0;
        else wanted = (req.has("mult") ? req.get("mult").getAsInt() : 1000) * base0;
        double maxP = Math.min(1.0, Math.max(0.0, cfg.boostMaxChancePercent / 100.0));
        double target = Math.max(base0, Math.min(maxP, wanted));

        JsonObject out = new JsonObject();
        out.addProperty("t", "boost");
        if (!cfg.boostEnabled) {
            ACTIVE.remove(player.getUuid());
            out.addProperty("on", false);
            out.addProperty("msg", "The shiny boost is disabled on this server.");
            ServerNet.reply(player, out);
            return;
        }
        if (!mayBoost(player)) {
            ACTIVE.remove(player.getUuid());
            out.addProperty("on", false);
            out.addProperty("msg", "You are not allowed to use the shiny boost on this server.");
            ServerNet.reply(player, out);
            return;
        }
        long now = System.currentTimeMillis();
        Long last = LAST.get(player.getUuid());
        if (last != null && now - last < 500) return; // ignore double clicks
        LAST.put(player.getUuid(), now);

        if (on) {
            Filter filter = Filter.parse(req.get("filter"));
            ACTIVE.put(player.getUuid(), new Boost(target, filter));
            double pct = Math.round(target * 1000.0) / 10.0;
            out.addProperty("msg", "Shiny boost ON: " + pct + "% of "
                    + (filter == null ? "all the wild Pokémon" : "the selected wild Pokémon") + " around you will be shiny.");
            ShinyControlMod.LOGGER.info("{} turned the shiny boost ON ({}% per wild Pokémon, filter: {})",
                    player.getName().getString(), pct, filter == null ? "none (all)" : filter.describe());
        } else {
            ACTIVE.remove(player.getUuid());
            out.addProperty("msg", "Shiny boost OFF.");
            ShinyControlMod.LOGGER.info("{} turned the shiny boost OFF", player.getName().getString());
        }
        out.addProperty("on", on);
        out.addProperty("chance", Math.round(target * 1000.0) / 10.0);
        ServerNet.reply(player, out);
    }

    private static boolean mayBoost(ServerPlayerEntity player) {
        ControlConfig cfg = ControlConfig.get();
        java.util.List<String> list = cfg.boostAllowedPlayers;
        String name = player.getName().getString().toLowerCase(Locale.ROOT);
        if (list != null && !list.isEmpty()) { // a list restricts the boost to these players
            for (String s : list) if (s != null && s.trim().toLowerCase(Locale.ROOT).equals(name)) return true;
            return false;
        }
        if (cfg.boostRequireOp) {
            return player.getServer() != null && player.getServer().getPlayerManager().isOperator(player.getGameProfile());
        }
        return true; // empty list and no op requirement: every player who has the client mod
    }

    // ------------------------------------------------------------------ the extra roll
    private static void onLoad(Entity entity, ServerWorld world) {
        try {
            if (!isPokemonEntity(entity)) return;
            if (entity.getCommandTags().contains(TAG)) return; // already handled (saved with the entity)
            entity.addCommandTag(TAG);                          // so a reload of the chunk never rolls it again
            if (ACTIVE.isEmpty()) return;
            if (entity instanceof TameableEntity t && t.getOwnerUuid() != null) return; // someone's own Pokémon

            ControlConfig cfg = ControlConfig.get();
            PlayerEntity nearest = world.getClosestPlayer(entity.getX(), entity.getY(), entity.getZ(), cfg.boostRadius, false);
            if (nearest == null) return;
            Boost boost = ACTIVE.get(nearest.getUuid());
            if (boost == null) return; // the nearest player has no boost: leave it alone
            double wantedChance = boost.chance();

            Object pokemon = entity.getClass().getMethod("getPokemon").invoke(entity);
            if (pokemon == null) return;
            Method getShiny = pokemon.getClass().getMethod("getShiny");
            if ((Boolean) getShiny.invoke(pokemon)) return;
            if (boost.filter() != null && !boost.filter().matches(pokemon)) return; // not one of the selected Pokémon

            Float rate = ShinyRate.currentRate();
            double base = 1.0 / (rate != null && rate > 0 ? rate : 8192.0);
            double target = Math.min(1.0, wantedChance);
            double extra = target > base ? (target - base) / (1.0 - base) : 0.0; // chance of the additional roll
            if (world.getRandom().nextDouble() < extra) {
                pokemon.getClass().getMethod("setShiny", boolean.class).invoke(pokemon, true);
                if (!loggedFirst) {
                    loggedFirst = true;
                    ShinyControlMod.LOGGER.info("Shiny boost: made a {} shiny near {} (wanted chance {})",
                            entity.getName().getString(), nearest.getName().getString(), wantedChance);
                }
            }
        } catch (Throwable t) {
            ShinyControlMod.LOGGER.warn("Shiny boost roll failed: {}", t.toString());
        }
    }

    private static boolean isPokemonEntity(Entity e) {
        if (!classLookedUp) {
            classLookedUp = true;
            try {
                pokemonEntityClass = Class.forName(POKEMON_ENTITY, false, PlayerBoost.class.getClassLoader());
            } catch (Throwable t) {
                pokemonEntityClass = null;
            }
        }
        return pokemonEntityClass != null && pokemonEntityClass.isInstance(e);
    }

    // ------------------------------------------------------------------ which Pokémon are boosted
    /** null filter = every Pokémon. Otherwise a Pokémon is boosted if it matches ANY selected type, category or species. */
    private record Filter(Set<String> types, Set<String> cats, Set<String> species) {
        static Filter parse(JsonElement e) {
            if (e == null || !e.isJsonObject()) return null;
            JsonObject o = e.getAsJsonObject();
            if (!o.has("enabled") || !o.get("enabled").getAsBoolean()) return null;
            return new Filter(set(o, "types"), set(o, "cats"), set(o, "species"));
        }

        private static Set<String> set(JsonObject o, String key) {
            Set<String> out = new HashSet<>();
            if (o.has(key) && o.get(key).isJsonArray()) {
                JsonArray a = o.getAsJsonArray(key);
                for (JsonElement x : a) out.add(norm(x.getAsString()));
            }
            out.remove("");
            return out;
        }

        String describe() {
            return "types=" + types + " categories=" + cats + " species=" + species;
        }

        boolean matches(Object pokemon) {
            try {
                Object species = call(pokemon, "getSpecies");
                if (!this.species.isEmpty() && species != null) {
                    if (this.species.contains(norm(String.valueOf(call(species, "getName"))))) return true;
                }
                if (!types.isEmpty()) {
                    Object ts = call(pokemon, "getTypes");
                    if (ts instanceof Iterable<?> it) {
                        for (Object t : it) if (types.contains(norm(String.valueOf(call(t, "getName"))))) return true;
                    } else if (species != null) {
                        Object p = call(species, "getPrimaryType"), q = call(species, "getSecondaryType");
                        if (p != null && types.contains(norm(String.valueOf(call(p, "getName"))))) return true;
                        if (q != null && types.contains(norm(String.valueOf(call(q, "getName"))))) return true;
                    }
                }
                if (!cats.isEmpty()) {
                    Set<String> labels = new HashSet<>();
                    addLabels(labels, species);
                    addLabels(labels, call(pokemon, "getForm"));
                    boolean legendary = Boolean.TRUE.equals(call(pokemon, "isLegendary")) || labels.contains("legendary");
                    boolean mythical = Boolean.TRUE.equals(call(pokemon, "isMythical")) || labels.contains("mythical");
                    boolean ub = labels.contains("ultrabeast");
                    boolean paradox = labels.contains("paradox");
                    if (cats.contains("legendary") && legendary) return true;
                    if (cats.contains("mythical") && mythical) return true;
                    if (cats.contains("ultrabeast") && ub) return true;
                    if (cats.contains("paradox") && paradox) return true;
                    if (cats.contains("normal") && !legendary && !mythical && !ub && !paradox) return true;
                }
            } catch (Throwable t) {
                // unreadable: not matching
            }
            return false;
        }

        private static void addLabels(Set<String> out, Object holder) {
            if (holder == null) return;
            Object labels = call(holder, "getLabels");
            if (labels instanceof Collection<?> c) for (Object o : c) out.add(norm(String.valueOf(o)));
        }
    }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private static Object call(Object target, String method) {
        if (target == null) return null;
        try {
            Method m = target.getClass().getMethod(method);
            return m.invoke(target);
        } catch (Throwable t) {
            return null;
        }
    }
}
