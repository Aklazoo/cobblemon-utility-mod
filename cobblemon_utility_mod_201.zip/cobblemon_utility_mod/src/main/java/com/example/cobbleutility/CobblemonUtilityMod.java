package com.example.cobbleutility;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.esp.ContainerEsp;
import com.example.cobbleutility.esp.OpenedContainers;
import com.example.cobbleutility.input.KeyHandler;
import com.example.cobbleutility.radar.RadarManager;
import com.example.cobbleutility.shiny.ShinyBoost;
import com.example.cobbleutility.render.Overlay;
import com.example.cobbleutility.structure.StructureFinder;
import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CobblemonUtilityMod implements ClientModInitializer {
    public static final String MOD_ID = "cobblemon_utility_mod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        ConfigManager.load();
        com.example.cobbleutility.net.ServerLink.init();
        KeyHandler.init();
        RadarManager.init();
        OpenedContainers.init();
        ContainerEsp.init();
        StructureFinder.init();
        ShinyBoost.init();
        com.example.cobbleutility.ballaim.BallAim.init();
        com.example.cobbleutility.ballaim.BallAdvice.init();
        com.example.cobbleutility.battle.BattleAdvisor.init();
        com.example.cobbleutility.finder.FinderAlerts.init();
        Overlay.init();
        LOGGER.info("Cobblemon Utility Mod loaded (itemless, client-side).");
    }
}
