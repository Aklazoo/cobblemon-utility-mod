package com.example.cobbleutility.input;

import com.example.cobbleutility.config.ConfigManager;
import com.example.cobbleutility.config.ConfigScreenBuilder;
import com.example.cobbleutility.config.ModConfig;
import com.example.cobbleutility.esp.OpenedContainers;
import com.example.cobbleutility.pokemenu.PokeMenuScreen;
import com.example.cobbleutility.structure.StructureFinderScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Keys come from ModConfig (editable in the config GUI), so there is a single source of truth.
 * Keys are polled with edge detection and ignored while any screen (chat, inventory...) is open.
 */
public final class KeyHandler {
    private static final boolean[] wasDown = new boolean[12];

    private KeyHandler() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(KeyHandler::tick);
    }

    private static void tick(MinecraftClient mc) {
        if (mc.player == null || mc.getWindow() == null) return;
        ModConfig c = ConfigManager.get();
        long handle = mc.getWindow().getHandle();
        boolean free = mc.currentScreen == null;

        if (edge(0, handle, c.keyOpenSettings, free)) {
            mc.setScreen(ConfigScreenBuilder.create(null));
        }
        if (edge(1, handle, c.keyStructureFinder, free)) {
            mc.setScreen(new StructureFinderScreen(null));
        }
        if (edge(2, handle, c.keyToggleChestEsp, free)) {
            c.chestEspEnabled = !c.chestEspEnabled;
            ConfigManager.save();
            message(mc, "Chest ESP", c.chestEspEnabled);
        }
        if (edge(3, handle, c.keyToggleRadar, free)) {
            c.radarEnabled = !c.radarEnabled;
            ConfigManager.save();
            message(mc, "Cobblemon Radar", c.radarEnabled);
        }
        if (edge(6, handle, c.keyInspectBlock, free)) {
            com.example.cobbleutility.esp.ContainerEsp.inspect(mc, net.minecraft.client.gui.screen.Screen.hasShiftDown());
        }
        if (edge(5, handle, c.keyOpenPokeMenu, free)) {
            mc.setScreen(new PokeMenuScreen(null));
        }
        if (edge(7, handle, c.keyPokeFinder, free)) {
            mc.setScreen(new com.example.cobbleutility.finder.PokeFinderScreen(null));
        }
        if (edge(9, handle, c.keyChestFilter, free)) {
            mc.setScreen(new com.example.cobbleutility.finder.ChestFilterScreen(null));
        }
        if (edge(10, handle, c.keyTypeAdvisor, free)) {
            mc.setScreen(new com.example.cobbleutility.battle.TypeAdvisorScreen(null));
        }
        if (edge(11, handle, c.keyStreamMode, free)) {
            com.example.cobbleutility.util.StreamMode.toggle();
            if (!com.example.cobbleutility.util.StreamMode.active()) message(mc, "Stream mode", false);
        }
        if (edge(8, handle, c.keyBallAim, free)) {
            c.ballAimEnabled = !c.ballAimEnabled;
            ConfigManager.save();
            message(mc, "Poké Ball aim", c.ballAimEnabled);
        }
        if (edge(4, handle, c.keyMarkContainer, free)) {
            OpenedContainers.toggleLookedAt(mc);
        }
    }

    private static boolean edge(int idx, long handle, int key, boolean free) {
        boolean now = key != GLFW.GLFW_KEY_UNKNOWN && InputUtil.isKeyPressed(handle, key);
        boolean fire = now && !wasDown[idx] && free;
        wasDown[idx] = now;
        return fire;
    }

    private static void message(MinecraftClient mc, String what, boolean on) {
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(what + ": " + (on ? "§aON" : "§cOFF")), true);
        }
    }
}
